import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

// kg of CO2 avoided per kWh of solar generation (grid-avoidance factor).
const CO2_PER_KWH = 0.7;

// Public, unauthenticated endpoint: returns aggregate impact numbers only.
// No customer-identifying data ever leaves this function.
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);

    const [customers, solar, locations] = await Promise.all([
      base44.asServiceRole.entities.Customer.list(),
      base44.asServiceRole.entities.SolarData.list(),
      base44.asServiceRole.entities.Location.list(),
    ]);

    const list = Array.isArray(customers) ? customers : [];
    const solarList = Array.isArray(solar) ? solar : [];
    const locList = Array.isArray(locations) ? locations : [];

    const homes = list.filter((c) => c.status === 'active').length;
    const capacityKw = list.reduce((s, c) => s + (Number(c.solar_capacity_kw) || 0), 0);
    const metersOnline = list.filter((c) => c.meter_status === 'online').length;

    const kwhGenerated = solarList.reduce((s, r) => s + (Number(r.production_kwh) || 0), 0);
    const co2SavedKg = kwhGenerated * CO2_PER_KWH;

    return Response.json({
      homes,
      customers: list.length,
      metersOnline,
      locations: locList.length,
      capacityKw: Math.round(capacityKw * 10) / 10,
      kwhGenerated: Math.round(kwhGenerated * 10) / 10,
      co2SavedKg: Math.round(co2SavedKg * 10) / 10,
      co2PerKwh: CO2_PER_KWH,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}