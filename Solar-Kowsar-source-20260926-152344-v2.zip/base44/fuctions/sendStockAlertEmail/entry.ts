import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';

// Do not email twice for the same low-stock item within this window.
const LOW_STOCK_WINDOW_MS = 6 * 60 * 60 * 1000;

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const payload = await req.json().catch(() => ({}));
    const itemId = payload?.itemId;
    if (!itemId) return Response.json({ error: 'itemId is required' }, { status: 400 });

    const item = await base44.asServiceRole.entities.StockItem.get(itemId).catch(() => null);
    if (!item) return Response.json({ error: 'Stock item not found' }, { status: 404 });

    const qty = Number(item.quantity) || 0;
    const min = Number(item.min_quantity) || 0;
    if (qty > min) return Response.json({ sent: false, reason: 'above_minimum' });

    const title = `Digniin kayd: ${item.name}`;

    const recent = await base44.asServiceRole.entities.Notification.list('-created_date', 20);
    const cutoff = Date.now() - LOW_STOCK_WINDOW_MS;
    const alreadySent = (Array.isArray(recent) ? recent : []).some(
      (n) => n.title === title && new Date(n.created_date).getTime() >= cutoff
    );
    if (alreadySent) return Response.json({ sent: false, reason: 'already_sent' });

    const users = await base44.asServiceRole.entities.User.list();
    const recipients = [
      ...new Set(
        (Array.isArray(users) ? users : [])
          .filter((u) => u.role === 'admin' && u.email)
          .map((u) => u.email)
      ),
    ];
    if (recipients.length === 0) return Response.json({ sent: false, reason: 'no_admin_email' });

    const short = Math.max(min - qty, 0);
    const subject = `Digniin kayd: ${item.name} wuxuu gaadhay xadka ugu yar`;
    const lines = [
      `Alaabta "${item.name}"${item.location ? ` (${item.location})` : ''} ayaa gaadhay xadka ugu yar ee kaydka.`,
      '',
      `Tirada hadhay: ${qty}${item.unit ? ` ${item.unit}` : ''}`,
      `Xadka ugu yar: ${min}`,
      short > 0 ? `Ka dhiman: ${short}` : '',
      `Qaybta: ${item.category}`,
      '',
      'Fadlan dalbo alaab cusub intaysan gabaabsi noqon.',
    ].filter((line) => line !== '');
    const text = lines.join('\n');

    let sent = 0;
    for (const to of recipients) {
      try {
        await base44.asServiceRole.integrations.Core.SendEmail({ to, subject, body: text });
        sent += 1;
      } catch {
        // keep trying the remaining recipients
      }
    }

    await base44.asServiceRole.entities.Notification.create({
      title,
      message: `Alaabta "${item.name}" ayaa gaadhay xadka ugu yar — ${qty} ayaa hadhay (xadka ${min}).`,
      type: 'warning',
      is_read: false,
    });

    return Response.json({ sent: sent > 0, count: sent, recipients });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}