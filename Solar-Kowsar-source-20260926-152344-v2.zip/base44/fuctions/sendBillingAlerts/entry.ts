import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (user.role !== 'admin') return Response.json({ error: 'Forbidden - admin only' }, { status: 403 });

    const body = await req.json().catch(() => ({}));
    const statuses = Array.isArray(body.statuses) && body.statuses.length
      ? body.statuses
      : ['pending', 'overdue'];

    const [bills, customers] = await Promise.all([
      base44.asServiceRole.entities.Billing.list('-created_date', 2000),
      base44.asServiceRole.entities.Customer.list(),
    ]);

    const custMap = {};
    for (const c of customers) custMap[c.id] = c;

    const targets = bills.filter((b) => statuses.includes(b.status));

    let sent = 0;
    let skipped = 0;
    let failed = 0;
    const alerts = [];
    const notifsToCreate = [];

    for (const bill of targets) {
      const cust = custMap[bill.customer];
      if (!cust) { skipped++; continue; }

      const isOverdue = bill.status === 'overdue';
      const amount = Number(bill.total_amount || 0).toFixed(2);
      const subject = isOverdue
        ? `Digniin: Biilka ${bill.billing_month} waa dhafay`
        : `Xusuusin: Biilka ${bill.billing_month} ayaa soo socda`;
      const message = `Salaan ${cust.full_name}, biilka bisha ${bill.billing_month} ee mitaarka ${cust.meter_number || '-'} waa $${amount} (${bill.kwh_used || 0} kWh). ${isOverdue
        ? 'Fadlan bixi isla markiiba si aan korontada looga jarin.'
        : 'Fadlan bixi biilka waqtigiisa.'}`;

      alerts.push({
        customer: cust.full_name,
        email: cust.email || null,
        amount: bill.total_amount,
        status: bill.status,
      });

      const email = (cust.email || '').trim();
      if (email) {
        try {
          await base44.asServiceRole.integrations.Core.SendEmail({ to: email, subject, body: message });
          sent++;
        } catch (e) {
          failed++;
        }
      } else {
        skipped++;
      }

      notifsToCreate.push({
        title: subject,
        message,
        type: 'billing',
        customer: bill.customer,
        is_read: false,
      });
    }

    if (notifsToCreate.length > 0) {
      await base44.asServiceRole.entities.Notification.bulkCreate(notifsToCreate);
    }

    return Response.json({
      success: true,
      alerts_total: targets.length,
      sent,
      skipped,
      failed,
      alerts,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}