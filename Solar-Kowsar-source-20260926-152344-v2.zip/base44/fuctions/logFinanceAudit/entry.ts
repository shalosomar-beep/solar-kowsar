import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

// Writes a financial audit entry. The "performed by" identity is taken from the
// authenticated session server-side, so a client cannot forge who did what.
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const action = typeof body?.action === 'string' ? body.action.trim().slice(0, 120) : '';
    if (!action) return Response.json({ error: 'action is required' }, { status: 400 });

    const record = await base44.asServiceRole.entities.AuditLog.create({
      action,
      category: 'finance',
      details: typeof body?.details === 'string' ? body.details.slice(0, 500) : '',
      amount: Number(body?.amount) || 0,
      target_email: typeof body?.target === 'string' ? body.target.slice(0, 200) : '',
      performed_by_email: user.email,
      performed_by_name: user.full_name || user.email,
      timestamp: new Date().toISOString(),
    });

    return Response.json({ ok: true, id: record?.id });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}