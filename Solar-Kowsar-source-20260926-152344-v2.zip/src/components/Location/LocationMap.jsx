import React from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { MapPin } from "lucide-react";

const markerIcon = L.divIcon({
  className: "",
  html: `<div style="width:26px;height:26px;border-radius:50% 50% 50% 0;transform:rotate(-45deg);background:#f59e0b;border:2px solid #ffffff;box-shadow:0 2px 6px rgba(0,0,0,0.5)"></div>`,
  iconSize: [26, 26],
  iconAnchor: [13, 26],
  popupAnchor: [0, -26],
});

export default function LocationMap({ locations }) {
  const pinned = locations.filter(
    (l) => typeof l.latitude === "number" && typeof l.longitude === "number"
  );

  const center = pinned.length
    ? [
        pinned.reduce((s, l) => s + l.latitude, 0) / pinned.length,
        pinned.reduce((s, l) => s + l.longitude, 0) / pinned.length,
      ]
    : [5.1521, 46.1996];

  return (
    <div className="relative rounded-2xl overflow-hidden border border-zinc-800/50" style={{ height: 520 }}>
      <MapContainer
        center={center}
        zoom={pinned.length ? 6 : 5}
        scrollWheelZoom
        style={{ height: "100%", width: "100%" }}
      >
        <TileLayer
          className="map-tiles-dark"
          attribution='&copy; OpenStreetMap contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {pinned.map((l) => (
          <Marker key={l.id} position={[l.latitude, l.longitude]} icon={markerIcon}>
            <Popup>
              <strong>{l.name}</strong>
              <br />
              {l.city}
              {l.address ? `, ${l.address}` : ""}
              {l.total_capacity_kw ? (
                <>
                  <br />
                  {l.total_capacity_kw} KW · {l.total_panels || 0} panels
                </>
              ) : null}
            </Popup>
          </Marker>
        ))}
      </MapContainer>

      {pinned.length === 0 && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="rounded-xl bg-zinc-900/90 border border-zinc-800 px-5 py-4 text-center max-w-xs">
            <MapPin className="w-6 h-6 mx-auto mb-2 text-amber-400" />
            <p className="text-white text-sm font-medium">Goobaha khariidadda lama dhigin</p>
            <p className="text-zinc-400 text-xs mt-1">Kudar latitude iyo longitude goob kasta si ay khariidadda uga soo muuqato.</p>
          </div>
        </div>
      )}
    </div>
  );
}