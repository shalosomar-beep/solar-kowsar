import React, { useRef } from "react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
} from "recharts";
import { DollarSign } from "lucide-react";
import { useT } from "@/lib/i18n";
import ChartExportMenu from "@/components/Chart/ChartExportMenu";

export default function MonthlyRevenueChart({ data }) {
  const { t } = useT();
  const chartRef = useRef(null);

  return (
    <div className="rounded-2xl bg-card border border-border p-6">
      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3 mb-1">
        <div>
          <h3 className="text-foreground font-semibold flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-amber-400" />
            {t("revdash.chart.revenue.title")}
          </h3>
          <p className="text-muted-foreground text-xs mt-1">{t("revdash.chart.revenue.sub")}</p>
        </div>
        <ChartExportMenu
          chartRef={chartRef}
          filename="dakhliga-bishii"
          columns={[
            t("chart.col.date"),
            t("revdash.chart.legend.billed"),
            t("revdash.chart.legend.collected"),
          ]}
          rows={data.map((d) => [d.name, d.billed, d.collected])}
        />
      </div>

      <div className="h-64 mt-4" ref={chartRef}>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} />
            <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
            <Tooltip
              formatter={(v) => `$${v}`}
              contentStyle={{
                background: "hsl(var(--popover))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "12px",
                color: "hsl(var(--popover-foreground))",
              }}
              labelStyle={{ color: "hsl(var(--muted-foreground))" }}
            />
            <Legend wrapperStyle={{ fontSize: 12 }} />
            <Bar
              dataKey="billed"
              name={t("revdash.chart.legend.billed")}
              fill="#f59e0b"
              radius={[8, 8, 0, 0]}
            />
            <Bar
              dataKey="collected"
              name={t("revdash.chart.legend.collected")}
              fill="#10b981"
              radius={[8, 8, 0, 0]}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}