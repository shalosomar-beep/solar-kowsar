import React from "react";
import { DollarSign, Zap, Sun } from "lucide-react";
import { useT } from "@/lib/i18n";

const money = (v) => `$${(v || 0).toLocaleString(undefined, { maximumFractionDigits: 2 })}`;
const kwh = (v) => `${(v || 0).toLocaleString(undefined, { maximumFractionDigits: 1 })} kWh`;

function Group({ title, icon: Icon, accent, children }) {
  return (
    <div className="rounded-2xl bg-card border border-border p-4">
      <div className={`flex items-center gap-2 ${accent}`}>
        <Icon className="w-4 h-4" />
        <h3 className="text-xs font-semibold uppercase tracking-wider">{title}</h3>
      </div>
      <div className="mt-3 space-y-2.5">{children}</div>
    </div>
  );
}

function Row({ label, value, strong, tone }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-xs text-muted-foreground">{label}</span>
      <span
        className={`${strong ? "text-lg font-bold" : "text-sm font-semibold"} ${
          tone || "text-foreground"
        }`}
      >
        {value}
      </span>
    </div>
  );
}

export default function SummaryCards({ revenue, consumption, energy }) {
  const { t } = useT();

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      <Group title={t("revdash.group.revenue")} icon={DollarSign} accent="text-amber-400">
        <Row
          label={t("revdash.collected")}
          value={money(revenue.collected)}
          strong
          tone="text-emerald-400"
        />
        <Row label={t("revdash.billed")} value={money(revenue.billed)} />
        <Row label={t("revdash.pending")} value={money(revenue.pending)} tone="text-red-400" />
        <Row label={t("revdash.collectionRate")} value={`${revenue.rate.toFixed(1)}%`} />
      </Group>

      <Group title={t("revdash.group.consumption")} icon={Zap} accent="text-cyan-400">
        <Row
          label={t("revdash.totalUsage")}
          value={kwh(consumption.total)}
          strong
          tone="text-cyan-400"
        />
        <Row label={t("revdash.estimated")} value={kwh(consumption.estimated)} />
        <Row label={t("revdash.dailyAvg")} value={kwh(consumption.dailyAvg)} />
        <Row label={t("revdash.customers")} value={consumption.customers} />
      </Group>

      <Group title={t("revdash.group.energy")} icon={Sun} accent="text-orange-400">
        <Row
          label={t("revdash.produced")}
          value={kwh(energy.produced)}
          strong
          tone="text-orange-400"
        />
        <Row label={t("revdash.sold")} value={kwh(energy.sold)} tone="text-emerald-400" />
        <Row label={t("revdash.coverage")} value={`${energy.coverage.toFixed(1)}%`} />
        <Row
          label={t("revdash.diff")}
          value={kwh(energy.diff)}
          tone={energy.diff < 0 ? "text-red-400" : "text-foreground"}
        />
      </Group>
    </div>
  );
}