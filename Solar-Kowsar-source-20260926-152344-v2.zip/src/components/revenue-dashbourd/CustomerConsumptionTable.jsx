import React from "react";
import { Zap, Users } from "lucide-react";
import { useT } from "@/lib/i18n";

const kwh = (v) => `${(v || 0).toLocaleString(undefined, { maximumFractionDigits: 1 })} kWh`;

const BADGE = {
  meter: "bg-cyan-500/15 text-cyan-400 border-cyan-500/25",
  estimated: "bg-amber-500/15 text-amber-400 border-amber-500/25",
  none: "bg-zinc-500/15 text-zinc-400 border-zinc-500/25",
};

export default function CustomerConsumptionTable({ rows }) {
  const { t } = useT();

  return (
    <div className="rounded-2xl bg-card border border-border p-6">
      <h3 className="text-foreground font-semibold flex items-center gap-2">
        <Zap className="w-4 h-4 text-cyan-400" />
        {t("revdash.table.title")}
      </h3>
      <p className="text-muted-foreground text-xs mt-1 mb-4">{t("revdash.table.sub")}</p>

      {rows.length === 0 ? (
        <div className="py-12 text-center text-muted-foreground">
          <Users className="w-10 h-10 mx-auto mb-3 opacity-30" />
          <p className="text-sm">{t("revdash.table.empty")}</p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-muted-foreground text-xs uppercase tracking-wider">
                <th className="text-left py-3 font-medium">{t("revdash.table.customer")}</th>
                <th className="text-right py-3 font-medium">{t("revdash.table.used")}</th>
                <th className="text-right py-3 font-medium">{t("revdash.table.estimate")}</th>
                <th className="text-right py-3 font-medium">{t("revdash.table.type")}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {rows.map((r) => {
                const type = !r.hasReading ? "none" : r.estimated ? "estimated" : "meter";
                return (
                  <tr key={r.id} className="hover:bg-accent/40 transition-colors">
                    <td className="py-3 text-foreground font-medium">{r.name}</td>
                    <td className="py-3 text-right text-foreground">{kwh(r.kwh)}</td>
                    <td className="py-3 text-right text-muted-foreground">{kwh(r.projected)}</td>
                    <td className="py-3 text-right">
                      <span
                        className={`inline-flex px-2.5 py-1 rounded-full text-[10px] font-semibold border ${BADGE[type]}`}
                      >
                        {t(`revdash.reading.${type}`)}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}