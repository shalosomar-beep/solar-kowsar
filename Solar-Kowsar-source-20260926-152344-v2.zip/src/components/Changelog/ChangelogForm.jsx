import React, { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useT } from "@/lib/i18n";

const CATEGORIES = ["feature", "fix", "improvement", "security"];
const STATUSES = ["released", "planned"];

const emptyForm = () => ({
  version: "",
  title: "",
  description: "",
  category: "feature",
  status: "released",
  release_date: new Date().toISOString().slice(0, 10),
});

export default function ChangelogForm({ open, onOpenChange, initial, onSave, saving }) {
  const { t } = useT();
  const [form, setForm] = useState(emptyForm());

  useEffect(() => {
    if (!open) return;
    setForm(
      initial
        ? {
            version: initial.version || "",
            title: initial.title || "",
            description: initial.description || "",
            category: initial.category || "feature",
            status: initial.status || "released",
            release_date: initial.release_date || "",
          }
        : emptyForm()
    );
  }, [open, initial]);

  const set = (key, value) => setForm((f) => ({ ...f, [key]: value }));

  const submit = (e) => {
    e.preventDefault();
    if (!form.version.trim() || !form.title.trim()) return;
    onSave(form);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{initial ? t("changelog.form.edit") : t("changelog.form.new")}</DialogTitle>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>{t("changelog.field.version")}</Label>
              <Input
                value={form.version}
                onChange={(e) => set("version", e.target.value)}
                placeholder="1.0.2"
                required
              />
            </div>
            <div className="space-y-1.5">
              <Label>{t("changelog.field.date")}</Label>
              <Input
                type="date"
                value={form.release_date}
                onChange={(e) => set("release_date", e.target.value)}
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>{t("changelog.field.title")}</Label>
            <Input value={form.title} onChange={(e) => set("title", e.target.value)} required />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>{t("changelog.field.category")}</Label>
              <Select value={form.category} onValueChange={(v) => set("category", v)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((c) => (
                    <SelectItem key={c} value={c}>
                      {t(`changelog.cat.${c}`)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>{t("changelog.field.status")}</Label>
              <Select value={form.status} onValueChange={(v) => set("status", v)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {STATUSES.map((s) => (
                    <SelectItem key={s} value={s}>
                      {t(`changelog.status.${s}`)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>{t("changelog.field.description")}</Label>
            <Textarea
              rows={4}
              value={form.description}
              onChange={(e) => set("description", e.target.value)}
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              {t("common.cancel")}
            </Button>
            <Button
              type="submit"
              disabled={saving}
              className="bg-orange-500 hover:bg-orange-600 text-white"
            >
              {saving ? t("common.saving") : t("common.save")}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}