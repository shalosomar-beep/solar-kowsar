import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Receipt, CheckCircle2, Wrench, Bell, Gauge } from "lucide-react";

const KIND = {
  bill_created: {
    label: "Biil",
    icon: Receipt,
    chip: "bg-amber-500/10 border-amber-500/20 text-amber-400",
  },
  bill_paid: {
    label: "Lacag Bixin",
    icon: CheckCircle2,
    chip: "bg-emerald-500/10 border-emerald-500/20 text-emerald-400",
  },
  visit: {
    label: "Booqasho Farsamayaqaan",
    icon: Wrench,
    chip: "bg-blue-500/10 border-blue-500/20 text-blue-400",
  },
  notification: {
    label: "Ogeysiis",
    icon: Bell,
    chip: "bg-purple-500/10 border-purple-500/20 text-purple-400",
  },
  meter: {
    label: "Meter",
    icon: Gauge,
    chip: "bg-cyan-500/10 border-cyan-500/20 text-cyan-400",
  },
};

const TASK_STATUS = {
  open: "Furan",
  assigned: "La Xilsaaray",
  in_progress: "Socda",
  completed: "Dhammaaday",
};

const METER_TYPE = {
  smart: "Smart",
  single_phase: "Hal Waji",
  three_phase: "Saddex Waji",
  prepaid: "Prepaid",
};

const fmt = (v) => {
  if (!v) return "—";
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return String(v);
  return d.toLocaleDateString("so-SO", { day: "numeric", month: "short", year: "numeric" });
};

const ts = (v) => {
  const t = new Date(v || 0).getTime();
  return Number.isNaN(t) ? 0 : t;
};

export default function CustomerTimeline({ customer }) {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    setLoading(true);
    (async () => {
      const [bills, tasks, notifs, meters, staff] = await Promise.all([
        base44.entities.Billing.filter({ customer: customer.id }).catch(() => []),
        base44.entities.Task.filter({ customer: customer.id }).catch(() => []),
        base44.entities.Notification.filter({ customer: customer.id }).catch(() => []),
        base44.entities.Meter.filter({ customer: customer.id }).catch(() => []),
        base44.entities.Staff.list().catch(() => []),
      ]);
      if (!active) return;

      const techName = (id) => staff.find((s) => s.id === id)?.full_name || "Lama xilsaarin";
      const list = [];

      bills.forEach((b) => {
        list.push({
          id: `bill-${b.id}`,
          date: b.created_date,
          sort: ts(b.created_date),
          kind: "bill_created",
          title: `Biil la soo saaray${b.billing_month ? ` — ${b.billing_month}` : ""}`,
          detail: `$${Number(b.total_amount || 0).toLocaleString()} · ${b.kwh_used ?? 0} kWh`,
        });
        if (b.payment_date) {
          list.push({
            id: `pay-${b.id}`,
            date: b.payment_date,
            sort: ts(b.payment_date),
            kind: "bill_paid",
            title: `Lacag la bixiyay${b.billing_month ? ` — ${b.billing_month}` : ""}`,
            detail: `$${Number(b.total_amount || 0).toLocaleString()}`,
          });
        }
      });

      tasks.forEach((t) => {
        const tech = techName(t.technician);
        list.push({
          id: `task-${t.id}`,
          date: t.due_date || t.created_date,
          sort: ts(t.due_date || t.created_date),
          kind: "visit",
          title: t.title || "Booqasho",
          detail: `${tech} · ${TASK_STATUS[t.status] || t.status || ""}`,
          tech,
        });
      });

      notifs.forEach((n) => {
        list.push({
          id: `notif-${n.id}`,
          date: n.created_date,
          sort: ts(n.created_date),
          kind: "notification",
          title: n.title || "Ogeysiis",
          detail: n.message || "",
        });
      });

      meters.forEach((m) => {
        list.push({
          id: `meter-${m.id}`,
          date: m.install_date,
          sort: ts(m.install_date),
          kind: "meter",
          title: `Meter la dhigay${m.serial_number ? ` — ${m.serial_number}` : ""}`,
          detail: [METER_TYPE[m.meter_type] || m.meter_type, m.location].filter(Boolean).join(" · "),
        });
      });

      list.sort((a, b) => b.sort - a.sort);
      setEvents(list);
      setLoading(false);
    })();
    return () => {
      active = false;
    };
  }, [customer.id]);

  const lastPayment = events.find((e) => e.kind === "bill_paid");
  const lastVisit = events.find((e) => e.kind === "visit");

  return (
    <div className="rounded-2xl bg-zinc-900/50 border border-zinc-800/50">
      <div className="p-5 border-b border-zinc-800/50 flex items-center justify-between">
        <h3 className="text-white font-semibold">Diiwaanka Taariikhda Macmiilka</h3>
        <span className="text-zinc-500 text-xs">{events.length} dhacdo</span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-5 pb-0">
        <div className="rounded-xl bg-zinc-800/40 border border-zinc-800 p-3">
          <p className="text-zinc-400 text-xs">Lacagta Ugu Dambaysa</p>
          <p className="text-white text-sm font-semibold mt-1">
            {lastPayment ? `${fmt(lastPayment.date)} · ${lastPayment.detail}` : "Wali lama bixin"}
          </p>
        </div>
        <div className="rounded-xl bg-zinc-800/40 border border-zinc-800 p-3">
          <p className="text-zinc-400 text-xs">Booqashada Farsamayaqaanka Ugu Dambaysa</p>
          <p className="text-white text-sm font-semibold mt-1">
            {lastVisit ? `${lastVisit.tech} · ${fmt(lastVisit.date)}` : "Booqasho ma jirto"}
          </p>
        </div>
      </div>

      {loading ? (
        <div className="py-12 flex justify-center">
          <div className="w-7 h-7 border-4 border-amber-500/30 border-t-amber-500 rounded-full animate-spin" />
        </div>
      ) : events.length === 0 ? (
        <div className="p-10 text-center text-zinc-500 text-sm">
          Wali dhacdo lama diiwaangelin macmiilkan.
        </div>
      ) : (
        <ol className="p-5">
          {events.map((e, i) => {
            const meta = KIND[e.kind] || KIND.notification;
            const Icon = meta.icon;
            return (
              <li key={e.id} className="flex gap-3">
                <div className="flex flex-col items-center">
                  <span className={`w-8 h-8 rounded-full border flex items-center justify-center shrink-0 ${meta.chip}`}>
                    <Icon className="w-4 h-4" />
                  </span>
                  {i < events.length - 1 && <span className="w-px flex-1 bg-zinc-800 my-1" />}
                </div>
                <div className="pb-5 flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-3">
                    <p className="text-white text-sm font-medium">{e.title}</p>
                    <p className="text-zinc-500 text-xs whitespace-nowrap">{fmt(e.date)}</p>
                  </div>
                  {e.detail && <p className="text-zinc-400 text-xs mt-0.5">{e.detail}</p>}
                  <span className={`inline-block text-[10px] mt-1.5 px-2 py-0.5 rounded-full border ${meta.chip}`}>
                    {meta.label}
                  </span>
                </div>
              </li>
            );
          })}
        </ol>
      )}
    </div>
  );
}