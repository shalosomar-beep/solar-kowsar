import React, { useState, useEffect, useRef } from "react";
import { MessageCircle, X, Send, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useT } from "@/lib/i18n";
import ChatBubble from "./ChatBubble";

const SYSTEM_CONTEXT = `You are "Caawiyaha QoraxSolar", the built-in assistant of Solar Kowsar Somalia — a solar energy management and rental platform for Somali households and businesses.

Modules of the system (Somali names shown in the sidebar):
- Bogga Hore: dashboard with production, customers, meters, billing totals.
- Macaamiisha: customer records (phone, meter number, solar capacity, status, meter online/offline).
- Qaybaha Macaamiisha: customer segmentation.
- Billing / Biilasha: monthly bills (kWh used, rate, total, paid/pending/overdue), auto-generate bills, reminders.
- Lacagaha: payments. Kharashaadka: expenses. Warbixin: profit & loss.
- Qalabka: equipment inventory (battery, inverter, panel, generator, smart meter) with warehouse/installed state.
- Baytariyada: battery storage health. Xogta Qoraxda: solar production data.
- Lumitaanka Tamarta: grid loss analytics. Shabakada Qeybinta: substations and transformers load.
- Kaarboonka: carbon / CO2 tracking. Talooyinka Tamarta: AI energy efficiency advice.
- Dayactir: maintenance requests. Jadwalka: scheduling & dispatch. Hawlaha: tasks.
- Shaqaalaha: staff. Heshiisyada: contracts & SLA. Dukumentiyada: documents. KYC: identity verification.
- Iibsashada: procurement / purchase orders. Aqoonta: knowledge base. Caawinaad: support tickets.
- Ciladaha: alarms. Saadaasha Cimilada: weather & yield forecast.

Answer in the same language the user writes in (Somali, English or Arabic). Be concise (under 120 words), practical and friendly.
Write plain text only — no markdown symbols such as asterisks, hash signs or backticks.
Never invent real numbers, customers or bills — you cannot see the database. If asked about specific figures, tell the user which page shows them instead.
For anything about the custom domain, HTTPS or app settings, tell them it is handled in the app dashboard (Domains / App Settings).`;

export default function HelpChatWidget() {
  const { t } = useT();
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState([]);
  const [busy, setBusy] = useState(false);
  const endRef = useRef(null);

  useEffect(() => {
    if (open && messages.length === 0) {
      setMessages([{ role: "assistant", content: t("chat.greeting") }]);
    }
  }, [open, messages.length, t]);

  useEffect(() => {
    if (endRef.current) endRef.current.scrollIntoView({ block: "end" });
  }, [messages, busy, open]);

  const send = async (preset) => {
    const value = (preset ?? input).trim();
    if (!value || busy) return;

    const next = [...messages, { role: "user", content: value }];
    setMessages(next);
    setInput("");
    setBusy(true);

    try {
      const history = next
        .slice(-6)
        .map((m) => `${m.role === "user" ? "User" : "Assistant"}: ${m.content}`)
        .join("\n");
      const reply = await base44.integrations.Core.InvokeLLM({
        prompt: `${SYSTEM_CONTEXT}\n\nConversation so far:\n${history}\n\nAssistant:`,
      });
      const text = String(reply || "").trim() || t("chat.error");
      setMessages((prev) => [...prev, { role: "assistant", content: text }]);
    } catch (e) {
      setMessages((prev) => [...prev, { role: "assistant", content: t("chat.error") }]);
    } finally {
      setBusy(false);
    }
  };

  const suggestions = [t("chat.s1"), t("chat.s2"), t("chat.s3")];

  return (
    <>
      <button
        onClick={() => setOpen((o) => !o)}
        title={t("chat.title")}
        className="fixed bottom-5 end-5 z-40 w-12 h-12 rounded-full bg-amber-500 hover:bg-amber-600 text-black shadow-xl flex items-center justify-center transition-transform hover:scale-105"
      >
        {open ? <X className="w-5 h-5" /> : <MessageCircle className="w-5 h-5" />}
      </button>

      {open && (
        <div className="fixed bottom-20 end-5 z-40 w-[calc(100vw-2.5rem)] sm:w-96 h-[30rem] max-h-[72vh] rounded-2xl bg-popover border border-border shadow-2xl flex flex-col overflow-hidden">
          <div className="flex items-center gap-2.5 px-4 py-3 bg-amber-500/10 border-b border-border">
            <span className="w-8 h-8 rounded-full bg-amber-500 text-black flex items-center justify-center">
              <MessageCircle className="w-4 h-4" />
            </span>
            <div className="min-w-0">
              <p className="text-xs font-bold text-foreground truncate">{t("chat.title")}</p>
              <p className="text-[10px] text-muted-foreground truncate">{t("chat.subtitle")}</p>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-3 space-y-3">
            {messages.map((m, i) => (
              <ChatBubble key={i} role={m.role} content={m.content} />
            ))}
            {busy && (
              <div className="flex items-center gap-2 text-[11px] text-muted-foreground ps-8">
                <Loader2 className="w-3 h-3 animate-spin" /> {t("chat.thinking")}
              </div>
            )}
            <div ref={endRef} />
          </div>

          {messages.length <= 1 && !busy && (
            <div className="px-3 pb-2 flex flex-wrap gap-1.5">
              {suggestions.map((s) => (
                <button
                  key={s}
                  onClick={() => send(s)}
                  className="px-2.5 py-1.5 rounded-full bg-accent hover:bg-accent/70 border border-border text-[11px] text-muted-foreground transition-colors"
                >
                  {s}
                </button>
              ))}
            </div>
          )}

          <div className="flex items-center gap-2 p-3 border-t border-border">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") send(); }}
              placeholder={t("chat.placeholder")}
              className="flex-1 px-3 py-2 rounded-lg bg-card border border-border text-foreground text-xs outline-none focus:ring-1 focus:ring-ring placeholder:text-muted-foreground"
            />
            <button
              onClick={() => send()}
              disabled={busy || !input.trim()}
              title={t("chat.send")}
              className="w-9 h-9 shrink-0 rounded-lg bg-amber-500 hover:bg-amber-600 disabled:opacity-40 text-black flex items-center justify-center transition-colors"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </>
  );
}