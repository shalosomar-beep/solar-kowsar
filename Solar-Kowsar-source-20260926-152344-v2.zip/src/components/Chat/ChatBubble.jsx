import React from "react";
import { Bot } from "lucide-react";

export default function ChatBubble({ role, content }) {
  const isUser = role === "user";

  return (
    <div className={`flex gap-2 ${isUser ? "justify-end" : "justify-start"}`}>
      {!isUser && (
        <span className="w-6 h-6 shrink-0 rounded-full bg-amber-500/15 text-amber-500 flex items-center justify-center">
          <Bot className="w-3.5 h-3.5" />
        </span>
      )}
      <div
        className={`max-w-[82%] px-3 py-2 text-xs leading-relaxed whitespace-pre-wrap ${
          isUser
            ? "bg-amber-500 text-black rounded-2xl rounded-br-sm"
            : "bg-accent text-foreground rounded-2xl rounded-bl-sm"
        }`}
      >
        {content}
      </div>
    </div>
  );
}