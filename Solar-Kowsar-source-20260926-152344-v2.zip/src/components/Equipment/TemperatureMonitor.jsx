import React, { useEffect, useMemo, useRef, useState } from "react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Thermometer, AlertTriangle } from "lucide-react";
import TempTile, { tempLevel, tempLimit } from "@/components/equipment/TempTile";
import { notifyEquipmentTemperature, createTemperatureMaintenanceRequest } from "@/lib/alertNotifications";
import { useT } from "@/lib/i18n";

export default function TemperatureMonitor({ items = [] }) {
  const { t } = useT();
  const { toast } = useToast();
  const [liveTemps, setLiveTemps] = useState({});
  // Last known heat level per equipment, so an alert only fires when it worsens.
  const levels = useRef({});

  useEffect(() => {
    items.forEach((item) => {
      if (item.temperature == null || levels.current[item.id] !== undefined) return;
      const level = tempLevel(item.temperature, item.category).key;
      levels.current[item.id] = level;
      // Equipment that is already running hot still needs a maintenance ticket.
      if (level !== "ok") createTemperatureMaintenanceRequest(item, item.temperature);
    });
  }, [items]);

  // Live feed: any temperature change saved in the system updates this panel at once.
  useEffect(() => {
    const unsubscribe = base44.entities.Equipment.subscribe((event) => {
      if (event.type === "delete") {
        delete levels.current[event.id];
        return;
      }
      const temp = event.data?.temperature ?? null;
      setLiveTemps((prev) => ({ ...prev, [event.id]: temp }));
      if (temp == null) {
        delete levels.current[event.id];
        return;
      }
      const limit = tempLimit(event.data?.category);
      const level = tempLevel(temp, event.data?.category).key;
      const previous = levels.current[event.id];
      levels.current[event.id] = level;
      // Alert only when the heat level worsens (normal → high → critical).
      if (level === "ok" || level === previous) return;

      toast({
        variant: "destructive",
        title: t("equip2.temp.toast.title"),
        description: t("equip2.temp.toast.desc", {
          name: event.data?.name || "",
          temp,
          limit: limit.max,
        }),
      });
      notifyEquipmentTemperature(event.data, temp);
      createTemperatureMaintenanceRequest(event.data, temp).then((request) => {
        if (request) {
          toast({ title: t("equip2.temp.maintenance.created"), description: request.title });
        }
      });
    });
    return unsubscribe;
  }, [t, toast]);

  const monitored = useMemo(
    () =>
      items
        .map((item) => ({
          ...item,
          temp: Object.prototype.hasOwnProperty.call(liveTemps, item.id) ? liveTemps[item.id] : item.temperature,
        }))
        .filter((item) => item.temp != null)
        .sort((a, b) => b.temp - a.temp),
    [items, liveTemps]
  );

  const alerts = monitored.filter((i) => tempLevel(i.temp, i.category).key !== "ok");
  const critical = alerts.filter((i) => tempLevel(i.temp, i.category).key === "critical");

  return (
    <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-5 space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-orange-500/15 text-orange-400 shrink-0">
            <Thermometer className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-white font-semibold text-base">{t("equip2.temp.title")}</h2>
            <p className="text-zinc-400 text-xs mt-0.5">{t("equip2.temp.subtitle")}</p>
          </div>
        </div>
        <div className="flex items-center gap-3 shrink-0">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-500/15 text-emerald-400">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            {t("equip2.temp.live")}
          </span>
          <span className="text-xs text-zinc-500">{t("equip2.temp.monitored", { count: monitored.length })}</span>
        </div>
      </div>

      {alerts.length > 0 && (
        <div className={`flex items-start gap-3 rounded-xl border p-3 ${critical.length ? "bg-red-500/10 border-red-500/30" : "bg-amber-500/10 border-amber-500/30"}`}>
          <AlertTriangle className={`w-5 h-5 shrink-0 mt-0.5 ${critical.length ? "text-red-400" : "text-amber-400"}`} />
          <div className="min-w-0">
            <p className={`text-sm font-semibold ${critical.length ? "text-red-400" : "text-amber-400"}`}>
              {t("equip2.temp.alert", { count: alerts.length })}
            </p>
            <p className="text-xs text-zinc-400 mt-0.5 truncate">
              {alerts.slice(0, 4).map((a) => `${a.name} ${a.temp}°C`).join(" · ")}
            </p>
          </div>
        </div>
      )}

      {monitored.length === 0 ? (
        <p className="text-sm text-zinc-500 py-6 text-center">{t("equip2.temp.empty")}</p>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
          {monitored.map((item) => (
            <TempTile key={item.id} item={item} />
          ))}
        </div>
      )}
    </div>
  );
}