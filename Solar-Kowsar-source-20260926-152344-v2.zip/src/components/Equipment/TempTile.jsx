import React from "react";
import { Flame } from "lucide-react";
import { CATEGORY_META } from "@/components/equipment/EquipmentCard";
import { useT } from "@/lib/i18n";

// Normal operating ceiling (°C) per equipment category.
export const TEMP_LIMITS = {
  battery: { max: 45, critical: 55 },
  inverter: { max: 60, critical: 70 },
  solar_panel: { max: 70, critical: 85 },
  generator: { max: 85, critical: 100 },
  smart_meter: { max: 55, critical: 65 },
};

export const DEFAULT_LIMIT = { max: 60, critical: 75 };

export function tempLimit(category) {
  return TEMP_LIMITS[category] || DEFAULT_LIMIT;
}

export function tempLevel(temp, category) {
  const limit = tempLimit(category);
  if (temp >= limit.critical) {
    return { key: "critical", labelKey: "equip2.temp.critical", text: "text-red-400", badge: "bg-red-500/15 text-red-400", bar: "bg-red-500", card: "border-red-500/40 bg-red-500/5" };
  }
  if (temp >= limit.max) {
    return { key: "warning", labelKey: "equip2.temp.warning", text: "text-amber-400", badge: "bg-amber-500/15 text-amber-400", bar: "bg-amber-500", card: "border-amber-500/40 bg-amber-500/5" };
  }
  return { key: "ok", labelKey: "equip2.temp.normal", text: "text-emerald-400", badge: "bg-emerald-500/15 text-emerald-400", bar: "bg-emerald-500", card: "border-zinc-800 bg-zinc-900/40" };
}

export default function TempTile({ item }) {
  const { t } = useT();
  const cat = CATEGORY_META[item.category] || CATEGORY_META.battery;
  const limit = tempLimit(item.category);
  const level = tempLevel(item.temp, item.category);
  const Icon = cat.icon;
  const pct = Math.min(100, Math.round((item.temp / limit.critical) * 100));

  return (
    <div className={`rounded-xl border p-3 ${level.card}`}>
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <Icon className="w-4 h-4 shrink-0" style={{ color: cat.color }} />
          <div className="min-w-0">
            <p className="text-white text-sm font-medium truncate">{item.name}</p>
            <p className="text-zinc-500 text-[11px] truncate">
              {t(cat.labelKey)}{item.location ? ` · ${item.location}` : ""}
            </p>
          </div>
        </div>
        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium shrink-0 ${level.badge}`}>
          {level.key !== "ok" && <Flame className="w-3 h-3" />}
          {t(level.labelKey)}
        </span>
      </div>

      <div className="flex items-end justify-between mt-3">
        <span className={`text-2xl font-bold ${level.text}`}>{item.temp}°C</span>
        <span className="text-[11px] text-zinc-500">{t("equip2.temp.limit")}: {limit.max}°C</span>
      </div>

      <div className="mt-2 h-1.5 rounded-full bg-zinc-800 overflow-hidden">
        <div className={`h-full rounded-full ${level.bar}`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}