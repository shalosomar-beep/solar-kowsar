import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import { useToast } from "@/components/ui/use-toast";
import { BellRing, Loader2 } from "lucide-react";

// Sends email + in-app reminders for bills that are still pending or already overdue.
export default function BillingAlertsButton({ pendingCount, overdueCount, onSent }) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [sending, setSending] = useState(false);
  const total = (pendingCount || 0) + (overdueCount || 0);

  const send = async () => {
    setSending(true);
    try {
      const res = await base44.functions.invoke("sendBillingAlerts", { statuses: ["pending", "overdue"] });
      const d = res.data || {};
      toast({
        title: "Ogeysiisyada waa la diray",
        description: `${d.sent || 0} email la diray · ${d.skipped || 0} la booday · ${d.failed || 0} fashilmay`,
      });
      setOpen(false);
      if (onSent) onSent();
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Ogeysiisyada lama dirin karin" });
    } finally {
      setSending(false);
    }
  };

  return (
    <>
      <Button
        onClick={() => setOpen(true)}
        disabled={total === 0}
        className="gap-2 bg-orange-500 hover:bg-orange-600 text-white"
      >
        <BellRing className="w-4 h-4" /> Digniino Biilasha
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="bg-zinc-900 border-zinc-800 text-white">
          <DialogHeader>
            <DialogTitle>Dir Digniinaha Biilasha</DialogTitle>
            <DialogDescription className="text-zinc-400">
              Macaamiisha biilashooda aan bixin waxaa loo diri doonaa email xusuusin ah, iyo ogeysiis gudaha nidaamka.
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-3 py-2">
            <div className="rounded-xl bg-amber-500/10 border border-amber-500/20 p-4">
              <p className="text-zinc-400 text-xs uppercase tracking-wider">Soo Socda</p>
              <p className="text-2xl font-bold text-amber-400">{pendingCount || 0}</p>
            </div>
            <div className="rounded-xl bg-red-500/10 border border-red-500/20 p-4">
              <p className="text-zinc-400 text-xs uppercase tracking-wider">Dhafay</p>
              <p className="text-2xl font-bold text-red-400">{overdueCount || 0}</p>
            </div>
          </div>
          <p className="text-zinc-500 text-xs">
            Macaamiisha aan email lahayn waxaa kaliya loo abuuri doonaa ogeysiis gudaha ah.
          </p>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)} className="border-zinc-700 text-zinc-300">
              Jooji
            </Button>
            <Button onClick={send} disabled={sending} className="bg-orange-500 hover:bg-orange-600 text-white">
              {sending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <BellRing className="w-4 h-4 mr-2" />}
              Dir {total} Digniin
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}