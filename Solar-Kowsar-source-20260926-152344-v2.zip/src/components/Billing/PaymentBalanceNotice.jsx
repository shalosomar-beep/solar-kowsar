import React from "react";
import { CheckCircle2, Wallet, X } from "lucide-react";
import { useT } from "@/lib/i18n";

// Shown right after a payment is confirmed: it tells the operator how much this
// customer still owes, or that nothing is left on their account.
export default function PaymentBalanceNotice({ result, onClose }) {
  const { t } = useT();
  if (!result) return null;

  const settled = result.remaining <= 0;

  return (
    <div
      className={`rounded-2xl border p-4 flex items-start justify-between gap-4 ${
        settled ? "bg-emerald-500/10 border-emerald-500/20" : "bg-amber-500/10 border-amber-500/20"
      }`}
    >
      <div className="flex items-start gap-3">
        <CheckCircle2 className={`w-5 h-5 mt-0.5 shrink-0 ${settled ? "text-emerald-400" : "text-amber-400"}`} />
        <div>
          <p className="text-white text-sm font-medium">
            {t("billing.remaining.paid", {
              name: result.name,
              amount: result.paid.toFixed(2),
              month: result.month,
            })}
          </p>
          {settled ? (
            <p className="text-emerald-400 text-xs mt-1">{t("billing.remaining.clear")}</p>
          ) : (
            <p className="text-amber-400 text-xs mt-1 flex items-center gap-1.5">
              <Wallet className="w-3.5 h-3.5" />
              {t("billing.remaining.left")}:{" "}
              <span className="font-semibold">${result.remaining.toFixed(2)}</span>
            </p>
          )}
        </div>
      </div>
      <button
        type="button"
        onClick={onClose}
        aria-label={t("common.close")}
        className="text-zinc-400 hover:text-white shrink-0"
      >
        <X className="w-4 h-4" />
      </button>
    </div>
  );
}