import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { TrendingUp, TrendingDown, DollarSign, Receipt, Percent, Minus } from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from "recharts";

const CATEGORY_LABELS = {
  maintenance: "Dayactir",
  salaries: "Mushaharo",
  equipment: "Qalab",
  transport: "Gaadiid",
  utilities: "Kharashka Guud",
  rent: "Kirada",
  other: "Kale",
};

const CATEGORY_COLORS = {
  maintenance: "#f59e0b",
  salaries: "#3b82f6",
  equipment: "#8b5cf6",
  transport: "#06b6d4",
  utilities: "#10b981",
  rent: "#ef4444",
  other: "#71717a",
};

export default function ProfitLoss({ month }) {
  const [billings, setBillings] = useState([]);
  const [expenses, setExpenses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [taxRate, setTaxRate] = useState(5);

  useEffect(() => {
    Promise.all([
      base44.entities.Billing.list("-created_date"),
      base44.entities.Expense.list("-created_date"),
    ])
      .then(([b, e]) => {
        setBillings(b);
        setExpenses(e);
      })
      .finally(() => setLoading(false));
  }, []);

  const monthBills = billings.filter((b) => b.billing_month?.startsWith(month));
  const revenue = monthBills.reduce((s, b) => s + (b.total_amount || 0), 0);
  const collected = monthBills
    .filter((b) => b.status === "paid")
    .reduce((s, b) => s + (b.total_amount || 0), 0);

  const monthExpenses = expenses.filter((e) => e.expense_date?.startsWith(month));
  const totalExpenses = monthExpenses.reduce((s, e) => s + (e.amount || 0), 0);

  const grossProfit = revenue - totalExpenses;
  const tax = Math.max(0, grossProfit) * (taxRate / 100);
  const netProfit = grossProfit - tax;
  const margin = revenue > 0 ? (grossProfit / revenue) * 100 : 0;

  const byCategory = {};
  monthExpenses.forEach((e) => {
    const k = e.category || "other";
    byCategory[k] = (byCategory[k] || 0) + (e.amount || 0);
  });
  const pieData = Object.entries(byCategory)
    .map(([k, v]) => ({ name: CATEGORY_LABELS[k] || k, value: v, color: CATEGORY_COLORS[k] || "#71717a" }))
    .sort((a, b) => b.value - a.value);

  if (loading) {
    return (
      <div className="h-64 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-amber-500/30 border-t-amber-500 rounded-full animate-spin" />
      </div>
    );
  }

  const Row = ({ label, value, negative, bold, accent }) => (
    <div className={`flex items-center justify-between py-3 ${bold ? "border-t border-zinc-700/60 mt-1" : ""}`}>
      <span className={`${bold ? "text-white font-semibold" : "text-zinc-400"} text-sm`}>{label}</span>
      <span className={`${accent || (bold ? "text-white font-bold" : "text-zinc-200 font-medium")} text-sm tabular-nums`}>
        {negative ? "−" : ""}${Math.abs(value).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
      </span>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="rounded-2xl bg-zinc-900/50 border border-zinc-800/50 p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
          <div>
            <h3 className="text-white font-semibold flex items-center gap-2">
              <Receipt className="w-4 h-4 text-amber-400" /> Faa'iido & Khasaaro (Profit &amp; Loss)
            </h3>
            <p className="text-zinc-500 text-xs mt-1">Dakhiga, kharashaadka iyo canshuurta — {month}</p>
          </div>
          <div className="flex items-center gap-2">
            <Percent className="w-4 h-4 text-zinc-500" />
            <label className="text-zinc-400 text-xs">Heerka Canshuurta</label>
            <input
              type="number"
              min="0"
              step="0.5"
              value={taxRate}
              onChange={(e) => setTaxRate(Number(e.target.value))}
              className="w-16 h-8 rounded-md bg-zinc-800 border border-zinc-700 text-white text-sm px-2"
            />
            <span className="text-zinc-400 text-xs">%</span>
          </div>
        </div>

        <div className="divide-y divide-zinc-800/50">
          <Row label="Dakhiga Guud (Revenue)" value={revenue} accent="text-emerald-400 font-medium" />
          <Row label="Kharashaadka (Expenses)" value={totalExpenses} negative accent="text-red-400 font-medium" />
          <Row
            label={`Faa'iidada Guud (Gross Profit) · ${margin.toFixed(1)}%`}
            value={grossProfit}
            bold
            accent={grossProfit >= 0 ? "text-emerald-400" : "text-red-400"}
          />
          <Row label={`Canshuur (${taxRate}%)`} value={tax} negative accent="text-amber-400 font-medium" />
          <Row
            label="Faa'iidada Saafiga (Net Profit)"
            value={netProfit}
            bold
            accent={netProfit >= 0 ? "text-emerald-400" : "text-red-400"}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="rounded-2xl bg-gradient-to-br from-emerald-500/10 to-emerald-600/5 border border-emerald-500/15 p-5">
          <div className="flex items-center justify-between mb-3">
            <p className="text-zinc-400 text-xs font-medium uppercase tracking-wider">Dakhiga La Ururiyay</p>
            <DollarSign className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-2xl font-bold text-emerald-400">${collected.toLocaleString()}</p>
          <p className="text-zinc-500 text-xs mt-1">{revenue > 0 ? ((collected / revenue) * 100).toFixed(1) : 0}% dakhiga la ururiyay</p>
        </div>
        <div className="rounded-2xl bg-gradient-to-br from-red-500/10 to-red-600/5 border border-red-500/15 p-5">
          <div className="flex items-center justify-between mb-3">
            <p className="text-zinc-400 text-xs font-medium uppercase tracking-wider">Wadarta Kharashaadka</p>
            <TrendingDown className="w-4 h-4 text-red-400" />
          </div>
          <p className="text-2xl font-bold text-red-400">${totalExpenses.toLocaleString()}</p>
          <p className="text-zinc-500 text-xs mt-1">{monthExpenses.length} kharash bishan</p>
        </div>
        <div className={`rounded-2xl bg-gradient-to-br border p-5 ${netProfit >= 0 ? "from-amber-500/10 to-amber-600/5 border-amber-500/15" : "from-red-500/10 to-red-600/5 border-red-500/15"}`}>
          <div className="flex items-center justify-between mb-3">
            <p className="text-zinc-400 text-xs font-medium uppercase tracking-wider">Faa'iidada Saafiga</p>
            {netProfit >= 0 ? <TrendingUp className="w-4 h-4 text-amber-400" /> : <Minus className="w-4 h-4 text-red-400" />}
          </div>
          <p className={`text-2xl font-bold ${netProfit >= 0 ? "text-amber-400" : "text-red-400"}`}>${netProfit.toLocaleString()}</p>
          <p className="text-zinc-500 text-xs mt-1">{margin.toFixed(1)}% margin guud</p>
        </div>
      </div>

      <div className="rounded-2xl bg-zinc-900/50 border border-zinc-800/50 p-6">
        <h3 className="text-white font-semibold mb-1">Kharashaadka Qaybaha</h3>
        <p className="text-zinc-500 text-xs mb-4">Kharashaadka bishan oo loo qaybiyay qaybaha</p>
        {pieData.length > 0 ? (
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={95} label={(e) => `$${e.value.toLocaleString()}`}>
                  {pieData.map((d) => (
                    <Cell key={d.name} fill={d.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ background: "#18181b", border: "1px solid #3f3f46", borderRadius: "12px", color: "#fff" }} />
                <Legend wrapperStyle={{ fontSize: "12px" }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        ) : (
          <div className="h-64 flex items-center justify-center text-zinc-600 text-sm">Bishan kharash lama helin</div>
        )}
      </div>
    </div>
  );
}