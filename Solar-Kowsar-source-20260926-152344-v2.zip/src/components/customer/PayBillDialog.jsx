import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import { useToast } from "@/components/ui/use-toast";
import { Wallet, Loader2, CheckCircle2 } from "lucide-react";

const PROVIDER_LABELS = {
  evc_plus: "EVC Plus",
  zaad: "Zaad",
  premier_wallet: "Premier Wallet",
  edahab: "eDahab",
  bank_transfer: "Wareejin Bangi",
  card: "Kaadh",
  cash: "Lacag Caddaan",
  other: "Kale",
};

// Customer pays a bill through one of the company's payment methods, then
// confirms with the transaction reference — the office verifies and closes it.
export default function PayBillDialog({ bill, customer, open, onOpenChange, onSubmitted }) {
  const { toast } = useToast();
  const [methods, setMethods] = useState([]);
  const [reference, setReference] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!open) return;
    setReference("");
    base44.entities.PaymentMethod.list()
      .then((m) => setMethods(m.filter((x) => x.enabled !== false)))
      .catch(() => setMethods([]));
  }, [open]);

  const submit = async () => {
    if (!bill || !customer) return;
    setSubmitting(true);
    try {
      await base44.entities.Notification.create({
        title: `Codsiga lacag bixinta: ${customer.full_name}`,
        message: `${customer.full_name} (Mitaar ${customer.meter_number || "-"}) wuxuu sheegay inuu bixiyay biilka ${bill.billing_month} oo dhan $${Number(bill.total_amount || 0).toFixed(2)}. Lambarka xaqiijinta: ${reference.trim() || "—"}. Fadlan xaqiiji lacag bixinta.`,
        type: "billing",
        customer: customer.id,
        is_read: false,
      });
      toast({
        title: "Waa la gudbiyay",
        description: "Xafiiska ayaa xaqiijin doona lacag bixinta.",
      });
      onOpenChange(false);
      if (onSubmitted) onSubmitted();
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Codsiga lama gudbin karin" });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-zinc-900 border-zinc-800 text-white">
        <DialogHeader>
          <DialogTitle>Bixi Biilka</DialogTitle>
          <DialogDescription className="text-zinc-400">
            Bixi lacagta mid ka mid ah hababka hoos ku qoran, kadibna xaqiiji lambarka.
          </DialogDescription>
        </DialogHeader>

        {bill && (
          <div className="rounded-xl bg-zinc-800/60 border border-zinc-700 p-4 flex items-center justify-between">
            <div>
              <p className="text-zinc-400 text-xs uppercase tracking-wider">Biilka</p>
              <p className="text-white font-semibold">{bill.billing_month}</p>
              <p className="text-zinc-500 text-xs">{bill.kwh_used} kWh</p>
            </div>
            <p className="text-2xl font-bold text-amber-400">${Number(bill.total_amount || 0).toFixed(2)}</p>
          </div>
        )}

        <div className="space-y-2">
          <p className="text-zinc-300 text-sm font-medium">Hababka Lacag Bixinta</p>
          {methods.length === 0 ? (
            <p className="text-zinc-500 text-sm">Hababka lacag bixinta lama helin. La xiriir xafiiska.</p>
          ) : (
            <div className="space-y-2 max-h-52 overflow-y-auto">
              {methods.map((m) => (
                <div key={m.id} className="rounded-lg bg-zinc-800/50 border border-zinc-700 p-3">
                  <div className="flex items-center justify-between">
                    <span className="inline-flex items-center gap-2 text-sm font-medium text-white">
                      <Wallet className="w-4 h-4 text-emerald-400" />
                      {m.name}
                    </span>
                    <span className="text-zinc-400 text-xs">{PROVIDER_LABELS[m.provider] || m.provider}</span>
                  </div>
                  {m.account_number && (
                    <p className="text-zinc-300 text-sm mt-1">
                      {m.account_name ? `${m.account_name} — ` : ""}<span className="font-mono">{m.account_number}</span>
                    </p>
                  )}
                  {m.instructions && <p className="text-zinc-500 text-xs mt-1">{m.instructions}</p>}
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="space-y-2">
          <Label className="text-zinc-300 text-sm">Lambarka Xaqiijinta (Tusaale: EVC/TTX)</Label>
          <Input
            value={reference}
            onChange={(e) => setReference(e.target.value)}
            placeholder="T.c. 1234567890"
            className="bg-zinc-800 border-zinc-700 text-white"
          />
        </div>

        <DialogFooter>
          <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="border-zinc-700 text-zinc-300">
            Jooji
          </Button>
          <Button onClick={submit} disabled={submitting} className="bg-orange-500 hover:bg-orange-600 text-white">
            {submitting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <CheckCircle2 className="w-4 h-4 mr-2" />}
            Waan Bixiyay
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}