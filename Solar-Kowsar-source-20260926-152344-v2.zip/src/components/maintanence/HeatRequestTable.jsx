import React from "react";
import { useT } from "@/lib/i18n";
import { Flame } from "lucide-react";

const PRIORITY_META = {
  low: { key: "heatreq.priority.low", bg: "bg-zinc-500/15", text: "text-zinc-300" },
  medium: { key: "heatreq.priority.medium", bg: "bg-blue-500/15", text: "text-blue-400" },
  high: { key: "heatreq.priority.high", bg: "bg-amber-500/15", text: "text-amber-400" },
  critical: { key: "heatreq.priority.critical", bg: "bg-red-500/15", text: "text-red-400" },
};

const STATUS_META = {
  open: { key: "heatreq.status.open", bg: "bg-amber-500/15", text: "text-amber-400" },
  in_progress: { key: "heatreq.status.in_progress", bg: "bg-blue-500/15", text: "text-blue-400" },
  resolved: { key: "heatreq.status.resolved", bg: "bg-emerald-500/15", text: "text-emerald-400" },
};

export default function HeatRequestTable({ items, total, loading }) {
  const { t } = useT();

  return (
    <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 overflow-hidden">
      {loading ? (
        <div className="p-12 flex items-center justify-center">
          <div className="w-8 h-8 border-4 border-orange-500/30 border-t-orange-500 rounded-full animate-spin" />
        </div>
      ) : items.length === 0 ? (
        <div className="p-12 text-center text-zinc-500">
          <Flame className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p className="text-sm">{total === 0 ? t("heatreq.empty") : t("heatreq.noMatch")}</p>
          {total === 0 && <p className="text-xs mt-1">{t("heatreq.empty.sub")}</p>}
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-zinc-800 text-zinc-400 text-xs uppercase tracking-wider">
                <th className="text-left px-6 py-3 font-medium">{t("heatreq.col.equipment")}</th>
                <th className="text-left px-6 py-3 font-medium">{t("heatreq.col.location")}</th>
                <th className="text-left px-6 py-3 font-medium">{t("heatreq.col.temp")}</th>
                <th className="text-left px-6 py-3 font-medium">{t("heatreq.col.priority")}</th>
                <th className="text-left px-6 py-3 font-medium">{t("heatreq.col.status")}</th>
                <th className="text-left px-6 py-3 font-medium">{t("heatreq.col.date")}</th>
              </tr>
            </thead>
            <tbody>
              {items.map((item) => {
                const pr = PRIORITY_META[item.priority] || PRIORITY_META.medium;
                const st = STATUS_META[item.status] || STATUS_META.open;
                return (
                  <tr key={item.id} className="border-b border-zinc-800/50 hover:bg-zinc-800/30 transition-colors">
                    <td className="px-6 py-3 text-white font-medium">{item.name}</td>
                    <td className="px-6 py-3 text-zinc-300">{item.customer_name || "—"}</td>
                    <td className="px-6 py-3 text-orange-400 font-semibold">
                      {item.temp === null ? "—" : `${item.temp}°C`}
                    </td>
                    <td className="px-6 py-3">
                      <span className={`inline-flex px-2.5 py-1 rounded-full text-xs font-medium ${pr.bg} ${pr.text}`}>
                        {t(pr.key)}
                      </span>
                    </td>
                    <td className="px-6 py-3">
                      <span className={`inline-flex px-2.5 py-1 rounded-full text-xs font-medium ${st.bg} ${st.text}`}>
                        {t(st.key)}
                      </span>
                    </td>
                    <td className="px-6 py-3 text-zinc-400">
                      {item.created_date ? new Date(item.created_date).toLocaleDateString() : "—"}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}