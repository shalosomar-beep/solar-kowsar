import React from "react";
import { Link } from "react-router-dom";
import { Cpu, Clock, ThermometerSun, ChevronRight } from "lucide-react";
import { useT } from "@/lib/i18n";

function heatOf(temp) {
  if (typeof temp !== "number") {
    return { labelKey: null, cls: "text-muted-foreground", bg: "bg-accent border-border" };
  }
  if (temp >= 60) return { labelKey: "invhealth.hot", cls: "text-red-400", bg: "bg-red-500/15 border-red-500/30" };
  if (temp >= 50) return { labelKey: "invhealth.warn", cls: "text-amber-400", bg: "bg-amber-500/15 border-amber-500/30" };
  return { labelKey: "invhealth.normal", cls: "text-emerald-400", bg: "bg-emerald-500/15 border-emerald-500/30" };
}

// Inverter running hours and operating temperature, so overheating is caught
// before an inverter burns out in the middle of the day.
export default function InverterHealthCard({ inverters }) {
  const { t } = useT();
  return (
    <div className="rounded-xl bg-card border border-border p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Cpu className="w-4 h-4 text-cyan-400" />
          <h3 className="text-foreground font-semibold text-sm">{t("invhealth.title")}</h3>
        </div>
        <Link to="/qalabka" className="inline-flex items-center gap-1 text-xs font-semibold text-muted-foreground hover:text-foreground transition-colors">
          {t("nav.equipment")}
          <ChevronRight className="w-3.5 h-3.5" />
        </Link>
      </div>

      {inverters.length === 0 ? (
        <p className="text-muted-foreground text-sm py-6 text-center">
          {t("invhealth.empty")}
        </p>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {inverters.map((inv) => {
            const heat = heatOf(inv.temperature);
            return (
              <div key={inv.id} className="rounded-lg bg-accent/50 border border-border p-3">
                <p className="text-foreground font-semibold text-sm truncate">{inv.name}</p>
                <p className="text-muted-foreground text-xs mt-0.5 truncate">{inv.location || "—"}</p>
                <div className="flex items-center justify-between mt-3">
                  <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Clock className="w-3.5 h-3.5 text-cyan-400" />
                    {typeof inv.running_hours === "number" ? `${inv.running_hours.toLocaleString()} h` : "—"}
                  </span>
                  <span className={`inline-flex items-center gap-1.5 px-2 py-1 rounded-full border text-xs font-semibold ${heat.bg} ${heat.cls}`}>
                    <ThermometerSun className="w-3.5 h-3.5" />
                    {typeof inv.temperature === "number" ? `${inv.temperature}°C` : "—"} · {heat.labelKey ? t(heat.labelKey) : "—"}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}