import React from "react";
import { Link } from "react-router-dom";
import { Leaf, TreePine, ChevronRight } from "lucide-react";

// Grid emission factor used for the CO₂ avoided figure (kg CO₂ per kWh).
const CO2_FACTOR = 0.7;
const KG_PER_TREE_YEAR = 21;

export default function CarbonOffsetCard({ kwh }) {
  const co2Kg = (Number(kwh) || 0) * CO2_FACTOR;
  const tonnes = co2Kg / 1000;
  const trees = co2Kg / KG_PER_TREE_YEAR;

  return (
    <div className="rounded-xl bg-gradient-to-br from-emerald-500/10 to-emerald-600/5 border border-emerald-500/20 p-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Leaf className="w-4 h-4 text-emerald-400" />
          <h3 className="text-foreground font-semibold text-sm">CO₂ La Badbaadiyay</h3>
        </div>
        <Link to="/kaarboonka" className="inline-flex items-center gap-1 text-xs font-semibold text-muted-foreground hover:text-foreground transition-colors">
          Faahfaahin
          <ChevronRight className="w-3.5 h-3.5" />
        </Link>
      </div>
      <p className="text-muted-foreground text-xs mt-0.5 mb-3">
        Deegaanka laga badbaadiyay iyadoo la isticmaalayo tamarta qorraxda
      </p>

      <div className="flex items-end justify-between gap-4">
        <div>
          <p className="text-muted-foreground text-[11px] font-medium uppercase tracking-wider">Tanno CO₂</p>
          <p className="text-2xl font-bold text-emerald-400">{tonnes.toFixed(2)}</p>
        </div>
        <div className="text-right">
          <p className="text-muted-foreground text-[11px] font-medium uppercase tracking-wider">Geedo U Dhigma</p>
          <p className="text-lg font-bold text-foreground inline-flex items-center gap-1.5">
            <TreePine className="w-4 h-4 text-emerald-400" />
            {trees.toFixed(1)}
          </p>
        </div>
      </div>

      <p className="text-muted-foreground text-xs mt-3">
        {co2Kg.toLocaleString(undefined, { maximumFractionDigits: 0 })} kg CO₂ — heerka {CO2_FACTOR} kg/kWh
      </p>
    </div>
  );
}