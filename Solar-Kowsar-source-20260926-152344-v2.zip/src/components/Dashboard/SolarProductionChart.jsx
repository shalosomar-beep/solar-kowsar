import React, { useRef } from "react";
import { Link } from "react-router-dom";
import {
  ResponsiveContainer, ComposedChart, Area, Line, XAxis, YAxis,
  CartesianGrid, Tooltip, Legend, ReferenceLine,
} from "recharts";
import { Sun } from "lucide-react";
import { useT } from "@/lib/i18n";
import ChartExportMenu from "@/components/Chart/ChartExportMenu";

// Solar yield chart: production vs consumption, with the previous period as a
// dashed line and the system's design capacity as a dotted reference line.
export default function SolarProductionChart({ data, designCapacity }) {
  const { t } = useT();
  const chartRef = useRef(null);

  return (
    <div className="rounded-xl bg-card border border-border p-4 hover:shadow-md transition-shadow">
      <div className="flex items-center justify-between mb-1">
        <h3 className="text-foreground font-semibold text-sm flex items-center gap-2">
          <Sun className="w-4 h-4 text-orange-400" />
          {t("home.solar.productionChart.title")}
        </h3>
        <div className="flex items-center gap-2">
          <ChartExportMenu
            chartRef={chartRef}
            filename="wax-soo-saarka-qoraxda"
            columns={[t("chart.col.date"), t("chart.legend.production"), t("solarData.col.consumption")]}
            rows={data.map((d) => [d.name, d.kwh, d.consumption])}
          />
          <Link
            to="/xogta-qoraxda"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-orange-500 hover:bg-orange-600 text-white text-xs font-semibold transition-colors"
          >
            {t("home.solar.openData")}
          </Link>
        </div>
      </div>
      <p className="text-muted-foreground text-xs mb-3">{t("home.solar.productionChart.sub")}</p>
      <div className="h-56" ref={chartRef}>
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={data}>
            <defs>
              <linearGradient id="solarDashFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#f97316" stopOpacity={0.5} />
                <stop offset="95%" stopColor="#f97316" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={11} angle={-30} textAnchor="end" height={60} />
            <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
            <Tooltip
              formatter={(v) => (v == null ? "—" : `${Number(v).toFixed(1)} kWh`)}
              contentStyle={{ background: "hsl(var(--popover))", border: "1px solid hsl(var(--border))", borderRadius: "12px", color: "hsl(var(--popover-foreground))" }}
              labelStyle={{ color: "hsl(var(--muted-foreground))" }}
            />
            <Legend wrapperStyle={{ fontSize: 12 }} />
            <Area type="monotone" dataKey="kwh" name={t("chart.legend.production")} stroke="#f97316" strokeWidth={2.5} fill="url(#solarDashFill)" />
            <Line type="monotone" dataKey="consumption" name={t("solarData.col.consumption")} stroke="#06b6d4" strokeWidth={2} dot={false} />
            <Line type="monotone" dataKey="prev" name={t("chart.legend.previousPeriod")} stroke="hsl(var(--muted-foreground))" strokeDasharray="5 4" strokeWidth={1.5} dot={false} connectNulls />
            {designCapacity > 0 && (
              <ReferenceLine
                y={designCapacity}
                stroke="#f43f5e"
                strokeDasharray="4 4"
                strokeWidth={1.5}
                label={{ value: t("chart.legend.designCapacity"), position: "insideTopRight", fontSize: 10, fill: "#f43f5e" }}
              />
            )}
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}