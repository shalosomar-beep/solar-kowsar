import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import {
  Zap, DollarSign, Clock, Package, Sun, History as HistoryIcon
} from "lucide-react";
import StatGrid from "@/components/dashboard/StatGrid";
import SolarProductionChart from "@/components/dashboard/SolarProductionChart";
import DailyRevenueChart from "@/components/dashboard/DailyRevenueChart";
import LineLossCard from "@/components/dashboard/LineLossCard";
import CarbonOffsetCard from "@/components/dashboard/CarbonOffsetCard";
import InverterHealthCard from "@/components/dashboard/InverterHealthCard";
import ChartExportMenu from "@/components/Chart/ChartExportMenu";
import DataErrorState from "@/components/common/DataErrorState";
import DateRangeFilter from "@/components/common/DateRangeFilter";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area, LineChart, Line } from "recharts";
import { Calendar } from "lucide-react";
import { Link } from "react-router-dom";
import { useT } from "@/lib/i18n";

// Full dashboard for Admin / Manager roles — sees the entire system.
export default function AdminDashboard() {
  const { t } = useT();
  const [customers, setCustomers] = useState([]);
  const [billings, setBillings] = useState([]);
  const [dailyUsages, setDailyUsages] = useState([]);
  const [expenses, setExpenses] = useState([]);
  const [solarData, setSolarData] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [equipment, setEquipment] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [range, setRange] = useState("month");
  const hoursChartRef = useRef(null);

  const load = () => {
    setLoading(true);
    setError(false);
    Promise.all([
      base44.entities.Customer.list(),
      base44.entities.Billing.list(),
      base44.entities.DailyUsage.list(),
      base44.entities.Expense.list(),
      base44.entities.SolarData.list("-usage_date", 200),
      base44.entities.Notification.list(),
      base44.entities.Equipment.list(),
    ])
      .then(([c, b, u, e, sd, n, eq]) => {
        setCustomers(c);
        setBillings(b);
        setDailyUsages(u);
        setExpenses(e);
        setSolarData(sd);
        setNotifications(n);
        setEquipment(eq);
      })
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-amber-500/30 border-t-amber-500 rounded-full animate-spin" />
      </div>
    );
  }

  if (error) {
    return <DataErrorState onRetry={load} />;
  }

  const activeCustomers = customers.filter((c) => c.status === "active");
  const totalKW = customers.reduce((sum, c) => sum + (c.solar_capacity_kw || 0), 0);
  const totalCollected = billings.reduce((sum, b) => sum + (b.amount_paid || 0), 0);
  const pendingBills = billings.filter((b) => b.status === "pending");
  const pendingAmount = pendingBills.reduce((sum, b) => sum + (b.total_amount || 0), 0);
  const overdueBills = billings.filter((b) => b.status === "overdue");
  const totalExpenses = expenses.reduce((sum, e) => sum + (e.amount || 0), 0);
  const suspendedCount = customers.filter((c) => c.status === "suspended").length;
  const onlineMeters = customers.filter((c) => c.meter_status === "online").length;
  const offlineMeters = customers.filter((c) => c.meter_status === "offline").length;
  const maintenanceRequests = expenses.filter((e) => e.category === "maintenance" || e.category === "equipment").length;
  const totalBalance = customers.reduce((sum, c) => sum + (c.balance || 0), 0);
  const lowStockItems = expenses.filter((e) => e.category === "equipment").length;
  const unreadNotifications = notifications.filter((n) => !n.is_read).length;

  const solarTotalKwh = solarData.reduce((sum, s) => sum + (Number(s.production_kwh) || 0), 0);
  const solarAvgHours = solarData.length ? solarData.reduce((sum, s) => sum + (Number(s.sun_hours) || 0), 0) / solarData.length : 0;
  const solarPeakKw = solarData.reduce((max, s) => Math.max(max, Number(s.peak_power_kw) || 0), 0);
  const solarConsumptionKwh = solarData.reduce((sum, s) => sum + (Number(s.consumption_kwh) || 0), 0);
  const lineLossKwh = Math.max(0, solarTotalKwh - solarConsumptionKwh);
  const lineLossPct = solarTotalKwh > 0 ? (lineLossKwh / solarTotalKwh) * 100 : 0;
  const inverters = equipment.filter((e) => e.category === "inverter");
  const solarToday = solarData.find((s) => s.usage_date === new Date().toISOString().slice(0, 10));
  const rangeStart = (() => {
    if (range === "all") return null;
    const d = new Date();
    if (range === "week") d.setDate(d.getDate() - 7);
    else if (range === "month") d.setDate(d.getDate() - 30);
    else d.setDate(d.getDate() - 365);
    return d;
  })();

  const sortedSolar = [...solarData]
    .filter((s) => s.usage_date)
    .sort((a, b) => new Date(a.usage_date) - new Date(b.usage_date));

  const currentSolar = sortedSolar
    .filter((s) => !rangeStart || new Date(s.usage_date) >= rangeStart)
    .slice(-40);

  // The days immediately before the shown window, aligned by index for comparison.
  const prevSolar = sortedSolar.slice(
    Math.max(0, sortedSolar.length - currentSolar.length * 2),
    sortedSolar.length - currentSolar.length
  );

  const solarChartData = currentSolar.map((s, i) => ({
    name: new Date(s.usage_date).toLocaleDateString("en-US", { month: "short", day: "numeric" }),
    kwh: Number(s.production_kwh) || 0,
    consumption: Number(s.consumption_kwh) || 0,
    prev: prevSolar[i] ? Number(prevSolar[i].production_kwh) || 0 : null,
    hours: Number(s.sun_hours) || 0,
  }));

  // Design capacity: the total installed capacity of the customers' solar systems (kWp).
  const designCapacity = totalKW;

  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const revenueByMonth = [];
  const kwhByMonth = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date();
    d.setMonth(d.getMonth() - i);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    const monthBills = billings.filter((b) => b.billing_month?.startsWith(key));
    const rev = monthBills.filter((b) => b.status === "paid").reduce((s, b) => s + (b.total_amount || 0), 0);
    const kwh = monthBills.reduce((s, b) => s + (b.kwh_used || 0), 0);
    revenueByMonth.push({ name: monthNames[d.getMonth()], lacag: rev });
    kwhByMonth.push({ name: monthNames[d.getMonth()], kwh });
  }

  const dailyUsageData = [];
  for (let i = 13; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const key = d.toISOString().slice(0, 10);
    const dayUsage = dailyUsages.filter((u) => u.usage_date === key);
    const totalKwh = dayUsage.reduce((s, u) => s + (u.kwh_used || 0), 0);
    dailyUsageData.push({ name: d.toLocaleDateString("en", { day: "numeric", month: "short" }), kwh: Number(totalKwh.toFixed(2)) });
  }
  const todayKwh = dailyUsageData[dailyUsageData.length - 1]?.kwh || 0;
  const avgDailyKwh = (dailyUsageData.reduce((s, d) => s + d.kwh, 0) / dailyUsageData.length).toFixed(1);

  const dailyRevenueData = [];
  for (let i = 13; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const key = d.toISOString().slice(0, 10);
    const collected = billings
      .filter((b) => b.status === "paid" && b.payment_date === key)
      .reduce((s, b) => s + (b.total_amount || 0), 0);
    dailyRevenueData.push({
      name: d.toLocaleDateString("en", { day: "numeric", month: "short" }),
      revenue: Number(collected.toFixed(2)),
    });
  }
  const revenue14 = dailyRevenueData.reduce((s, d) => s + d.revenue, 0);

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-xl md:text-2xl font-bold text-foreground tracking-tight">{t("app.title")}</h1>
          <p className="text-muted-foreground mt-0.5 text-sm">{t("app.subtitle")}</p>
        </div>
        <div className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-card border border-border text-sm text-muted-foreground">
          <Calendar className="w-4 h-4 text-orange-400" />
          {new Date().toLocaleDateString(undefined, { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
        </div>
      </div>

      <StatGrid
        customersCount={customers.length}
        totalKW={totalKW}
        collectedAmount={totalCollected}
        pendingAmount={pendingAmount}
        unreadNotifications={unreadNotifications}
        totalBalance={totalBalance}
        suspendedCount={suspendedCount}
        billingCount={billings.length}
        pendingBillsCount={pendingBills.length}
        onlineMeters={onlineMeters}
        offlineMeters={offlineMeters}
      />

      {/* Solar metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-2">
        <div className="rounded-xl bg-gradient-to-br from-orange-500 to-amber-600 p-4 text-white">
          <div className="flex items-center gap-2">
            <Sun className="w-4 h-4" />
            <p className="text-xs font-medium uppercase tracking-wider opacity-90">{t("home.solar.totalProduction.title")}</p>
          </div>
          <p className="text-2xl font-bold mt-2">{solarTotalKwh.toFixed(1)} kWh</p>
          <p className="text-xs opacity-80 mt-0.5">{t("home.solar.totalProduction.sub", { count: solarData.length })}</p>
        </div>
        <div className="rounded-xl bg-card border border-border p-4">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-cyan-400" />
            <p className="text-muted-foreground text-xs font-medium uppercase tracking-wider">{t("home.solar.avgHours.title")}</p>
          </div>
          <p className="text-2xl font-bold mt-2 text-foreground">{solarAvgHours.toFixed(1)} h</p>
        </div>
        <div className="rounded-xl bg-card border border-border p-4">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-400" />
            <p className="text-muted-foreground text-xs font-medium uppercase tracking-wider">{t("home.solar.peakPower.title")}</p>
          </div>
          <p className="text-2xl font-bold mt-2 text-foreground">{solarPeakKw.toFixed(1)} kW</p>
        </div>
      </div>

      {/* Line losses, carbon offset and inverter health */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
        <LineLossCard production={solarTotalKwh} consumption={solarConsumptionKwh} lossPct={lineLossPct} />
        <CarbonOffsetCard kwh={solarTotalKwh} />
      </div>

      <InverterHealthCard inverters={inverters} />

      {/* Period filter for the solar charts below */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mt-2">
        <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{t("range.label")}</p>
        <DateRangeFilter value={range} onChange={setRange} />
      </div>

      {/* Solar Production Chart */}
      <SolarProductionChart data={solarChartData} designCapacity={designCapacity} />

      {/* Sun Hours Chart */}
      <div className="rounded-xl bg-card border border-border p-4">
        <div className="flex items-center justify-between mb-1">
          <h3 className="text-foreground font-semibold text-sm flex items-center gap-2">
            <Clock className="w-4 h-4 text-cyan-400" />
            {t("home.solar.hoursChart.title")}
          </h3>
          <div className="flex items-center gap-2">
            <ChartExportMenu
              chartRef={hoursChartRef}
              filename="saacadaha-qoraxda"
              columns={[t("chart.col.date"), t("home.solar.avg")]}
              rows={solarChartData.map((d) => [d.name, d.hours])}
            />
            <span className="px-3 py-1.5 rounded-lg bg-cyan-500/15 text-cyan-400 text-xs font-semibold">
              {t("home.solar.avg")}: {solarAvgHours.toFixed(1)} h
            </span>
          </div>
        </div>
        <p className="text-muted-foreground text-xs mb-3">{t("home.solar.hoursChart.sub")}</p>
        <div className="h-48" ref={hoursChartRef}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={solarChartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={11} angle={-30} textAnchor="end" height={60} />
              <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
              <Tooltip formatter={(v) => `${v} h`} contentStyle={{ background: "hsl(var(--popover))", border: "1px solid hsl(var(--border))", borderRadius: "12px", color: "hsl(var(--popover-foreground))" }} labelStyle={{ color: "hsl(var(--muted-foreground))" }} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Bar dataKey="hours" name={t("chart.legend.sunHours")} fill="#06b6d4" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Status Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-2">
        <div className="rounded-2xl bg-card border border-border p-6 flex items-center justify-between">
          <div>
            <h3 className="text-foreground font-semibold">{t("home.status.systemStatus")}</h3>
            <p className="text-muted-foreground text-sm mt-0.5">{t("home.status.systemStatusSub")}</p>
          </div>
          <button className="px-3 py-2 rounded-lg bg-accent hover:bg-accent/70 text-foreground text-sm font-semibold transition-colors">
            {t("home.status.systemsCount", { count: customers.length })}
          </button>
        </div>
        <div className="rounded-2xl bg-card border border-border p-6 flex items-center justify-between">
          <div>
            <h3 className="text-foreground font-semibold">{t("home.status.activeSystems")}</h3>
            <p className="text-muted-foreground text-sm mt-0.5">{t("home.status.topSystemsSub")}</p>
          </div>
          <button className="px-3 py-2 rounded-lg bg-accent hover:bg-accent/70 text-foreground text-sm font-semibold transition-colors">
            {t("home.status.activeTotal", { count: activeCustomers.length })}
          </button>
        </div>
        <div className="rounded-2xl bg-card border border-border p-6 flex items-center justify-between">
          <div>
            <h3 className="text-foreground font-semibold">{t("home.status.solarIrradiance")}</h3>
            <p className="text-muted-foreground text-sm mt-0.5">{t("home.status.todayProduction")}</p>
          </div>
          <span className="px-3 py-2 rounded-lg bg-amber-500/20 text-amber-400 text-sm font-semibold">
            {solarToday ? `${solarToday.production_kwh} kWh` : "0 kWh"}
          </span>
        </div>
      </div>

      {/* Usage History */}
      <div className="rounded-2xl bg-card border border-border p-6 flex items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-600/20 flex items-center justify-center">
            <HistoryIcon className="w-6 h-6 text-blue-400" />
          </div>
          <div>
            <h3 className="text-foreground font-semibold text-lg">{t("home.history.title")}</h3>
            <p className="text-muted-foreground text-sm">{t("home.history.sub", { count: dailyUsages.length })}</p>
          </div>
        </div>
        <Link to="/taariikhda" className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-blue-700 hover:bg-blue-800 text-white text-sm font-semibold transition-colors whitespace-nowrap">
          <HistoryIcon className="w-4 h-4" />
          {t("home.history.button")}
        </Link>
      </div>

      {/* Daily Usage Chart */}
      <div className="rounded-2xl bg-card border border-border p-6">
        <div className="flex items-center justify-between mb-1">
          <h3 className="text-foreground font-semibold flex items-center gap-2">
            <Calendar className="w-4 h-4 text-cyan-400" />
            {t("home.daily.title")}
          </h3>
          <div className="flex gap-4 text-xs">
            <div className="text-right">
              <p className="text-muted-foreground">{t("home.daily.today")}</p>
              <p className="text-cyan-400 font-bold">{todayKwh} KWh</p>
            </div>
            <div className="text-right">
              <p className="text-muted-foreground">{t("home.daily.avg")}</p>
              <p className="text-foreground font-bold">{avgDailyKwh} KWh</p>
            </div>
          </div>
        </div>
        <p className="text-muted-foreground text-xs mb-6">{t("home.daily.sub")}</p>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={dailyUsageData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={11} angle={-30} textAnchor="end" height={60} />
              <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
              <Tooltip formatter={(v) => `${v} kWh`} contentStyle={{ background: "hsl(var(--popover))", border: "1px solid hsl(var(--border))", borderRadius: "12px", color: "hsl(var(--popover-foreground))" }} labelStyle={{ color: "hsl(var(--muted-foreground))" }} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Line type="monotone" dataKey="kwh" name={t("chart.legend.usage")} stroke="#06b6d4" strokeWidth={2.5} dot={{ fill: "#06b6d4", r: 3 }} activeDot={{ r: 5 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Revenue & KWh Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="rounded-2xl bg-card border border-border p-6">
          <h3 className="text-foreground font-semibold mb-1 flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-amber-400" />
            {t("home.revenue.title")}
          </h3>
          <p className="text-muted-foreground text-xs mb-6">{t("home.revenue.sub")}</p>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={revenueByMonth}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <Tooltip formatter={(v) => `$${v}`} contentStyle={{ background: "hsl(var(--popover))", border: "1px solid hsl(var(--border))", borderRadius: "12px", color: "hsl(var(--popover-foreground))" }} labelStyle={{ color: "hsl(var(--muted-foreground))" }} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Bar dataKey="lacag" name={t("chart.legend.revenue")} fill="#f59e0b" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="rounded-2xl bg-card border border-border p-6">
          <h3 className="text-foreground font-semibold mb-1 flex items-center gap-2">
            <Zap className="w-4 h-4 text-emerald-400" />
            {t("home.kwh.title")}
          </h3>
          <p className="text-muted-foreground text-xs mb-6">{t("home.kwh.sub")}</p>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={kwhByMonth}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <Tooltip formatter={(v) => `${v} kWh`} contentStyle={{ background: "hsl(var(--popover))", border: "1px solid hsl(var(--border))", borderRadius: "12px", color: "hsl(var(--popover-foreground))" }} labelStyle={{ color: "hsl(var(--muted-foreground))" }} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Area type="monotone" dataKey="kwh" name={t("chart.legend.kwh")} stroke="#10b981" fill="#10b981" fillOpacity={0.15} strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <DailyRevenueChart data={dailyRevenueData} total={revenue14} />
    </div>
  );
}