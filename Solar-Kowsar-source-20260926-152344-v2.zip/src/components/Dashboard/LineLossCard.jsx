import React from "react";
import { Link } from "react-router-dom";
import { TrendingDown, ChevronRight } from "lucide-react";
import { useT } from "@/lib/i18n";

// Line losses: the gap between what the inverters produced and what the
// customers' meters recorded — the energy lost in the cables (voltage drop).
export default function LineLossCard({ production, consumption, lossPct }) {
  const { t } = useT();
  const loss = Math.max(0, (production || 0) - (consumption || 0));
  const pct = lossPct || 0;
  const tone = pct > 15 ? "text-red-400" : pct > 8 ? "text-amber-400" : "text-emerald-400";
  const bar = pct > 15 ? "bg-red-500" : pct > 8 ? "bg-amber-500" : "bg-emerald-500";

  return (
    <div className="rounded-xl bg-card border border-border p-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <TrendingDown className="w-4 h-4 text-red-400" />
          <h3 className="text-foreground font-semibold text-sm">{t("lineloss.title")}</h3>
        </div>
        <Link to="/lumitaanka-tamarta" className="inline-flex items-center gap-1 text-xs font-semibold text-muted-foreground hover:text-foreground transition-colors">
          {t("lineloss.details")}
          <ChevronRight className="w-3.5 h-3.5" />
        </Link>
      </div>
      <p className="text-muted-foreground text-xs mt-0.5 mb-3">
        {t("lineloss.sub")}
      </p>

      <div className="flex items-end justify-between gap-4">
        <div>
          <p className="text-muted-foreground text-[11px] font-medium uppercase tracking-wider">{t("lineloss.lost")}</p>
          <p className={`text-2xl font-bold ${tone}`}>{loss.toFixed(1)} kWh</p>
        </div>
        <span className={`px-2.5 py-1 rounded-full text-xs font-semibold border ${tone} ${
          pct > 15 ? "bg-red-500/15 border-red-500/30" : pct > 8 ? "bg-amber-500/15 border-amber-500/30" : "bg-emerald-500/15 border-emerald-500/30"
        }`}>
          {t("lineloss.pct", { pct: pct.toFixed(1) })}
        </span>
      </div>

      <div className="mt-3 h-1.5 rounded-full bg-accent overflow-hidden">
        <div className={`h-full ${bar}`} style={{ width: `${Math.min(pct, 100)}%` }} />
      </div>

      <div className="flex items-center justify-between mt-3 text-xs">
        <span className="text-muted-foreground">
          {t("lineloss.production")}: <span className="text-foreground font-semibold">{Number(production || 0).toFixed(1)} kWh</span>
        </span>
        <span className="text-muted-foreground">
          {t("lineloss.delivered")}: <span className="text-foreground font-semibold">{Number(consumption || 0).toFixed(1)} kWh</span>
        </span>
      </div>
    </div>
  );
}