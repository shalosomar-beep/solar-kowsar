import React from "react";
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
} from "recharts";
import { DollarSign } from "lucide-react";
import { useT } from "@/lib/i18n";

// Money actually collected day by day, so management can relate sold energy to revenue.
export default function DailyRevenueChart({ data, total }) {
  const { t } = useT();

  return (
    <div className="rounded-2xl bg-card border border-border p-6">
      <div className="flex items-center justify-between mb-1">
        <h3 className="text-foreground font-semibold flex items-center gap-2">
          <DollarSign className="w-4 h-4 text-amber-400" />
          {t("home.revenueDaily.title")}
        </h3>
        <span className="px-3 py-1.5 rounded-lg bg-amber-500/15 text-amber-400 text-xs font-semibold">
          ${Number(total || 0).toFixed(2)}
        </span>
      </div>
      <p className="text-muted-foreground text-xs mb-6">{t("home.revenueDaily.sub")}</p>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={11} angle={-30} textAnchor="end" height={60} />
            <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
            <Tooltip
              formatter={(v) => `$${Number(v).toFixed(2)}`}
              contentStyle={{ background: "hsl(var(--popover))", border: "1px solid hsl(var(--border))", borderRadius: "12px", color: "hsl(var(--popover-foreground))" }}
              labelStyle={{ color: "hsl(var(--muted-foreground))" }}
            />
            <Legend wrapperStyle={{ fontSize: 12 }} />
            <Bar dataKey="revenue" name={t("chart.legend.revenue")} fill="#f59e0b" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}