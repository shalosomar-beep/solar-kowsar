import React from "react";
import { RefreshCw } from "lucide-react";
import { useT } from "@/lib/i18n";

// Header button that re-pulls live data for the page you are on without a
// full browser reload.
export default function RefreshButton({ onClick, spinning }) {
  const { t } = useT();

  return (
    <button
      onClick={onClick}
      title={t("header.refresh")}
      className="inline-flex items-center gap-1.5 px-2.5 py-2 rounded-lg bg-card hover:bg-accent border border-border text-muted-foreground text-xs font-semibold transition-colors"
    >
      <RefreshCw className={`w-3.5 h-3.5 ${spinning ? "animate-spin" : ""}`} />
      <span className="hidden xl:inline">{t("header.refresh")}</span>
    </button>
  );
}