import React, { useState } from "react";
import { ShieldCheck } from "lucide-react";
import { useT } from "@/lib/i18n";
import SecurityDialog from "@/components/layout/SecurityDialog";

export default function SecurityBadge() {
  const { t } = useT();
  const [open, setOpen] = useState(false);

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        title={t("security.title")}
        className="relative inline-flex items-center justify-center p-2 rounded-lg bg-card hover:bg-accent border border-border text-foreground transition-colors"
      >
        <ShieldCheck className="w-3.5 h-3.5" />
        <span className="absolute -top-0.5 -end-0.5 w-2 h-2 rounded-full bg-amber-400 ring-2 ring-card" />
      </button>
      <SecurityDialog open={open} onOpenChange={setOpen} />
    </>
  );
}