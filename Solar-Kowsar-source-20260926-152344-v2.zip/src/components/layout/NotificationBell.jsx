import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Bell, Check, BellOff } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
} from "@/components/ui/dropdown-menu";
import { useT } from "@/lib/i18n";

const TYPE_COLOR = {
  billing: "text-emerald-500",
  maintenance: "text-amber-500",
  warning: "text-red-500",
  general: "text-blue-500",
};

export default function NotificationBell() {
  const { t } = useT();
  const [items, setItems] = useState([]);

  const load = () =>
    base44.entities.Notification
      .filter({ is_read: false }, "-created_date", 20)
      .then(setItems)
      .catch(() => {});

  useEffect(() => {
    load();
    const unsubscribe = base44.entities.Notification.subscribe(() => load());
    return unsubscribe;
  }, []);

  const markAllRead = async () => {
    const ids = items.map((n) => n.id);
    if (ids.length === 0) return;
    await base44.entities.Notification.bulkUpdate(ids.map((id) => ({ id, is_read: true })));
    setItems([]);
  };

  const count = items.length;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          title={t("notif.title")}
          className="relative inline-flex items-center justify-center p-2 rounded-lg bg-card hover:bg-accent border border-border text-muted-foreground transition-colors"
        >
          <Bell className="w-4 h-4" />
          {count > 0 && (
            <span className="absolute -top-1.5 -end-1.5 min-w-[18px] h-[18px] px-1 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center">
              {count > 99 ? "99+" : count}
            </span>
          )}
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80 p-0">
        <div className="flex items-center justify-between px-3 py-2.5 border-b border-border">
          <p className="text-xs font-semibold text-foreground">
            {t("notif.title")}
            {count > 0 && <span className="ms-1.5 text-amber-500">({count})</span>}
          </p>
          {count > 0 && (
            <button
              onClick={markAllRead}
              className="inline-flex items-center gap-1 text-[11px] text-muted-foreground hover:text-emerald-500 transition-colors"
            >
              <Check className="w-3 h-3" /> {t("notif.markAllRead")}
            </button>
          )}
        </div>

        <div className="max-h-80 overflow-y-auto">
          {count === 0 ? (
            <div className="px-3 py-8 text-center">
              <BellOff className="w-6 h-6 mx-auto mb-2 text-muted-foreground" />
              <p className="text-xs text-muted-foreground">{t("notif.empty")}</p>
            </div>
          ) : (
            items.slice(0, 8).map((n) => (
              <div key={n.id} className="px-3 py-2.5 border-b border-border/60 last:border-0">
                <p className={`text-xs font-semibold ${TYPE_COLOR[n.type] || "text-foreground"}`}>
                  {n.title}
                </p>
                <p className="text-[11px] text-muted-foreground mt-0.5 line-clamp-2">{n.message}</p>
              </div>
            ))
          )}
        </div>

        <Link
          to="/ogeysiisyada"
          className="block px-3 py-2.5 text-center text-xs font-semibold text-amber-500 hover:bg-accent border-t border-border transition-colors"
        >
          {t("notif.viewAll")}
        </Link>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}