import React from "react";
import { useNavigate } from "react-router-dom";
import { ChevronDown, Settings, KeyRound, LogOut } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
} from "@/components/ui/dropdown-menu";
import { base44 } from "@/api/base44Client";
import { useT } from "@/lib/i18n";
import { useAuth } from "@/lib/AuthContext";
import SolarKowsarLogo from "@/components/SolarKowsarLogo";

export default function ProfileMenu() {
  const { t } = useT();
  const { user, jobRole } = useAuth();
  const navigate = useNavigate();

  if (!user) return null;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          title={t("profile.title")}
          className="inline-flex items-center gap-2 ps-2 pe-1.5 h-[34px] rounded-lg bg-card hover:bg-accent border border-border transition-colors"
        >
          <span className="hidden sm:inline text-xs font-medium text-foreground max-w-[120px] truncate">
            {user.full_name || user.email}
          </span>
          <SolarKowsarLogo size={20} showText={false} />
          <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-60">
        <div className="px-2 py-2">
          <p className="text-sm font-semibold text-foreground truncate">{user.full_name || "—"}</p>
          <p className="text-xs text-muted-foreground truncate">{user.email}</p>
          <p className="text-[10px] font-semibold uppercase tracking-wider text-amber-500 mt-1">
            {t("profile.role")}: {jobRole || user.role || "—"}
          </p>
        </div>
        <div className="h-px bg-border my-1" />
        <DropdownMenuItem onClick={() => navigate("/boggooyinka")} className="cursor-pointer gap-2">
          <Settings className="w-3.5 h-3.5" />
          {t("profile.settings")}
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => navigate("/forgot-password")} className="cursor-pointer gap-2">
          <KeyRound className="w-3.5 h-3.5" />
          {t("profile.changePassword")}
        </DropdownMenuItem>
        <div className="h-px bg-border my-1" />
        <DropdownMenuItem
          onClick={() => base44.auth.logout("/login")}
          className="cursor-pointer gap-2 text-red-500 focus:text-red-500"
        >
          <LogOut className="w-3.5 h-3.5" />
          {t("profile.logout")}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}