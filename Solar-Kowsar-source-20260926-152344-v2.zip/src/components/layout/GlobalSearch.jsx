import React, { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Search, Users, FileText, Loader2 } from "lucide-react";
import { useT } from "@/lib/i18n";

export default function GlobalSearch() {
  const { t } = useT();
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [customers, setCustomers] = useState([]);
  const [billings, setBillings] = useState([]);
  const [loading, setLoading] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const boxRef = useRef(null);

  const loadData = () => {
    if (loaded || loading) return;
    setLoading(true);
    Promise.all([
      base44.entities.Customer.list("-created_date", 500).catch(() => []),
      base44.entities.Billing.list("-created_date", 500).catch(() => []),
    ])
      .then(([c, b]) => { setCustomers(c); setBillings(b); setLoaded(true); })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    const onClick = (e) => {
      if (boxRef.current && !boxRef.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  const term = q.trim().toLowerCase();
  const customerName = (id) => customers.find((c) => c.id === id)?.full_name || "";

  const customerHits = term.length < 2 ? [] : customers.filter((c) =>
    [c.full_name, c.phone, c.meter_number].filter(Boolean).join(" ").toLowerCase().includes(term)
  ).slice(0, 5);

  const billHits = term.length < 2 ? [] : billings.filter((b) =>
    `${customerName(b.customer)} ${b.billing_month || ""}`.toLowerCase().includes(term)
  ).slice(0, 5);

  const go = (path) => {
    setOpen(false);
    setQ("");
    navigate(path);
  };

  const showPanel = open && term.length >= 2;

  return (
    <div ref={boxRef} className="relative">
      <Search className="absolute start-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground pointer-events-none" />
      <input
        value={q}
        onFocus={() => { setOpen(true); loadData(); }}
        onChange={(e) => { setQ(e.target.value); setOpen(true); loadData(); }}
        placeholder={t("search.placeholder")}
        className="w-36 md:w-56 xl:w-72 ps-9 pe-3 py-2 rounded-lg bg-card border border-border text-foreground text-xs outline-none focus:ring-1 focus:ring-ring placeholder:text-muted-foreground"
      />

      {showPanel && (
        <div className="absolute end-0 mt-2 w-80 max-h-96 overflow-y-auto rounded-xl bg-popover border border-border shadow-xl p-2 z-50">
          {loading && (
            <div className="flex items-center gap-2 px-3 py-4 text-xs text-muted-foreground">
              <Loader2 className="w-3.5 h-3.5 animate-spin" /> {t("search.searching")}
            </div>
          )}

          {!loading && customerHits.length === 0 && billHits.length === 0 && (
            <p className="px-3 py-4 text-xs text-muted-foreground">{t("search.noResults")}</p>
          )}

          {customerHits.length > 0 && (
            <div className="mb-1">
              <p className="px-3 py-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">{t("search.customers")}</p>
              {customerHits.map((c) => (
                <button
                  key={c.id}
                  onClick={() => go(`/macaamiisha?q=${encodeURIComponent(c.full_name || "")}`)}
                  className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-accent text-start transition-colors"
                >
                  <Users className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                  <span className="min-w-0">
                    <span className="block text-xs font-medium text-foreground truncate">{c.full_name}</span>
                    <span className="block text-[11px] text-muted-foreground truncate">
                      {c.phone || "—"} · {t("search.meter")} {c.meter_number || "—"}
                    </span>
                  </span>
                </button>
              ))}
            </div>
          )}

          {billHits.length > 0 && (
            <div>
              <p className="px-3 py-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">{t("search.bills")}</p>
              {billHits.map((b) => (
                <button
                  key={b.id}
                  onClick={() => go(`/billing?q=${encodeURIComponent(b.billing_month || "")}`)}
                  className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-accent text-start transition-colors"
                >
                  <FileText className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                  <span className="min-w-0">
                    <span className="block text-xs font-medium text-foreground truncate">{customerName(b.customer) || "—"}</span>
                    <span className="block text-[11px] text-muted-foreground truncate">
                      {b.billing_month} · ${b.total_amount?.toLocaleString()}
                    </span>
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}