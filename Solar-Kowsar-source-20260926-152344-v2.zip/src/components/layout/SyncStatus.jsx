import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useT } from "@/lib/i18n";

// Entities whose realtime changes mean "the data on screen just refreshed".
const WATCHED = [
  base44.entities.Customer,
  base44.entities.Billing,
  base44.entities.SolarData,
  base44.entities.Alarm,
];

export default function SyncStatus() {
  const { t } = useT();
  const [lastSync, setLastSync] = useState(() => Date.now());
  const [, setTick] = useState(0);

  useEffect(() => {
    const unsubs = WATCHED.map((entity) => {
      try {
        return entity.subscribe(() => setLastSync(Date.now()));
      } catch {
        return null;
      }
    });
    return () => unsubs.forEach((u) => { if (typeof u === "function") u(); });
  }, []);

  // Re-render every 20s so the relative label stays truthful.
  useEffect(() => {
    const id = setInterval(() => setTick((n) => n + 1), 20000);
    return () => clearInterval(id);
  }, []);

  const mins = Math.floor((Date.now() - lastSync) / 60000);
  const live = mins < 1;
  const label = live ? t("sync.now") : t("sync.ago").replace("{n}", String(mins));

  return (
    <div
      className="hidden md:flex items-center gap-2 px-2.5 py-2 rounded-lg bg-card border border-border"
      title={t("sync.title")}
    >
      <span className="relative flex w-2 h-2">
        <span className={`absolute inline-flex w-full h-full rounded-full ${live ? "bg-emerald-400 animate-ping" : "bg-amber-400"}`} />
        <span className={`relative inline-flex w-2 h-2 rounded-full ${live ? "bg-emerald-500" : "bg-amber-500"}`} />
      </span>
      <span className="text-[11px] font-medium text-muted-foreground whitespace-nowrap">
        {live ? t("sync.live") : label}
      </span>
    </div>
  );
}