import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useT } from "@/lib/i18n";
import { useAuth } from "@/lib/AuthContext";
import { useToast } from "@/components/ui/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Bug, Loader2 } from "lucide-react";

const CATEGORIES = ["bug", "suggestion", "question", "other"];
const SEVERITIES = ["low", "medium", "high", "critical"];

const emptyForm = { subject: "", message: "", category: "bug", severity: "medium" };

// Small corner shortcut that lets the company report a problem
// to whoever built the software.
export default function ReportToDeveloper() {
  const { t } = useT();
  const { user } = useAuth();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [busy, setBusy] = useState(false);

  const set = (key, value) => setForm((f) => ({ ...f, [key]: value }));

  const submit = async (e) => {
    e.preventDefault();
    if (!form.subject.trim() || !form.message.trim()) {
      toast({ title: t("dev.error.missing"), variant: "destructive" });
      return;
    }
    setBusy(true);
    try {
      await base44.entities.DeveloperReport.create({
        ...form,
        page: window.location.pathname,
        reported_by_name: user?.full_name || "",
        reported_by_email: user?.email || "",
      });
      setOpen(false);
      setForm(emptyForm);
      toast({ title: t("dev.toast.sent"), description: t("dev.toast.sentDesc") });
    } catch (err) {
      toast({
        title: t("common.error"),
        description: String(err?.message || err),
        variant: "destructive",
      });
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        title={t("dev.title")}
        className="fixed bottom-[4.5rem] start-5 lg:start-[17rem] z-40 w-10 h-10 rounded-full bg-card border border-border text-foreground shadow-xl flex items-center justify-center hover:bg-accent transition-colors"
      >
        <Bug className="w-4 h-4" />
      </button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{t("dev.title")}</DialogTitle>
            <DialogDescription>{t("dev.subtitle")}</DialogDescription>
          </DialogHeader>

          <form onSubmit={submit} className="space-y-4">
            <div className="space-y-1.5">
              <Label>{t("dev.field.subject")}</Label>
              <Input
                value={form.subject}
                onChange={(e) => set("subject", e.target.value)}
                placeholder={t("dev.field.subjectPlaceholder")}
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>{t("dev.field.category")}</Label>
                <Select value={form.category} onValueChange={(v) => set("category", v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map((c) => (
                      <SelectItem key={c} value={c}>
                        {t(`dev.cat.${c}`)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>{t("dev.field.severity")}</Label>
                <Select value={form.severity} onValueChange={(v) => set("severity", v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {SEVERITIES.map((s) => (
                      <SelectItem key={s} value={s}>
                        {t(`dev.severity.${s}`)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-1.5">
              <Label>{t("dev.field.message")}</Label>
              <Textarea
                rows={4}
                value={form.message}
                onChange={(e) => set("message", e.target.value)}
                placeholder={t("dev.field.messagePlaceholder")}
              />
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                {t("common.cancel")}
              </Button>
              <Button
                type="submit"
                disabled={busy}
                className="bg-orange-500 hover:bg-orange-600 text-white"
              >
                {busy && <Loader2 className="w-4 h-4 animate-spin" />}
                {t("dev.submit")}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}