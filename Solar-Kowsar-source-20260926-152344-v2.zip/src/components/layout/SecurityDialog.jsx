import React from "react";
import { ShieldCheck, Smartphone, Globe, KeyRound, Info } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useT } from "@/lib/i18n";
import { useAuth } from "@/lib/AuthContext";

export default function SecurityDialog({ open, onOpenChange }) {
  const { t } = useT();
  const { user, jobRole } = useAuth();

  const methods = [
    { icon: Smartphone, label: "SMS OTP" },
    { icon: KeyRound, label: "Authenticator App" },
    { icon: Globe, label: "Google / Microsoft / Apple" },
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg bg-zinc-900 border-zinc-800 text-white">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-amber-400" />
            {t("security.title")}
          </DialogTitle>
        </DialogHeader>
        <p className="text-zinc-400 text-xs -mt-2">{t("security.subtitle")}</p>

        <div className="rounded-xl bg-amber-500/10 border border-amber-500/25 p-4 flex items-center justify-between gap-3">
          <div>
            <p className="text-white text-sm font-semibold">{t("security.2fa")}</p>
            <p className="text-zinc-400 text-xs mt-0.5">{t("security.notEnabled")}</p>
          </div>
          <span className="px-2.5 py-1 rounded-full text-[10px] font-semibold border bg-amber-500/15 text-amber-400 border-amber-500/25 whitespace-nowrap">
            {t("security.notEnabled")}
          </span>
        </div>

        <div className="flex items-start gap-2 rounded-xl bg-zinc-800/40 border border-zinc-800 p-4">
          <Info className="w-4 h-4 text-blue-400 mt-0.5 shrink-0" />
          <p className="text-zinc-300 text-xs leading-relaxed">{t("security.help")}</p>
        </div>

        <div>
          <p className="text-zinc-500 text-[11px] font-medium uppercase tracking-wider mb-2">{t("security.methods")}</p>
          <div className="space-y-1.5">
            {methods.map((m) => (
              <div key={m.label} className="flex items-center gap-2.5 text-xs text-zinc-300">
                <m.icon className="w-3.5 h-3.5 text-zinc-500" />
                {m.label}
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-xl bg-zinc-800/40 border border-zinc-800 p-4">
          <p className="text-zinc-500 text-[11px] font-medium uppercase tracking-wider mb-2">{t("security.account")}</p>
          <dl className="space-y-1 text-xs">
            <div className="flex justify-between gap-4">
              <dt className="text-zinc-500">Email</dt>
              <dd className="text-zinc-200 truncate">{user?.email || "—"}</dd>
            </div>
            <div className="flex justify-between gap-4">
              <dt className="text-zinc-500">Role</dt>
              <dd className="text-zinc-200">{jobRole || user?.role || "—"}</dd>
            </div>
          </dl>
        </div>

        <DialogFooter>
          <Button onClick={() => onOpenChange(false)} className="bg-amber-500 hover:bg-amber-600 text-black font-semibold">
            {t("security.close")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}