import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";

const empty = {
  name: "", substation: "", serial_number: "", capacity_kva: "",
  current_load_kw: "", temperature: "", location: "", status: "online",
  last_inspection: "", notes: "",
};

export default function TransformerDialog({ open, onOpenChange, editing, substations, onSaved }) {
  const { toast } = useToast();
  const [form, setForm] = useState(empty);

  useEffect(() => {
    if (!open) return;
    setForm(editing ? {
      name: editing.name ?? "", substation: editing.substation ?? "", serial_number: editing.serial_number ?? "",
      capacity_kva: editing.capacity_kva ?? "", current_load_kw: editing.current_load_kw ?? "",
      temperature: editing.temperature ?? "", location: editing.location ?? "", status: editing.status ?? "online",
      last_inspection: editing.last_inspection?.slice(0, 10) ?? "", notes: editing.notes ?? "",
    } : empty);
  }, [open, editing]);

  const submit = async (e) => {
    e.preventDefault();
    const num = (v) => (v === "" ? undefined : Number(v));
    const payload = {
      ...form,
      capacity_kva: num(form.capacity_kva),
      current_load_kw: num(form.current_load_kw),
      temperature: num(form.temperature),
    };
    try {
      if (editing) await base44.entities.Transformer.update(editing.id, payload);
      else await base44.entities.Transformer.create(payload);
      toast({ title: editing ? "Transformer-ka waa la cusboonaysiiyay" : "Transformer cusub waa la abuuray" });
      onOpenChange(false);
      onSaved();
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Lama keydin karin" });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl bg-zinc-900 border-zinc-800 text-white max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{editing ? "Wax Ka Bedel Transformer-ka" : "Transformer Cusub"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Magaca *</Label>
              <Input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" placeholder="TR-01" />
            </div>
            <div className="space-y-2">
              <Label>Xarunta Qeybinta</Label>
              <Select value={form.substation} onValueChange={(v) => setForm({ ...form, substation: v })}>
                <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white"><SelectValue placeholder="Dooro xarun" /></SelectTrigger>
                <SelectContent className="bg-zinc-900 border-zinc-800">
                  {substations.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Awoodda (kVA) *</Label>
              <Input required type="number" value={form.capacity_kva} onChange={(e) => setForm({ ...form, capacity_kva: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" placeholder="400" />
            </div>
            <div className="space-y-2">
              <Label>Culayska Hadda (kW)</Label>
              <Input type="number" value={form.current_load_kw} onChange={(e) => setForm({ ...form, current_load_kw: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" />
            </div>
            <div className="space-y-2">
              <Label>Kulka (°C)</Label>
              <Input type="number" value={form.temperature} onChange={(e) => setForm({ ...form, temperature: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" />
            </div>
            <div className="space-y-2">
              <Label>Xaaladda *</Label>
              <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-zinc-900 border-zinc-800">
                  <SelectItem value="online">Shaqaynaya</SelectItem>
                  <SelectItem value="warning">Digniin</SelectItem>
                  <SelectItem value="overloaded">Culays Badan</SelectItem>
                  <SelectItem value="offline">Damay</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Goobta</Label>
              <Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" />
            </div>
            <div className="space-y-2">
              <Label>Lambarka Siiraadka</Label>
              <Input value={form.serial_number} onChange={(e) => setForm({ ...form, serial_number: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" />
            </div>
            <div className="space-y-2">
              <Label>Baaritaanka U Dambeeyay</Label>
              <Input type="date" value={form.last_inspection} onChange={(e) => setForm({ ...form, last_inspection: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" />
            </div>
            <div className="col-span-2 space-y-2">
              <Label>Qoraalka</Label>
              <Textarea rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="border-zinc-700 text-zinc-300 hover:bg-zinc-800">Jooji</Button>
            <Button type="submit" className="bg-amber-500 hover:bg-amber-600 text-black font-semibold">{editing ? "Cusboonaysii" : "Abuur"}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}