import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";

const empty = { name: "", city: "", address: "", capacity_kva: "", status: "active", commissioned_date: "", notes: "" };

export default function SubstationDialog({ open, onOpenChange, editing, onSaved }) {
  const { toast } = useToast();
  const [form, setForm] = useState(empty);

  useEffect(() => {
    if (!open) return;
    setForm(editing ? {
      name: editing.name ?? "", city: editing.city ?? "", address: editing.address ?? "",
      capacity_kva: editing.capacity_kva ?? "", status: editing.status ?? "active",
      commissioned_date: editing.commissioned_date?.slice(0, 10) ?? "", notes: editing.notes ?? "",
    } : empty);
  }, [open, editing]);

  const submit = async (e) => {
    e.preventDefault();
    const payload = { ...form, capacity_kva: form.capacity_kva === "" ? undefined : Number(form.capacity_kva) };
    try {
      if (editing) await base44.entities.Substation.update(editing.id, payload);
      else await base44.entities.Substation.create(payload);
      toast({ title: editing ? "Xarunta waa la cusboonaysiiyay" : "Xarun cusub waa la abuurtay" });
      onOpenChange(false);
      onSaved();
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Lama keydin karin" });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg bg-zinc-900 border-zinc-800 text-white">
        <DialogHeader>
          <DialogTitle>{editing ? "Wax Ka Bedel Xarunta" : "Xarun Qeybineed Cusub"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Magaca Xarunta *</Label>
              <Input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" placeholder="Substation A" />
            </div>
            <div className="space-y-2">
              <Label>Magaalada *</Label>
              <Input required value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" />
            </div>
            <div className="space-y-2">
              <Label>Awoodda Guud (kVA)</Label>
              <Input type="number" value={form.capacity_kva} onChange={(e) => setForm({ ...form, capacity_kva: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" />
            </div>
            <div className="space-y-2">
              <Label>Xaaladda *</Label>
              <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-zinc-900 border-zinc-800">
                  <SelectItem value="active">Firfircoon</SelectItem>
                  <SelectItem value="maintenance">Dayactir</SelectItem>
                  <SelectItem value="inactive">Joogsan</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Cinwaanka</Label>
              <Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" />
            </div>
            <div className="space-y-2">
              <Label>Taariikhda La Furay</Label>
              <Input type="date" value={form.commissioned_date} onChange={(e) => setForm({ ...form, commissioned_date: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" />
            </div>
            <div className="col-span-2 space-y-2">
              <Label>Qoraalka</Label>
              <Textarea rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="border-zinc-700 text-zinc-300 hover:bg-zinc-800">Jooji</Button>
            <Button type="submit" className="bg-amber-500 hover:bg-amber-600 text-black font-semibold">{editing ? "Cusboonaysii" : "Abuur"}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}