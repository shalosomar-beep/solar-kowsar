import React from "react";
import { Calculator, Zap, Activity, TrendingDown } from "lucide-react";

const money = (n) => `$${Number(n || 0).toLocaleString(undefined, { maximumFractionDigits: 2 })}`;

export default function DiscrepancyCalculator({ dispatched, metered, loss, lossPct, rate }) {
  const bar = Math.min(100, lossPct);

  return (
    <div className="rounded-2xl bg-card border border-border p-5">
      <div className="flex items-center gap-2 mb-4">
        <Calculator className="w-4 h-4 text-orange-400" />
        <div>
          <h2 className="text-foreground font-semibold">Xisaabta Farqiga</h2>
          <p className="text-muted-foreground text-xs mt-0.5">
            Korontada xarunta ka baxday vs tan mitaaradu diiwaangelisay
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="rounded-xl bg-amber-500/10 border border-amber-500/15 p-4">
          <div className="flex items-center gap-1.5 mb-1.5">
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <p className="text-muted-foreground text-[11px] font-medium uppercase tracking-wider">La Diray</p>
          </div>
          <p className="text-amber-400 text-xl font-bold">
            {dispatched.toFixed(1)}
            <span className="text-xs font-medium ms-1">kW</span>
          </p>
        </div>

        <div className="rounded-xl bg-cyan-500/10 border border-cyan-500/15 p-4">
          <div className="flex items-center gap-1.5 mb-1.5">
            <Activity className="w-3.5 h-3.5 text-cyan-400" />
            <p className="text-muted-foreground text-[11px] font-medium uppercase tracking-wider">La Diiwaangeliyay</p>
          </div>
          <p className="text-cyan-400 text-xl font-bold">
            {metered.toFixed(1)}
            <span className="text-xs font-medium ms-1">kW</span>
          </p>
        </div>
      </div>

      <div className="mt-3 rounded-xl bg-red-500/10 border border-red-500/15 p-4">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-1.5">
            <TrendingDown className="w-3.5 h-3.5 text-red-400" />
            <p className="text-muted-foreground text-[11px] font-medium uppercase tracking-wider">Farqiga (La Xaday)</p>
          </div>
          <p className="text-red-400 text-xl font-bold">{loss.toFixed(1)} kW</p>
        </div>

        <div className="mt-3 h-2 rounded-full bg-background overflow-hidden">
          <div className="h-full rounded-full bg-red-500" style={{ width: `${bar}%` }} />
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 mt-2 text-xs">
          <span className="text-muted-foreground">{lossPct.toFixed(1)}% lumid</span>
          {rate > 0 && <span className="text-red-400 font-semibold">{money(loss * 24 * rate)} / maalin</span>}
        </div>
      </div>

      <p className="text-muted-foreground text-[11px] mt-3 leading-relaxed">
        La Diray − La Diiwaangeliyay = Farqi. Farqiga ka badan 15% waxaa loo arkaa tuuganimad ama mitaar cilladaysan.
      </p>
    </div>
  );
}