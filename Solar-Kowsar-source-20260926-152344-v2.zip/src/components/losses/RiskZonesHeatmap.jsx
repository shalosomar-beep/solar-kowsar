import React from "react";
import { Flame } from "lucide-react";
import { useT } from "@/lib/i18n";

const RISK = {
  critical: { labelKey: "riskzones.critical", cls: "bg-red-500/15 text-red-400 border-red-500/30" },
  suspicious: { labelKey: "riskzones.suspicious", cls: "bg-amber-500/15 text-amber-400 border-amber-500/30" },
  watch: { labelKey: "riskzones.watch", cls: "bg-yellow-500/15 text-yellow-400 border-yellow-500/30" },
  normal: { labelKey: "riskzones.normal", cls: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30" },
};

const heat = (pct) =>
  pct >= 25 ? "bg-red-500" : pct >= 15 ? "bg-orange-500" : pct >= 8 ? "bg-amber-500" : "bg-emerald-500";

export default function RiskZonesHeatmap({ zones }) {
  const { t } = useT();
  const ranked = [...zones].sort((a, b) => b.lossPct - a.lossPct).slice(0, 8);

  return (
    <div className="rounded-2xl bg-card border border-border p-5">
      <div className="flex items-center gap-2 mb-4">
        <Flame className="w-4 h-4 text-orange-400" />
        <div>
          <h2 className="text-foreground font-semibold">{t("riskzones.title")}</h2>
          <p className="text-muted-foreground text-xs mt-0.5">{t("riskzones.sub")}</p>
        </div>
      </div>

      {ranked.length === 0 ? (
        <p className="text-muted-foreground text-sm text-center py-10">{t("loss.empty")}</p>
      ) : (
        <div className="space-y-3">
          {ranked.map((z, i) => {
            const r = RISK[z.risk];
            return (
              <div key={z.location} className="flex items-center gap-3">
                <span className="w-4 text-muted-foreground text-xs text-right shrink-0">{i + 1}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <span className="text-foreground text-sm truncate">{z.location}</span>
                    <span className="text-foreground text-sm font-semibold shrink-0">{z.lossPct.toFixed(1)}%</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-background overflow-hidden">
                    <div
                      className={`h-full rounded-full ${heat(z.lossPct)}`}
                      style={{ width: `${Math.min(100, z.lossPct)}%` }}
                    />
                  </div>
                </div>
                <span className={`shrink-0 inline-flex px-2 py-0.5 rounded-full text-[11px] font-medium border ${r.cls}`}>
                  {t(r.labelKey)}
                </span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}