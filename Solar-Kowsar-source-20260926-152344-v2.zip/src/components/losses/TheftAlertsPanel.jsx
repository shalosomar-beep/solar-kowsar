import React from "react";
import { ShieldAlert } from "lucide-react";

// Live stream of theft signals: a meter that stopped reporting while the
// transformer line it sits on is still carrying load.

const SEVERITY = {
  critical: { label: "Halis Sare", cls: "bg-red-500/15 text-red-400 border-red-500/30", dot: "bg-red-500" },
  warning: { label: "Digniin", cls: "bg-amber-500/15 text-amber-400 border-amber-500/30", dot: "bg-amber-500" },
};

export default function TheftAlertsPanel({ alerts }) {
  const critical = alerts.filter((a) => a.severity === "critical").length;

  return (
    <div className="rounded-2xl bg-card border border-border overflow-hidden">
      <div className="p-5 border-b border-border flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-red-400" />
          <div>
            <h2 className="text-foreground font-semibold">Digniinta Tuuganimada</h2>
            <p className="text-muted-foreground text-xs mt-0.5">
              Mitaarada joojiyay isgaarsiinta halka xariiqda transformer-ku culays leh tahay
            </p>
          </div>
        </div>
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-red-500/15 border border-red-500/30 text-red-400 text-xs font-medium">
          <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
          {alerts.length} toos · {critical} halis sare
        </span>
      </div>

      <div className="divide-y divide-border max-h-80 overflow-y-auto">
        {alerts.length === 0 ? (
          <div className="p-8 text-center text-muted-foreground text-sm">
            Ma jiro digniin toos ah — mitaarada oo dhan way shaqeynayaan.
          </div>
        ) : (
          alerts.map((a) => {
            const sev = SEVERITY[a.severity];
            return (
              <div key={a.id} className="p-4 flex items-start gap-3 hover:bg-accent/30 transition-colors">
                <span className={`mt-1.5 w-2 h-2 rounded-full shrink-0 ${sev.dot}`} />
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-foreground font-medium text-sm">{a.meter}</span>
                    <span className={`inline-flex px-2 py-0.5 rounded-full text-[11px] font-medium border ${sev.cls}`}>
                      {sev.label}
                    </span>
                  </div>
                  <p className="text-muted-foreground text-xs mt-1 truncate">
                    {a.customer} · {a.location}
                  </p>
                  <p className="text-muted-foreground text-xs mt-1">{a.reason}</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-foreground text-sm font-semibold">{a.load.toFixed(1)} kW</p>
                  <p className="text-muted-foreground text-[11px]">xariiqda {a.dispatched.toFixed(1)} kW</p>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}