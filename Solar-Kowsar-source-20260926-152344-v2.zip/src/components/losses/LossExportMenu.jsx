import React from "react";
import { Button } from "@/components/ui/button";
import { FileSpreadsheet, Printer } from "lucide-react";
import { exportCsv, exportPdf } from "@/utils/dataExport";

const RISK_LABEL = {
  critical: "Halis Sare",
  suspicious: "Shaki Leh",
  watch: "La Soco",
  normal: "Caadi",
};

const COLUMNS = [
  "Goobta",
  "Ka baxay xarunta (kW)",
  "Mitaarada (kW)",
  "Farqi (kW)",
  "Farqi %",
  "Qiimaha/Maalin ($)",
  "Heerka Halista",
];

const slugify = (v) =>
  String(v || "dhammaan-goobaha")
    .replace(/[^a-zA-Z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .toLowerCase();

export default function LossExportMenu({ zones, rate, scopeLabel }) {
  const rows = zones.map((z) => [
    z.location,
    z.dispatched.toFixed(2),
    z.metered.toFixed(2),
    z.loss.toFixed(2),
    z.lossPct.toFixed(1),
    rate > 0 ? z.dailyValue.toFixed(2) : "—",
    RISK_LABEL[z.risk] || "—",
  ]);

  const slug = slugify(scopeLabel);
  const disabled = rows.length === 0;

  return (
    <div className="flex items-center gap-2">
      <Button
        variant="outline"
        disabled={disabled}
        onClick={() => exportCsv(`xisaabinta-la-xaday-${slug}`, COLUMNS, rows)}
        className="gap-2"
      >
        <FileSpreadsheet className="w-4 h-4" /> CSV
      </Button>
      <Button
        variant="outline"
        disabled={disabled}
        onClick={() =>
          exportPdf(`xisaabinta-la-xaday-${slug}`, "Xisaabinta Tamarta La Xaday", COLUMNS, rows)
        }
        className="gap-2"
      >
        <Printer className="w-4 h-4" /> PDF
      </Button>
    </div>
  );
}