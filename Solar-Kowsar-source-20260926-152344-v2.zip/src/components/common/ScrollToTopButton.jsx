import React, { useState, useEffect } from "react";
import { ArrowUp } from "lucide-react";
import { useT } from "@/lib/i18n";

// Floating shortcut back to the top of long pages.
export default function ScrollToTopButton() {
  const { t } = useT();
  const [show, setShow] = useState(false);

  useEffect(() => {
    const onScroll = () => setShow(window.scrollY > 400);
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  if (!show) return null;

  return (
    <button
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      title={t("scroll.top")}
      className="fixed bottom-5 start-5 lg:start-[17rem] z-40 w-10 h-10 rounded-full bg-card border border-border text-foreground shadow-xl flex items-center justify-center hover:bg-accent transition-colors"
    >
      <ArrowUp className="w-4 h-4" />
    </button>
  );
}