import React from "react";
import { AlertTriangle, RefreshCw } from "lucide-react";
import { useT } from "@/lib/i18n";

// Shown when data could not be pulled from the server (offline / request failed).
export default function DataErrorState({ onRetry, title, description }) {
  const { t } = useT();

  return (
    <div className="rounded-2xl border border-red-500/30 bg-red-500/5 p-8 text-center">
      <AlertTriangle className="w-10 h-10 mx-auto mb-3 text-red-500" />
      <p className="text-sm font-semibold text-foreground">{title || t("error.title")}</p>
      <p className="text-xs text-muted-foreground mt-1 max-w-sm mx-auto">{description || t("error.desc")}</p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-red-500 hover:bg-red-600 text-white text-xs font-semibold transition-colors"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          {t("common.retry")}
        </button>
      )}
    </div>
  );
}