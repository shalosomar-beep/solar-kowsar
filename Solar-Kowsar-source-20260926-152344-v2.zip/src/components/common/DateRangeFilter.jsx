import React from "react";
import { useT } from "@/lib/i18n";

const RANGES = ["week", "month", "year", "all"];

// Segmented control for narrowing charts and lists to a period.
export default function DateRangeFilter({ value, onChange }) {
  const { t } = useT();

  return (
    <div className="inline-flex items-center gap-1 p-1 rounded-xl bg-card border border-border">
      {RANGES.map((r) => (
        <button
          key={r}
          onClick={() => onChange(r)}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
            value === r ? "bg-amber-500 text-black" : "text-muted-foreground hover:bg-accent"
          }`}
        >
          {t(`range.${r}`)}
        </button>
      ))}
    </div>
  );
}