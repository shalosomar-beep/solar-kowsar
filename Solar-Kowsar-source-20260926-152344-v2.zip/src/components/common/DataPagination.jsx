import React from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useT } from "@/lib/i18n";

function pageNumbers(page, pageCount) {
  if (pageCount <= 7) return Array.from({ length: pageCount }, (_, i) => i + 1);
  const nums = [...new Set([1, pageCount, page - 1, page, page + 1])]
    .filter((n) => n >= 1 && n <= pageCount)
    .sort((a, b) => a - b);
  const out = [];
  nums.forEach((n, i) => {
    if (i > 0 && n - nums[i - 1] > 1) out.push("gap");
    out.push(n);
  });
  return out;
}

const btn = "min-w-8 h-8 px-2 rounded-lg border text-xs font-semibold transition-colors";

export default function DataPagination({ page, pageCount, total, from, to, onPage }) {
  const { t } = useT();
  if (!total) return null;

  return (
    <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4">
      <p className="text-xs text-muted-foreground">{t("page.showing", { from, to, total })}</p>

      {pageCount > 1 && (
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => onPage(page - 1)}
            disabled={page <= 1}
            className={`${btn} inline-flex items-center gap-1 bg-card border-border text-muted-foreground hover:bg-accent disabled:opacity-40 disabled:pointer-events-none`}
          >
            <ChevronLeft className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{t("page.prev")}</span>
          </button>

          {pageNumbers(page, pageCount).map((n, i) =>
            n === "gap" ? (
              <span key={`gap-${i}`} className="px-1 text-xs text-muted-foreground">…</span>
            ) : (
              <button
                key={n}
                onClick={() => onPage(n)}
                className={`${btn} ${
                  n === page
                    ? "bg-amber-500 border-amber-500 text-black"
                    : "bg-card border-border text-muted-foreground hover:bg-accent"
                }`}
              >
                {n}
              </button>
            )
          )}

          <button
            onClick={() => onPage(page + 1)}
            disabled={page >= pageCount}
            className={`${btn} inline-flex items-center gap-1 bg-card border-border text-muted-foreground hover:bg-accent disabled:opacity-40 disabled:pointer-events-none`}
          >
            <span className="hidden sm:inline">{t("page.next")}</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
}