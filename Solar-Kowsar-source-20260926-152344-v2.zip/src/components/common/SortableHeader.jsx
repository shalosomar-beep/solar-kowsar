import React from "react";
import { ArrowUp, ArrowDown, ArrowUpDown } from "lucide-react";

// Table header cell that toggles ascending / descending order for its column.
export default function SortableHeader({ label, sortKey, sort, onSort, className = "" }) {
  const active = sort?.key === sortKey;
  const Icon = !active ? ArrowUpDown : sort.dir === "asc" ? ArrowUp : ArrowDown;

  return (
    <th className={className}>
      <button
        onClick={() => onSort(sortKey)}
        className={`inline-flex items-center gap-1 uppercase tracking-wider transition-colors ${
          active ? "text-amber-500" : "hover:text-foreground"
        }`}
      >
        {label}
        <Icon className={`w-3 h-3 ${active ? "" : "opacity-40"}`} />
      </button>
    </th>
  );
}