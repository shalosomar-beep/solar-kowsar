import React from "react";
import { Download, Image as ImageIcon, FileSpreadsheet } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
} from "@/components/ui/dropdown-menu";
import { useT } from "@/lib/i18n";
import { useTheme } from "@/lib/theme";
import { exportChartPng } from "@/utils/chartExport";
import { exportCsv } from "@/utils/dataExport";

// Small corner menu that lets staff pull a chart out of the app as an image
// or as the underlying data in CSV.
export default function ChartExportMenu({ chartRef, filename, title, columns, rows }) {
  const { t } = useT();
  const { theme } = useTheme();

  const downloadPng = () => {
    exportChartPng(chartRef.current, filename, theme === "dark" ? "#18181b" : "#ffffff");
  };

  const downloadCsv = () => {
    exportCsv(filename, columns, rows);
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          title={t("chart.export")}
          className="inline-flex items-center justify-center p-2 rounded-lg bg-accent hover:bg-accent/70 border border-border text-muted-foreground transition-colors"
        >
          <Download className="w-3.5 h-3.5" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuItem onClick={downloadPng} className="cursor-pointer gap-2">
          <ImageIcon className="w-3.5 h-3.5" />
          {t("chart.exportPng")}
        </DropdownMenuItem>
        <DropdownMenuItem onClick={downloadCsv} className="cursor-pointer gap-2">
          <FileSpreadsheet className="w-3.5 h-3.5" />
          {t("chart.exportCsv")}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}