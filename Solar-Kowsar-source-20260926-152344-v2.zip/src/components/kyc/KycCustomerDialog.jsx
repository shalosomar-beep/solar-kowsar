import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Upload, Loader2, Eye, CheckCircle2, XCircle, Trash2, ShieldCheck, ShieldAlert, Clock, Paperclip } from "lucide-react";

export const DOC_TYPES = {
  passport: "Baasaboor",
  national_id: "Kaarka Aqoonsiga",
  driver_license: "Laysinka Darawalnimo",
  house_document: "Warqadda Guriga",
  utility_bill: "Biilka Korontada/Biyaha",
  location_map: "Khariidada Guriga",
  photo: "Sawir",
  other: "Kale",
};

const STATUS = {
  pending: { label: "Sugaya", cls: "bg-amber-500/15 text-amber-400 border-amber-500/25", icon: Clock },
  verified: { label: "La Hubiyay", cls: "bg-emerald-500/15 text-emerald-400 border-emerald-500/25", icon: ShieldCheck },
  rejected: { label: "La Diiday", cls: "bg-red-500/15 text-red-400 border-red-500/25", icon: ShieldAlert },
};

export default function KycCustomerDialog({ open, onOpenChange, customer, documents, onChanged }) {
  const { toast } = useToast();
  const [form, setForm] = useState({ document_type: "national_id", document_number: "", notes: "" });
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    if (open) setForm({ document_type: "national_id", document_number: "", notes: "" });
  }, [open, customer]);

  const addDocument = async (e) => {
    e.preventDefault();
    const file = e.target.file?.files?.[0];
    if (!file) {
      toast({ variant: "destructive", title: "Khalad", description: "Fadlan dooro fayl" });
      return;
    }
    setUploading(true);
    try {
      const { file_uri } = await base44.integrations.Core.UploadPrivateFile({ file });
      await base44.entities.KycDocument.create({
        customer: customer.id,
        customer_name: customer.full_name,
        document_type: form.document_type,
        document_number: form.document_number,
        notes: form.notes,
        file_uri,
        file_name: file.name,
        status: "pending",
      });
      toast({ title: "Dukumentiga waa la soo geliyay" });
      e.target.reset();
      setForm({ document_type: "national_id", document_number: "", notes: "" });
      onChanged();
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Faylka lama soo gelin karin" });
    } finally {
      setUploading(false);
    }
  };

  const viewFile = async (doc) => {
    try {
      const { signed_url } = await base44.integrations.Core.CreateFileSignedUrl({ file_uri: doc.file_uri, expires_in: 300 });
      window.open(signed_url, "_blank");
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Faylka lama furi karin" });
    }
  };

  const setStatus = async (doc, status) => {
    try {
      const me = await base44.auth.me();
      await base44.entities.KycDocument.update(doc.id, {
        status,
        verified_by: me?.full_name || me?.email || "",
        verification_date: new Date().toISOString().slice(0, 10),
      });
      toast({ title: status === "verified" ? "Dukumentiga waa la hubiyay" : "Dukumentiga waa la diiday" });
      onChanged();
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Lama cusboonaysiin karin" });
    }
  };

  const removeDoc = async (doc) => {
    if (!confirm("Ma hubtaa inaad tirtirto dukumentigan?")) return;
    try {
      await base44.entities.KycDocument.delete(doc.id);
      toast({ title: "Waa la tirtiray" });
      onChanged();
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Lama tirtiri karo" });
    }
  };

  if (!customer) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl bg-zinc-900 border-zinc-800 text-white max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{customer.full_name}</DialogTitle>
        </DialogHeader>
        <p className="text-zinc-400 text-xs -mt-2">{customer.phone} · Mitaar {customer.meter_number || "—"}</p>

        <div className="space-y-3">
          <h3 className="text-white text-sm font-semibold">Dukumentiyada La Soo Geliyay</h3>
          {documents.length === 0 ? (
            <p className="text-zinc-500 text-xs py-4 text-center border border-dashed border-zinc-800 rounded-xl">Weli dukumenti lama soo gelin</p>
          ) : (
            documents.map((d) => {
              const s = STATUS[d.status] || STATUS.pending;
              const Icon = s.icon;
              return (
                <div key={d.id} className="rounded-xl bg-zinc-800/40 border border-zinc-800 p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="text-white text-sm font-medium">{DOC_TYPES[d.document_type] || d.document_type}</p>
                      <p className="text-zinc-500 text-xs mt-0.5">
                        {d.document_number || "Lambarka lama gelin"}
                        {d.file_name ? ` · ${d.file_name}` : ""}
                      </p>
                      {d.verified_by && <p className="text-zinc-600 text-[11px] mt-1">La hubiyay: {d.verified_by} · {d.verification_date}</p>}
                    </div>
                    <span className={`shrink-0 px-2.5 py-1 rounded-full text-[10px] font-semibold border flex items-center gap-1 ${s.cls}`}>
                      <Icon className="w-3 h-3" /> {s.label}
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-2 mt-3">
                    {d.file_uri && (
                      <Button size="sm" variant="outline" onClick={() => viewFile(d)} className="border-zinc-700 text-zinc-200 hover:bg-zinc-800 h-8">
                        <Eye className="w-3.5 h-3.5 mr-1.5" /> Eeg Faylka
                      </Button>
                    )}
                    {d.status !== "verified" && (
                      <Button size="sm" onClick={() => setStatus(d, "verified")} className="bg-emerald-600 hover:bg-emerald-700 text-white h-8">
                        <CheckCircle2 className="w-3.5 h-3.5 mr-1.5" /> Hubi
                      </Button>
                    )}
                    {d.status !== "rejected" && (
                      <Button size="sm" variant="outline" onClick={() => setStatus(d, "rejected")} className="border-red-500/40 text-red-400 hover:bg-red-500/10 h-8">
                        <XCircle className="w-3.5 h-3.5 mr-1.5" /> Diid
                      </Button>
                    )}
                    <Button size="sm" variant="ghost" onClick={() => removeDoc(d)} className="text-zinc-400 hover:text-red-400 h-8 ml-auto">
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        <form onSubmit={addDocument} className="space-y-4 pt-4 border-t border-zinc-800">
          <h3 className="text-white text-sm font-semibold flex items-center gap-2">
            <Paperclip className="w-4 h-4 text-amber-400" /> Ku Dar Dukumenti Cusub
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-zinc-400 text-xs">Nooca Aqoonsiga *</Label>
              <Select value={form.document_type} onValueChange={(v) => setForm({ ...form, document_type: v })}>
                <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-zinc-900 border-zinc-800">
                  {Object.entries(DOC_TYPES).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="text-zinc-400 text-xs">Lambarka Aqoonsiga</Label>
              <Input value={form.document_number} onChange={(e) => setForm({ ...form, document_number: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" />
            </div>
            <div className="col-span-2 space-y-2">
              <Label className="text-zinc-400 text-xs">Faylka (Sawir ama PDF) *</Label>
              <input
                type="file"
                name="file"
                accept="image/*,.pdf"
                className="w-full text-xs text-zinc-400 file:mr-3 file:py-2 file:px-4 file:rounded-md file:border-0 file:bg-zinc-800 file:text-zinc-200 hover:file:bg-zinc-700 file:cursor-pointer"
              />
              <p className="text-zinc-600 text-[11px]">Faylasha aqoonsiga waxaa lagu kaydiyaa kayd gaar ah oo ammaan ah.</p>
            </div>
          </div>
          <div className="flex justify-end">
            <Button type="submit" disabled={uploading} className="bg-amber-500 hover:bg-amber-600 text-black font-semibold">
              {uploading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Soo Geliyaya...</> : <><Upload className="w-4 h-4 mr-2" /> Soo Geli</>}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}