import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Home, Building2, Factory, Users, Zap, DollarSign, Search } from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from "recharts";
import { useT } from "@/lib/i18n";

const SEGMENTS = {
  residential: { labelKey: "seg.residential", shortKey: "seg.residential.short", icon: Home, color: "#3b82f6", cls: "bg-blue-500/15 text-blue-400" },
  commercial: { labelKey: "seg.commercial", shortKey: "seg.commercial.short", icon: Building2, color: "#f59e0b", cls: "bg-amber-500/15 text-amber-400" },
  industrial: { labelKey: "seg.industrial", shortKey: "seg.industrial.short", icon: Factory, color: "#8b5cf6", cls: "bg-purple-500/15 text-purple-400" },
};

export default function QaybahaMacaamiisha() {
  const { t } = useT();
  const { toast } = useToast();
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [segFilter, setSegFilter] = useState("all");

  useEffect(() => {
    base44.entities.Customer.list("-created_date", 300)
      .then(setCustomers)
      .catch(() => toast({ variant: "destructive", title: t("common.error"), description: t("seg.error.load") }))
      .finally(() => setLoading(false));
  }, []);

  const stats = Object.keys(SEGMENTS).map((key) => {
    const list = customers.filter((c) => (c.customer_type || "residential") === key);
    return {
      key,
      count: list.length,
      capacity: list.reduce((s, c) => s + (c.solar_capacity_kw || 0), 0),
      revenue: list.reduce((s, c) => s + (c.monthly_rate || 0), 0),
    };
  });

  const totalRevenue = stats.reduce((s, x) => s + x.revenue, 0);
  const totalCapacity = stats.reduce((s, x) => s + x.capacity, 0);

  const pieData = stats.filter((s) => s.count > 0).map((s) => ({
    name: t(SEGMENTS[s.key].shortKey),
    value: s.count,
    color: SEGMENTS[s.key].color,
  }));

  const changeSegment = async (customer, type) => {
    try {
      await base44.entities.Customer.update(customer.id, { customer_type: type });
      setCustomers((prev) => prev.map((c) => (c.id === customer.id ? { ...c, customer_type: type } : c)));
      toast({ title: t("seg.toast.changed") });
    } catch {
      toast({ variant: "destructive", title: t("common.error"), description: t("seg.error.update") });
    }
  };

  const filtered = customers.filter((c) => {
    const q = search.toLowerCase();
    const matchQ = !q || c.full_name?.toLowerCase().includes(q) || c.city?.toLowerCase().includes(q) || c.meter_number?.toLowerCase().includes(q);
    const matchSeg = segFilter === "all" || (c.customer_type || "residential") === segFilter;
    return matchQ && matchSeg;
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">{t("seg.title")}</h1>
        <p className="text-zinc-400 text-sm mt-1">{t("seg.subtitle")}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {stats.map((s) => {
          const seg = SEGMENTS[s.key];
          const Icon = seg.icon;
          return (
            <div key={s.key} className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-5">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${seg.cls}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-white font-semibold text-sm">{t(seg.labelKey)}</h3>
                    <p className="text-zinc-500 text-xs">
                      {t("seg.revenueShare", { pct: totalRevenue > 0 ? ((s.revenue / totalRevenue) * 100).toFixed(1) : 0 })}
                    </p>
                  </div>
                </div>
                <p className="text-2xl font-bold text-white">{s.count}</p>
              </div>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-zinc-500 text-xs flex items-center gap-1"><Zap className="w-3 h-3" /> {t("seg.capacity")}</p>
                  <p className="text-zinc-200">{s.capacity.toFixed(1)} KW</p>
                </div>
                <div>
                  <p className="text-zinc-500 text-xs flex items-center gap-1"><DollarSign className="w-3 h-3" /> {t("seg.revenuePerMonth")}</p>
                  <p className="text-zinc-200">${s.revenue.toLocaleString()}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-6">
          <h3 className="text-white font-semibold mb-1">{t("seg.distribution.title")}</h3>
          <p className="text-zinc-500 text-xs mb-4">{t("seg.distribution.sub")}</p>
          {pieData.length > 0 ? (
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label={(e) => e.value}>
                    {pieData.map((d) => <Cell key={d.name} fill={d.color} />)}
                  </Pie>
                  <Tooltip contentStyle={{ background: "#18181b", border: "1px solid #3f3f46", borderRadius: "12px", color: "#fff" }} />
                  <Legend wrapperStyle={{ fontSize: "12px" }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="h-64 flex items-center justify-center text-zinc-600 text-sm">{t("seg.empty")}</div>
          )}
        </div>

        <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-6">
          <h3 className="text-white font-semibold mb-1">{t("seg.capacityChart.title")}</h3>
          <p className="text-zinc-500 text-xs mb-4">{t("seg.capacityChart.sub")}</p>
          <div className="space-y-4 mt-2">
            {stats.map((s) => {
              const seg = SEGMENTS[s.key];
              const pct = totalCapacity > 0 ? (s.capacity / totalCapacity) * 100 : 0;
              return (
                <div key={s.key}>
                  <div className="flex items-center justify-between text-sm mb-1.5">
                    <span className="text-zinc-300">{t(seg.labelKey)}</span>
                    <span className="text-zinc-400">{s.capacity.toFixed(1)} KW</span>
                  </div>
                  <div className="h-2.5 bg-zinc-800 rounded-full overflow-hidden">
                    <div className="h-full rounded-full" style={{ width: `${pct}%`, background: seg.color }} />
                  </div>
                </div>
              );
            })}
          </div>
          <div className="mt-6 pt-4 border-t border-zinc-800 flex items-center justify-between">
            <span className="text-zinc-400 text-sm flex items-center gap-2"><Users className="w-4 h-4" /> {t("seg.totalCustomers")}</span>
            <span className="text-white font-bold">{customers.length}</span>
          </div>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
          <Input
            placeholder={t("seg.searchPlaceholder")}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 bg-zinc-900 border-zinc-800 text-white placeholder:text-zinc-600"
          />
        </div>
        <Select value={segFilter} onValueChange={setSegFilter}>
          <SelectTrigger className="w-52 bg-zinc-900 border-zinc-800 text-white"><SelectValue /></SelectTrigger>
          <SelectContent className="bg-zinc-900 border-zinc-800">
            <SelectItem value="all">{t("seg.filter.all")}</SelectItem>
            {Object.entries(SEGMENTS).map(([v, s]) => <SelectItem key={v} value={v}>{t(s.labelKey)}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 overflow-hidden">
        {loading ? (
          <div className="py-16 flex items-center justify-center">
            <div className="w-8 h-8 border-4 border-amber-500/30 border-t-amber-500 rounded-full animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="py-16 text-center text-zinc-500 text-sm">{t("seg.empty")}</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-zinc-800 text-zinc-400 text-xs uppercase tracking-wider">
                  <th className="text-left px-5 py-3 font-medium">{t("seg.col.customer")}</th>
                  <th className="text-left px-5 py-3 font-medium">{t("seg.col.city")}</th>
                  <th className="text-left px-5 py-3 font-medium">{t("seg.col.meter")}</th>
                  <th className="text-right px-5 py-3 font-medium">{t("seg.col.capacity")}</th>
                  <th className="text-right px-5 py-3 font-medium">{t("seg.col.rate")}</th>
                  <th className="text-left px-5 py-3 font-medium">{t("seg.col.segment")}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/50">
                {filtered.map((c) => (
                  <tr key={c.id} className="hover:bg-zinc-900/50 transition-colors">
                    <td className="px-5 py-3 text-white font-medium">{c.full_name}</td>
                    <td className="px-5 py-3 text-zinc-400">{c.city || "—"}</td>
                    <td className="px-5 py-3 text-zinc-400">{c.meter_number || "—"}</td>
                    <td className="px-5 py-3 text-right text-zinc-300">{c.solar_capacity_kw ?? "—"}</td>
                    <td className="px-5 py-3 text-right text-zinc-300">{c.monthly_rate != null ? `$${c.monthly_rate}` : "—"}</td>
                    <td className="px-5 py-3">
                      <Select value={c.customer_type || "residential"} onValueChange={(v) => changeSegment(c, v)}>
                        <SelectTrigger className="w-40 h-8 bg-zinc-800 border-zinc-700 text-white text-xs"><SelectValue /></SelectTrigger>
                        <SelectContent className="bg-zinc-900 border-zinc-800">
                          {Object.entries(SEGMENTS).map(([v, s]) => <SelectItem key={v} value={v}>{t(s.labelKey)}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}