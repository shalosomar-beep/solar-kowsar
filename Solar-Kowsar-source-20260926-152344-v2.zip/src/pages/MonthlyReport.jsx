import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import {
  Zap, Activity, DollarSign, TrendingUp, Users, FileDown, FileText, PiggyBank, Loader2,
} from "lucide-react";
import { exportCsv, exportPdf } from "@/utils/dataExport";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";

const MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const MONTH_NAMES_SO = ["Jannaayo", "Febraayo", "Maarso", "Abriil", "Maayo", "Juun", "Luulyo", "Agoosto", "Sebtembar", "Oktoobar", "Nofembar", "Desembar"];

const monthKey = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
const fullLabel = (key) => {
  const [y, m] = key.split("-").map(Number);
  return `${MONTH_NAMES_SO[m - 1]} ${y}`;
};
const shortLabel = (key) => {
  const [y, m] = key.split("-").map(Number);
  return `${MONTH_NAMES[m - 1]} ${String(y).slice(2)}`;
};

const EXPORT_COLUMNS = ["Macmiilka", "Mitaarka", "kWh", "Biil ($)", "La Bixiyay ($)", "Harsan ($)"];

export default function MonthlyReport() {
  const { toast } = useToast();
  const [solarData, setSolarData] = useState([]);
  const [dailyUsage, setDailyUsage] = useState([]);
  const [billing, setBilling] = useState([]);
  const [expenses, setExpenses] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);

  const months = useMemo(() => {
    const arr = [];
    const now = new Date();
    for (let i = 0; i < 12; i++) {
      arr.push(monthKey(new Date(now.getFullYear(), now.getMonth() - i, 1)));
    }
    return arr;
  }, []);
  const [month, setMonth] = useState(months[0]);

  const load = () => {
    setLoading(true);
    Promise.all([
      base44.entities.SolarData.list("-usage_date", 1000),
      base44.entities.DailyUsage.list("-usage_date", 2000),
      base44.entities.Billing.list("-created_date", 2000),
      base44.entities.Expense.list("-expense_date", 1000),
      base44.entities.Customer.list(),
    ])
      .then(([sd, du, bi, ex, cu]) => {
        setSolarData(sd);
        setDailyUsage(du);
        setBilling(bi);
        setExpenses(ex);
        setCustomers(cu);
      })
      .catch(() => toast({ variant: "destructive", title: "Khalad", description: "Xogta warbixinta lama keeni karin" }))
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const custMap = useMemo(() => {
    const m = {};
    customers.forEach((c) => { m[c.id] = c; });
    return m;
  }, [customers]);

  const rows = useMemo(() => {
    const map = {};
    const ensure = (id) => {
      if (!map[id]) map[id] = { kwh: 0, billed: 0, paid: 0, outstanding: 0 };
      return map[id];
    };
    dailyUsage.filter((u) => u.usage_date?.startsWith(month)).forEach((u) => {
      if (!u.customer) return;
      ensure(u.customer).kwh += Number(u.kwh_used || 0);
    });
    billing.filter((b) => b.billing_month === month).forEach((b) => {
      if (!b.customer) return;
      const amt = Number(b.total_amount || 0);
      const row = ensure(b.customer);
      row.billed += amt;
      if (b.status === "paid") row.paid += amt;
      else if (b.status !== "cancelled") row.outstanding += amt;
    });
    return Object.entries(map)
      .map(([id, v]) => ({
        id,
        name: custMap[id]?.full_name || "—",
        meter: custMap[id]?.meter_number || "—",
        kwh: Number(v.kwh.toFixed(1)),
        billed: Number(v.billed.toFixed(2)),
        paid: Number(v.paid.toFixed(2)),
        outstanding: Number(v.outstanding.toFixed(2)),
      }))
      .sort((a, b) => b.billed - a.billed);
  }, [month, dailyUsage, billing, custMap]);

  const production = solarData
    .filter((s) => s.usage_date?.startsWith(month))
    .reduce((s, r) => s + Number(r.production_kwh || 0), 0);
  const metered = rows.reduce((s, r) => s + r.kwh, 0);
  const billed = rows.reduce((s, r) => s + r.billed, 0);
  const collected = rows.reduce((s, r) => s + r.paid, 0);
  const outstanding = rows.reduce((s, r) => s + r.outstanding, 0);
  const monthExpenses = expenses
    .filter((e) => e.expense_date?.startsWith(month))
    .reduce((s, e) => s + Number(e.amount || 0), 0);
  const net = collected - monthExpenses;

  const chartData = useMemo(() => {
    return months.slice(0, 6).reverse().map((m) => {
      const bills = billing.filter((b) => b.billing_month === m && b.status !== "cancelled");
      const billedSum = bills.reduce((s, b) => s + Number(b.total_amount || 0), 0);
      const paidSum = bills
        .filter((b) => b.status === "paid")
        .reduce((s, b) => s + Number(b.total_amount || 0), 0);
      return {
        name: shortLabel(m),
        Biilasha: Number(billedSum.toFixed(2)),
        "La Ururiyay": Number(paidSum.toFixed(2)),
      };
    });
  }, [billing, months]);

  const exportRows = rows.map((r) => [r.name, r.meter, r.kwh, r.billed, r.paid, r.outstanding]);

  const handleExport = (kind) => {
    const title = `Warbixin Bishii - ${fullLabel(month)}`;
    if (kind === "csv") exportCsv(`warbixin-${month}`, EXPORT_COLUMNS, exportRows);
    else exportPdf(`warbixin-${month}`, title, EXPORT_COLUMNS, exportRows);
  };

  const generateBills = async () => {
    setGenerating(true);
    try {
      const res = await base44.functions.invoke("generateMonthlyBills", { billing_month: month });
      const d = res.data || {};
      toast({
        title: "Biilasha waa la soo saaray",
        description: `${d.bills_created || 0} biil cusub · ${d.bills_skipped || 0} la booday`,
      });
      load();
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Biilasha lama soo saari karin" });
    } finally {
      setGenerating(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-24">
        <div className="w-8 h-8 border-4 border-amber-500/30 border-t-amber-500 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Warbixinta Bishii</h1>
          <p className="text-muted-foreground text-sm mt-1">
            Warbixin dhammaystiran oo bishii: wax-soo-saarka, dakhliga iyo isticmaalka macaamiisha
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Select value={month} onValueChange={setMonth}>
            <SelectTrigger className="w-48 bg-card border-border text-foreground"><SelectValue /></SelectTrigger>
            <SelectContent>
              {months.map((m) => (
                <SelectItem key={m} value={m}>{fullLabel(m)}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button variant="outline" onClick={() => handleExport("csv")} className="gap-2 border-border">
            <FileDown className="w-4 h-4" /> CSV
          </Button>
          <Button variant="outline" onClick={() => handleExport("pdf")} className="gap-2 border-border">
            <FileText className="w-4 h-4" /> PDF
          </Button>
          <Button onClick={generateBills} disabled={generating} className="gap-2 bg-orange-500 hover:bg-orange-600 text-white">
            {generating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
            Soo Saar Biilasha
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <ReportCard icon={Zap} label="Tamarta La Soo Saaray" value={`${production.toFixed(1)} kWh`} sub={`Solar-ka bisha ${fullLabel(month)}`} accent="text-amber-400" />
        <ReportCard icon={Activity} label="Tamarta La Isticmaalay" value={`${metered.toFixed(1)} kWh`} sub={`${rows.length} macmiil`} accent="text-cyan-400" />
        <ReportCard icon={Users} label="Macaamiisha Firfircoon" value={rows.length} sub="Diiwaan isticmaal leh" accent="text-purple-400" />
        <ReportCard icon={FileText} label="Biilasha La Soo Saaray" value={`$${billed.toFixed(2)}`} sub="Wadarta biilasha bisha" accent="text-blue-400" />
        <ReportCard icon={DollarSign} label="Dakhliga La Ururiyay" value={`$${collected.toFixed(2)}`} sub={`$${outstanding.toFixed(2)} wali harsan`} accent="text-emerald-400" />
        <ReportCard icon={PiggyBank} label="Faa'iidada Saafiga" value={`$${net.toFixed(2)}`} sub={`Kharashaad $${monthExpenses.toFixed(2)}`} accent={net >= 0 ? "text-emerald-400" : "text-red-400"} />
      </div>

      <div className="rounded-2xl bg-card border border-border p-5">
        <h2 className="text-foreground font-semibold flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-emerald-400" />
          Biilasha vs Lacagta La Ururiyay
        </h2>
        <p className="text-muted-foreground text-xs mb-4">6 bilood ee ugu dambeeyay</p>
        <div style={{ width: "100%", height: 280 }}>
          <ResponsiveContainer>
            <BarChart data={chartData} margin={{ top: 4, right: 8, left: -18, bottom: 4 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="name" tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{ background: "hsl(var(--popover))", border: "1px solid hsl(var(--border))", borderRadius: 12 }}
                formatter={(v) => `$${v}`}
              />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Bar dataKey="Biilasha" fill="#f59e0b" radius={[6, 6, 0, 0]} />
              <Bar dataKey="La Ururiyay" fill="#10b981" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="rounded-2xl bg-card border border-border overflow-hidden">
        <div className="p-5 border-b border-border">
          <h2 className="text-foreground font-semibold">Isticmaalka Macmiil kasta</h2>
          <p className="text-muted-foreground text-xs mt-1">{fullLabel(month)}</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-muted-foreground text-xs uppercase tracking-wider">
                <th className="text-left px-5 py-3 font-medium">Macmiilka</th>
                <th className="text-left px-5 py-3 font-medium hidden sm:table-cell">Mitaarka</th>
                <th className="text-right px-5 py-3 font-medium">kWh</th>
                <th className="text-right px-5 py-3 font-medium">Biil</th>
                <th className="text-right px-5 py-3 font-medium">La Bixiyay</th>
                <th className="text-right px-5 py-3 font-medium">Harsan</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {rows.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-5 py-12 text-center text-muted-foreground">
                    Xog lama helin bishan. Dooro bil kale ama soo saar biilasha.
                  </td>
                </tr>
              ) : (
                rows.map((r) => (
                  <tr key={r.id} className="hover:bg-accent/40 transition-colors">
                    <td className="px-5 py-3 text-foreground font-medium">{r.name}</td>
                    <td className="px-5 py-3 text-muted-foreground hidden sm:table-cell">{r.meter}</td>
                    <td className="px-5 py-3 text-right text-cyan-400">{r.kwh.toFixed(1)}</td>
                    <td className="px-5 py-3 text-right text-foreground">${r.billed.toFixed(2)}</td>
                    <td className="px-5 py-3 text-right text-emerald-400">${r.paid.toFixed(2)}</td>
                    <td className={`px-5 py-3 text-right font-semibold ${r.outstanding > 0 ? "text-red-400" : "text-muted-foreground"}`}>
                      ${r.outstanding.toFixed(2)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function ReportCard({ icon: Icon, label, value, sub, accent }) {
  return (
    <div className="rounded-2xl bg-card border border-border p-5">
      <div className="flex items-center justify-between mb-3">
        <p className="text-muted-foreground text-xs font-medium uppercase tracking-wider">{label}</p>
        <Icon className={`w-4 h-4 ${accent}`} />
      </div>
      <p className={`text-2xl font-bold ${accent}`}>{value}</p>
      {sub && <p className="text-muted-foreground text-xs mt-1">{sub}</p>}
    </div>
  );
}