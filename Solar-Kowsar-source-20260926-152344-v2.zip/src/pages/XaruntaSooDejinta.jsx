import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Users, FileText, Wallet, BarChart3, Package, FileSignature, Fuel, Download, Loader2 } from "lucide-react";
import { exportCsv, exportPdf } from "@/utils/dataExport";

const SEG_LABEL = { residential: "Guri", commercial: "Ganacsi", industrial: "Warshad" };

export default function XaruntaSooDejinta() {
  const { toast } = useToast();
  const [customers, setCustomers] = useState([]);
  const [busy, setBusy] = useState(null);

  useEffect(() => {
    base44.entities.Customer.list("-created_date", 1000).then(setCustomers).catch(() => {});
  }, []);

  const nameOf = (id) => customers.find((c) => c.id === id)?.full_name || "";

  const DATASETS = [
    {
      key: "macaamiisha", label: "Macaamiisha", icon: Users, color: "text-blue-400", bg: "bg-blue-500/15",
      desc: "Dhammaan xogta macaamiisha",
      loader: () => base44.entities.Customer.list("-created_date", 1000),
      columns: ["Magaca", "Telefoon", "Email", "Magaalo", "Qaybta", "Mitaar", "Awood KW", "Qiimaha/Bil", "Xaalada"],
      map: (c) => [c.full_name, c.phone, c.email, c.city, SEG_LABEL[c.customer_type] || "Guri", c.meter_number, c.solar_capacity_kw, c.monthly_rate, c.status],
    },
    {
      key: "biilasha", label: "Biilasha", icon: FileText, color: "text-emerald-400", bg: "bg-emerald-500/15",
      desc: "Biilasha la soo saaray",
      loader: () => base44.entities.Billing.list("-created_date", 1000),
      columns: ["Macmiilka", "Bisha", "KWh", "Qiimaha/kWh", "Wadarta", "Xaalada", "Taariikhda Lacag Bixinta"],
      map: (b) => [nameOf(b.customer), b.billing_month, b.kwh_used, b.rate_per_kwh, b.total_amount, b.status, b.payment_date],
    },
    {
      key: "kharashaadka", label: "Kharashaadka", icon: Wallet, color: "text-orange-400", bg: "bg-orange-500/15",
      desc: "Dhammaan kharashaadka shirkadda",
      loader: () => base44.entities.Expense.list("-created_date", 1000),
      columns: ["Cinwaanka", "Qaybta", "Qadarka", "Taariikhda", "Habka Bixinta", "Shirkadda", "Xaalada"],
      map: (e) => [e.title, e.category, e.amount, e.expense_date, e.payment_method, e.vendor, e.status],
    },
    {
      key: "isticmaalka", label: "Isticmaalka Maalinlaha", icon: BarChart3, color: "text-cyan-400", bg: "bg-cyan-500/15",
      desc: "Diiwaanka isticmaalka kWh",
      loader: () => base44.entities.DailyUsage.list("-usage_date", 1000),
      columns: ["Macmiilka", "Taariikhda", "KWh", "Nooca Qirada", "Qoraalka"],
      map: (u) => [nameOf(u.customer), u.usage_date, u.kwh_used, u.reading_type, u.notes],
    },
    {
      key: "qalabka", label: "Qalabka", icon: Package, color: "text-purple-400", bg: "bg-purple-500/15",
      desc: "Diiwaanka qalabka iyo kaydka",
      loader: () => base44.entities.Equipment.list("-created_date", 1000),
      columns: ["Magaca", "Nooca", "Xaaladda Kaydka", "Goobta", "Siiraadka", "Caafimaadka %", "Battery %"],
      map: (q) => [q.name, q.category, q.asset_state, q.location, q.serial_number, q.health, q.battery_level],
    },
    {
      key: "heshiisyada", label: "Heshiisyada", icon: FileSignature, color: "text-amber-400", bg: "bg-amber-500/15",
      desc: "Heshiisyada iyo SLA-yada",
      loader: () => base44.entities.Contract.list("-created_date", 1000),
      columns: ["Cinwaanka", "Macmiilka", "Nooca", "Bilow", "Dhammaad", "Qiimaha", "SLA (h)", "Xaalada"],
      map: (c) => [c.title, nameOf(c.customer), c.type, c.start_date, c.end_date, c.value, c.sla_response_hours, c.status],
    },
    {
      key: "matoorada", label: "Matoorada Shidaalka", icon: Fuel, color: "text-red-400", bg: "bg-red-500/15",
      desc: "Isticmaalka shidaalka matoorada",
      loader: () => base44.entities.GeneratorLog.list("-log_date", 1000),
      columns: ["Matoora", "Taariikhda", "Saacado", "Shidaal (L)", "La Kudaray (L)", "Qiimaha", "Goobta"],
      map: (g) => [g.generator_name, g.log_date, g.running_hours, g.fuel_consumed_liters, g.fuel_added_liters, g.fuel_cost, g.location],
    },
  ];

  const handleExport = async (ds, format) => {
    setBusy(`${ds.key}-${format}`);
    try {
      const data = await ds.loader();
      const rows = data.map(ds.map);
      if (format === "csv") exportCsv(ds.key, ds.columns, rows);
      else exportPdf(ds.key, ds.label, ds.columns, rows);
      toast({ title: "Waa la soo dejiyay", description: `${rows.length} diiwaan — ${ds.label}` });
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Soo dejintu waa fashilantay" });
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Xarunta Soo-dejinta Xogta</h1>
        <p className="text-zinc-400 text-sm mt-1">Soo deji xogta nidaamka qaab Excel (CSV) ama PDF ah</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {DATASETS.map((ds) => {
          const Icon = ds.icon;
          return (
            <div key={ds.key} className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-5 hover:border-zinc-700 transition-colors">
              <div className="flex items-start gap-3 mb-4">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${ds.bg} ${ds.color}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <h3 className="text-white font-semibold text-sm">{ds.label}</h3>
                  <p className="text-zinc-500 text-xs mt-0.5">{ds.desc}</p>
                </div>
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={() => handleExport(ds, "csv")}
                  disabled={busy === `${ds.key}-csv`}
                  variant="outline"
                  size="sm"
                  className="flex-1 border-zinc-700 text-zinc-200 hover:bg-zinc-800"
                >
                  {busy === `${ds.key}-csv` ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Download className="w-4 h-4 mr-2" />}
                  Excel / CSV
                </Button>
                <Button
                  onClick={() => handleExport(ds, "pdf")}
                  disabled={busy === `${ds.key}-pdf`}
                  size="sm"
                  className="flex-1 bg-amber-500 hover:bg-amber-600 text-black font-semibold"
                >
                  {busy === `${ds.key}-pdf` ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Download className="w-4 h-4 mr-2" />}
                  PDF
                </Button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}