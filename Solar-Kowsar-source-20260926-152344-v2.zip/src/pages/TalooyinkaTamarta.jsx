import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Sparkles, Loader2, BatteryCharging, Zap, AlertTriangle, TrendingUp, Lightbulb, Gauge } from "lucide-react";

const SCHEMA = {
  type: "object",
  properties: {
    efficiency_score: { type: "number" },
    summary: { type: "string" },
    recommendations: {
      type: "array",
      items: {
        type: "object",
        properties: {
          priority: { type: "string" },
          title: { type: "string" },
          detail: { type: "string" },
          category: { type: "string" },
          impact: { type: "string" },
        },
      },
    },
  },
};

const PRIORITY_STYLE = {
  urgent: { label: "Degdeg ah", cls: "bg-red-500/15 text-red-400 border-red-500/25" },
  high: { label: "Sare", cls: "bg-orange-500/15 text-orange-400 border-orange-500/25" },
  medium: { label: "Dhexdhexaad", cls: "bg-amber-500/15 text-amber-400 border-amber-500/25" },
  low: { label: "Hoose", cls: "bg-emerald-500/15 text-emerald-400 border-emerald-500/25" },
};

const avg = (arr, key) => {
  const vals = arr.map((a) => a[key]).filter((v) => typeof v === "number");
  return vals.length ? vals.reduce((s, v) => s + v, 0) / vals.length : 0;
};
const sum = (arr, key) => arr.reduce((s, a) => s + (a[key] || 0), 0);

export default function TalooyinkaTamarta() {
  const { toast } = useToast();
  const [stats, setStats] = useState(null);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(true);
  const [analyzing, setAnalyzing] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const [equipment, solar, locations] = await Promise.all([
          base44.entities.Equipment.list("-created_date", 500),
          base44.entities.SolarData.list("-usage_date", 90),
          base44.entities.Location.list("-created_date", 100),
        ]);
        const batteries = equipment.filter((e) => e.category === "battery");
        setStats({
          equipment,
          solar,
          locations,
          batteryCount: batteries.length,
          avgBatteryLevel: avg(batteries, "battery_level"),
          lowBatteries: batteries.filter((b) => (b.battery_level ?? 100) < 30).length,
          avgBatteryHealth: avg(batteries, "health"),
          avgEfficiency: avg(solar, "efficiency"),
          avgTemp: avg(batteries, "temperature"),
          totalProduction: sum(solar, "production_kwh"),
          totalConsumption: sum(solar, "consumption_kwh"),
          totalCapacityKw: sum(locations, "total_capacity_kw"),
          offlineCount: equipment.filter((e) => e.status !== "online").length,
          warningCount: equipment.filter((e) => e.status === "warning").length,
        });
      } catch {
        toast({ variant: "destructive", title: "Khalad", description: "Xogta lama soo qaadan karin" });
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const analyze = async () => {
    if (!stats) return;
    setAnalyzing(true);
    setResult(null);
    try {
      const prompt = `You are an energy optimization expert advising a solar power company in Somalia.
Here is the current state of their system:

Solar production vs consumption (last ${stats.solar.length} recorded days):
- Total production: ${stats.totalProduction.toFixed(1)} kWh
- Total consumption: ${stats.totalConsumption.toFixed(1)} kWh
- Average system efficiency: ${stats.avgEfficiency.toFixed(1)}%
- Installed capacity across sites: ${stats.totalCapacityKw} kW

Battery fleet:
- Number of batteries: ${stats.batteryCount}
- Average state of charge: ${stats.avgBatteryLevel.toFixed(1)}%
- Average battery health: ${stats.avgBatteryHealth.toFixed(1)}%
- Batteries below 30% charge: ${stats.lowBatteries}
- Average battery temperature: ${stats.avgTemp.toFixed(1)} °C

Equipment fleet:
- Total equipment items: ${stats.equipment.length}
- Items not online: ${stats.offlineCount}
- Items in warning state: ${stats.warningCount}

Give a realistic efficiency score from 0 to 100, a 2-3 sentence summary in Somali of the overall energy situation, and 4 to 6 concrete, actionable optimization recommendations in Somali. Each recommendation must have a priority of "urgent", "high", "medium" or "low", a short title, a detailed explanation of what to do and why, a category (for example Battery, Load Management, Solar Production, Maintenance, Cost), and the expected impact. Base your advice strictly on the numbers above and be specific (for example if battery charge is low, state roughly how many hours of backup remain and tell them to reduce heavy loads).`;

      const res = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: SCHEMA,
      });
      setResult(res);
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Falanqayntu waa fashilantay. Isku day mar kale." });
    } finally {
      setAnalyzing(false);
    }
  };

  if (loading) {
    return (
      <div className="py-24 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-amber-500/30 border-t-amber-500 rounded-full animate-spin" />
      </div>
    );
  }

  const hasData = stats && (stats.solar.length > 0 || stats.equipment.length > 0);
  const score = result?.efficiency_score ?? 0;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Talooyinka Optimization-ka Tamarta</h1>
          <p className="text-zinc-400 text-sm mt-1">Sirdoonka macmalka ah ayaa falanqeeya xogta oo kugula talinaya sida tamarta loo maareeyo</p>
        </div>
        <Button onClick={analyze} disabled={analyzing || !hasData} className="gap-2 bg-amber-500 hover:bg-amber-600 text-black font-semibold">
          {analyzing ? <><Loader2 className="w-4 h-4 animate-spin" /> Falanqaynaya...</> : <><Sparkles className="w-4 h-4" /> Falanqee Tamarta</>}
        </Button>
      </div>

      {!hasData && (
        <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-12 text-center">
          <AlertTriangle className="w-12 h-12 mx-auto mb-3 text-amber-500/40" />
          <p className="text-zinc-400 text-sm">Ma jiro xog ku filan oo la falanqeeyo. Marka hore geli xogta qoraxda iyo qalabka.</p>
        </div>
      )}

      {hasData && (
        <>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <MiniStat label="Battery Celcelis" value={`${stats.avgBatteryLevel.toFixed(0)}%`} icon={BatteryCharging} color="text-emerald-400" />
            <MiniStat label="Taynta Nidaamka" value={`${stats.avgEfficiency.toFixed(0)}%`} icon={Gauge} color="text-amber-400" />
            <MiniStat label="Battery < 30%" value={stats.lowBatteries} icon={AlertTriangle} color={stats.lowBatteries > 0 ? "text-red-400" : "text-zinc-400"} />
            <MiniStat label="Qalab Offline" value={stats.offlineCount} icon={Zap} color={stats.offlineCount > 0 ? "text-orange-400" : "text-zinc-400"} />
          </div>

          {analyzing && (
            <div className="py-16 flex flex-col items-center justify-center text-zinc-400 rounded-2xl bg-zinc-900/40 border border-zinc-800">
              <div className="w-10 h-10 border-4 border-amber-500/30 border-t-amber-500 rounded-full animate-spin mb-4" />
              <p className="text-sm">Xogta waa la falanqaynayaa...</p>
            </div>
          )}

          {!analyzing && !result && (
            <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-12 text-center">
              <Lightbulb className="w-12 h-12 mx-auto mb-3 text-amber-500/40" />
              <p className="text-zinc-400 text-sm">Riix "Falanqee Tamarta" si aad u hesho talooyinka</p>
            </div>
          )}

          {!analyzing && result && (
            <>
              <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-6 flex flex-col sm:flex-row items-center gap-6">
                <ScoreRing score={score} />
                <div className="flex-1 text-center sm:text-left">
                  <p className="text-zinc-400 text-xs font-medium uppercase tracking-wider mb-2">Heerka Waxtarka Nidaamka</p>
                  <p className="text-zinc-300 text-sm leading-relaxed">{result.summary}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {(result.recommendations || []).map((r, i) => {
                  const p = PRIORITY_STYLE[String(r.priority || "").toLowerCase()] || PRIORITY_STYLE.medium;
                  return (
                    <div key={i} className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-5">
                      <div className="flex items-start justify-between gap-3 mb-3">
                        <div className="flex items-start gap-3 min-w-0">
                          <div className="w-9 h-9 rounded-xl bg-amber-500/15 flex items-center justify-center shrink-0">
                            <Lightbulb className="w-4 h-4 text-amber-400" />
                          </div>
                          <h3 className="text-white font-semibold text-sm leading-snug">{r.title}</h3>
                        </div>
                        <span className={`shrink-0 px-2.5 py-1 rounded-full text-[10px] font-semibold uppercase tracking-wide border ${p.cls}`}>
                          {p.label}
                        </span>
                      </div>
                      <p className="text-zinc-400 text-sm leading-relaxed">{r.detail}</p>
                      <div className="flex flex-wrap gap-2 mt-4">
                        {r.category && (
                          <span className="px-2 py-1 rounded-md bg-zinc-800 text-zinc-300 text-[10px] font-medium">{r.category}</span>
                        )}
                        {r.impact && (
                          <span className="px-2 py-1 rounded-md bg-emerald-500/10 text-emerald-400 text-[10px] font-medium flex items-center gap-1">
                            <TrendingUp className="w-3 h-3" /> {r.impact}
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
}

function MiniStat({ label, value, icon: Icon, color }) {
  return (
    <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-4">
      <div className="flex items-center justify-between mb-2">
        <p className="text-zinc-500 text-[11px] font-medium uppercase tracking-wider">{label}</p>
        <Icon className={`w-4 h-4 ${color}`} />
      </div>
      <p className={`text-xl font-bold ${color}`}>{value}</p>
    </div>
  );
}

function ScoreRing({ score }) {
  const pct = Math.max(0, Math.min(100, score));
  const r = 42;
  const c = 2 * Math.PI * r;
  const color = pct >= 75 ? "#10b981" : pct >= 50 ? "#f59e0b" : "#ef4444";
  return (
    <div className="relative w-28 h-28 shrink-0">
      <svg viewBox="0 0 100 100" className="w-28 h-28 -rotate-90">
        <circle cx="50" cy="50" r={r} fill="none" stroke="#27272a" strokeWidth="9" />
        <circle
          cx="50" cy="50" r={r} fill="none" stroke={color} strokeWidth="9" strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={c - (c * pct) / 100}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-2xl font-bold" style={{ color }}>{Math.round(pct)}</span>
        <span className="text-zinc-500 text-[10px]">/ 100</span>
      </div>
    </div>
  );
}