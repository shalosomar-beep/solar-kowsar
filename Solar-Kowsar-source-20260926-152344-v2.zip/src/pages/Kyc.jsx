import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Input } from "@/components/ui/input";
import { Users, Search, ShieldCheck, Clock, AlertTriangle, FileCheck2 } from "lucide-react";
import KycCustomerDialog from "@/components/kyc/KycCustomerDialog";

export default function Kyc() {
  const { toast } = useToast();
  const [customers, setCustomers] = useState([]);
  const [docs, setDocs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(null);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [c, d] = await Promise.all([
        base44.entities.Customer.list("-created_date", 500),
        base44.entities.KycDocument.list("-created_date", 1000),
      ]);
      setCustomers(c);
      setDocs(d);
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Xogta KYC lama keeni karin" });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  const docsFor = (id) => docs.filter((d) => d.customer === id);

  const statusOf = (c) => {
    const list = docsFor(c.id);
    if (list.some((d) => d.status === "verified")) return "verified";
    if (list.some((d) => d.status === "pending")) return "pending";
    if (list.length > 0) return "rejected";
    return "none";
  };

  const STATUS = {
    verified: { label: "La Hubiyay", cls: "bg-emerald-500/15 text-emerald-400 border-emerald-500/25", icon: ShieldCheck },
    pending: { label: "Sugaya", cls: "bg-amber-500/15 text-amber-400 border-amber-500/25", icon: Clock },
    rejected: { label: "La Diiday", cls: "bg-red-500/15 text-red-400 border-red-500/25", icon: AlertTriangle },
    none: { label: "Ma Jiro", cls: "bg-zinc-700/40 text-zinc-400 border-zinc-600/40", icon: AlertTriangle },
  };

  const verifiedCount = customers.filter((c) => statusOf(c) === "verified").length;
  const pendingCount = customers.filter((c) => ["pending", "rejected"].includes(statusOf(c))).length;
  const missingCount = customers.filter((c) => statusOf(c) === "none").length;

  const q = search.trim().toLowerCase();
  const filtered = customers.filter((c) =>
    !q || [c.full_name, c.phone, c.meter_number, c.city].filter(Boolean).join(" ").toLowerCase().includes(q)
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Habka KYC ee Macaamiisha</h1>
        <p className="text-zinc-400 text-sm mt-1">Hubi aqoonsiga macaamiisha ka hor inta aan mitaarka loo xirin</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatBox label="Macaamiisha" value={customers.length} icon={Users} color="text-blue-400" />
        <StatBox label="La Hubiyay" value={verifiedCount} icon={ShieldCheck} color="text-emerald-400" />
        <StatBox label="Sugaya" value={pendingCount} icon={Clock} color="text-amber-400" />
        <StatBox label="Dukumenti Ma Jiro" value={missingCount} icon={AlertTriangle} color={missingCount ? "text-red-400" : "text-zinc-400"} />
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Raadi macmiil, telefoon ama mitaar..."
          className="pl-9 bg-zinc-900/60 border-zinc-800 text-white"
        />
      </div>

      {loading ? (
        <div className="py-20 flex items-center justify-center">
          <div className="w-8 h-8 border-4 border-amber-500/30 border-t-amber-500 rounded-full animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="py-20 text-center text-zinc-500 rounded-2xl bg-zinc-900/60 border border-zinc-800">
          <Users className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p className="text-sm">Macmiil lama helin</p>
        </div>
      ) : (
        <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-zinc-800 text-zinc-400 text-xs uppercase tracking-wider">
                  <th className="text-left px-5 py-3 font-medium">Macmiilka</th>
                  <th className="text-left px-5 py-3 font-medium">Telefoonka</th>
                  <th className="text-left px-5 py-3 font-medium">Mitaarka</th>
                  <th className="text-right px-5 py-3 font-medium">Dukumentiyo</th>
                  <th className="text-left px-5 py-3 font-medium">Xaaladda KYC</th>
                  <th className="text-right px-5 py-3 font-medium">Ficil</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/50">
                {filtered.map((c) => {
                  const s = STATUS[statusOf(c)];
                  const Icon = s.icon;
                  const count = docsFor(c.id).length;
                  return (
                    <tr key={c.id} className="hover:bg-zinc-900/50 transition-colors cursor-pointer" onClick={() => setSelected(c)}>
                      <td className="px-5 py-3 text-white font-medium">{c.full_name}</td>
                      <td className="px-5 py-3 text-zinc-400">{c.phone || "—"}</td>
                      <td className="px-5 py-3 text-zinc-400">{c.meter_number || "—"}</td>
                      <td className="px-5 py-3 text-right text-zinc-300">{count}</td>
                      <td className="px-5 py-3">
                        <span className={`px-2.5 py-1 rounded-full text-[10px] font-semibold border inline-flex items-center gap-1 ${s.cls}`}>
                          <Icon className="w-3 h-3" /> {s.label}
                        </span>
                      </td>
                      <td className="px-5 py-3 text-right">
                        <span className="text-amber-400 text-xs font-medium inline-flex items-center gap-1">
                          <FileCheck2 className="w-3.5 h-3.5" /> Maamul
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <KycCustomerDialog
        open={!!selected}
        onOpenChange={(o) => !o && setSelected(null)}
        customer={selected}
        documents={selected ? docsFor(selected.id) : []}
        onChanged={fetchData}
      />
    </div>
  );
}

function StatBox({ label, value, icon: Icon, color }) {
  return (
    <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-4">
      <div className="flex items-center justify-between mb-2">
        <p className="text-zinc-500 text-[11px] font-medium uppercase tracking-wider">{label}</p>
        <Icon className={`w-4 h-4 ${color}`} />
      </div>
      <p className={`text-xl font-bold ${color}`}>{value}</p>
    </div>
  );
}