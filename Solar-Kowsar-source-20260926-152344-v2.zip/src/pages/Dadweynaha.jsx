import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Home as HomeIcon, Leaf, Sun, Zap, MapPin, RefreshCw, Wifi, ArrowRight } from "lucide-react";

const num = (v) => Number(v || 0).toLocaleString();

export default function Dadweynaha() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const load = async () => {
    try {
      const res = await base44.functions.invoke("getPublicStats", {});
      setStats(res.data);
      setError(false);
    } catch {
      setError(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    const id = setInterval(load, 60000);
    return () => clearInterval(id);
  }, []);

  const co2 = Number(stats?.co2SavedKg) || 0;
  const co2Label = co2 >= 1000 ? `${(co2 / 1000).toFixed(1)} t` : `${Math.round(co2)} kg`;

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b border-border">
        <div className="max-w-6xl mx-auto px-5 py-4 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-400 to-orange-600 flex items-center justify-center">
              <Sun className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="font-bold leading-tight">Solar Kowsar</p>
              <p className="text-muted-foreground text-xs leading-tight">Saamaynta Tamarta Qorraxda</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-xs font-medium">
              <Wifi className="w-3.5 h-3.5" /> Toos
            </span>
            <button
              onClick={load}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-card border border-border text-xs font-medium hover:border-orange-400/50 transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} /> Cusboonaysii
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-5 py-10 space-y-8">
        <div className="text-center max-w-2xl mx-auto">
          <h1 className="text-3xl sm:text-4xl font-bold tracking-tight">
            Korontada Qorraxda ee Magaalada
          </h1>
          <p className="text-muted-foreground mt-3 text-sm sm:text-base">
            Xogta tooska ah ee saamaynta Solar Kowsar ku leedahay bulshada — guryaha aan korontada siino
            iyo CO₂ ee magaalada laga badbaadiyay.
          </p>
        </div>

        {error && (
          <div className="rounded-2xl border border-destructive/30 bg-destructive/5 p-5 text-center text-sm text-destructive">
            Xogta lama soo qaadi karin hadda. Fadlan isku day mar kale.
          </div>
        )}

        <div className="rounded-3xl bg-gradient-to-br from-amber-500 to-orange-600 p-8 sm:p-10 text-white">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
            <div>
              <div className="flex items-center gap-2 opacity-90">
                <HomeIcon className="w-4 h-4" />
                <p className="text-xs uppercase tracking-wider font-medium">Guryaha La Korontaysiiyay</p>
              </div>
              <p className="text-5xl sm:text-6xl font-bold mt-3">
                {loading && !stats ? "—" : num(stats?.homes)}
              </p>
              <p className="text-xs opacity-90 mt-2">
                {num(stats?.customers)} macmiil oo diiwaangashan
              </p>
            </div>
            <div>
              <div className="flex items-center gap-2 opacity-90">
                <Leaf className="w-4 h-4" />
                <p className="text-xs uppercase tracking-wider font-medium">CO₂ La Badbaadiyay</p>
              </div>
              <p className="text-5xl sm:text-6xl font-bold mt-3">{loading && !stats ? "—" : co2Label}</p>
              <p className="text-xs opacity-90 mt-2">
                {num(stats?.co2PerKwh)} kg CO₂ halkii kWh oo qorrax ah
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <Metric icon={Zap} label="Tamarta La Soo Saaray" value={`${num(stats?.kwhGenerated)} kWh`} color="text-amber-600 dark:text-amber-400" />
          <Metric icon={Sun} label="Awoodda La Rakibay" value={`${num(stats?.capacityKw)} kW`} color="text-orange-600 dark:text-orange-400" />
          <Metric icon={MapPin} label="Goobaha" value={num(stats?.locations)} color="text-blue-600 dark:text-blue-400" />
          <Metric icon={Wifi} label="Mitaarada Online" value={num(stats?.metersOnline)} color="text-emerald-600 dark:text-emerald-400" />
        </div>

        <p className="text-center text-muted-foreground text-xs">
          Xogta waxaa si otomaatig ah loo cusboonaysiiyaa halkii daqiiqo.
          {stats?.updatedAt && ` Markii ugu dambaysay: ${new Date(stats.updatedAt).toLocaleString()}`}
        </p>

        <div className="text-center">
          <Link
            to="/login"
            className="inline-flex items-center gap-1.5 text-sm font-medium text-orange-600 dark:text-orange-400 hover:underline"
          >
            Gelitaanka Shaqaalaha <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </main>
    </div>
  );
}

function Metric({ icon: Icon, label, value, color }) {
  return (
    <div className="rounded-2xl bg-card border border-border p-4">
      <div className="flex items-center gap-2">
        <Icon className={`w-4 h-4 ${color}`} />
        <p className="text-muted-foreground text-xs font-medium uppercase tracking-wider">{label}</p>
      </div>
      <p className={`text-2xl font-bold mt-2 ${color}`}>{value}</p>
    </div>
  );
}