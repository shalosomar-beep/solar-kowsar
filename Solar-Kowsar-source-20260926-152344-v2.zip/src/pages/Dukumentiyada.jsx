import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Upload, FileText, Image as ImageIcon, Trash2, Search, ExternalLink, Loader2, File as FileIcon } from "lucide-react";

const CATEGORY_META = {
  installation_photo: { label: "Sawir Rakibaad", cls: "bg-blue-500/15 text-blue-400" },
  signed_form: { label: "Foom Saxiixan", cls: "bg-purple-500/15 text-purple-400" },
  receipt: { label: "Caddayn Lacag", cls: "bg-emerald-500/15 text-emerald-400" },
  contract: { label: "Heshiis", cls: "bg-amber-500/15 text-amber-400" },
  invoice: { label: "Qaansheeg", cls: "bg-cyan-500/15 text-cyan-400" },
  other: { label: "Kale", cls: "bg-zinc-500/15 text-zinc-400" },
};

const emptyForm = { title: "", category: "installation_photo", file_url: "", file_type: "", customer: "", related_location: "", description: "" };

export default function Dukumentiyada() {
  const { toast } = useToast();
  const [items, setItems] = useState([]);
  const [urls, setUrls] = useState({});
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [catFilter, setCatFilter] = useState("all");
  const [modalOpen, setModalOpen] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [form, setForm] = useState(emptyForm);

  const load = async () => {
    try {
      setLoading(true);
      const [docs, custs] = await Promise.all([
        base44.entities.Document.list("-created_date", 40),
        base44.entities.Customer.list("-created_date", 300),
      ]);
      setItems(docs);
      setCustomers(custs);

      const map = {};
      await Promise.all(
        docs.map(async (d) => {
          if (!d.file_url) return;
          try {
            const { signed_url } = await base44.integrations.Core.CreateFileSignedUrl({ file_uri: d.file_url, expires_in: 3600 });
            map[d.id] = signed_url;
          } catch {
            /* skip */
          }
        })
      );
      setUrls(map);
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Dukumentiyada lama keeni karo" });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const custName = (id) => customers.find((c) => c.id === id)?.full_name || "";

  const handleFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_uri } = await base44.integrations.Core.UploadPrivateFile({ file });
      setForm((p) => ({ ...p, file_url: file_uri, file_type: file.type || "", title: p.title || file.name }));
      toast({ title: "Faylka waa la soo geliyay" });
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Faylka lama soo gelin karin" });
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.file_url) {
      toast({ variant: "destructive", title: "Khalad", description: "Marka hore soo geli fayl" });
      return;
    }
    try {
      let me = null;
      try { me = await base44.auth.me(); } catch { me = null; }
      await base44.entities.Document.create({
        ...form,
        customer: form.customer || null,
        uploaded_by: me?.full_name || me?.email || "",
      });
      toast({ title: "Dukumentiga waa la keydiyay" });
      setModalOpen(false);
      setForm(emptyForm);
      load();
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Dukumentiga lama keydin karin" });
    }
  };

  const handleDelete = async (item) => {
    if (!confirm("Ma hubtaa inaad tirtirto dukumentigan?")) return;
    try {
      await base44.entities.Document.delete(item.id);
      toast({ title: "Waa la tirtiray" });
      load();
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Lama tirtiri karo" });
    }
  };

  const filtered = items.filter((d) => {
    const q = search.toLowerCase();
    const matchQ =
      !q ||
      d.title?.toLowerCase().includes(q) ||
      custName(d.customer).toLowerCase().includes(q) ||
      d.related_location?.toLowerCase().includes(q);
    const matchCat = catFilter === "all" || d.category === catFilter;
    return matchQ && matchCat;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Kaydka Dukumentiyada</h1>
          <p className="text-zinc-400 text-sm mt-1">Sawirrada goobta, foomamka saxiixan iyo caddaymaha lacag bixinta</p>
        </div>
        <Button onClick={() => { setForm(emptyForm); setModalOpen(true); }} className="gap-2 bg-amber-500 hover:bg-amber-600 text-black font-semibold">
          <Upload className="w-4 h-4" /> Soo Geli Dukumenti
        </Button>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
          <Input
            placeholder="Raadi dukumenti, macmiil ama goob..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 bg-zinc-900 border-zinc-800 text-white placeholder:text-zinc-600"
          />
        </div>
        <Select value={catFilter} onValueChange={setCatFilter}>
          <SelectTrigger className="w-52 bg-zinc-900 border-zinc-800 text-white"><SelectValue /></SelectTrigger>
          <SelectContent className="bg-zinc-900 border-zinc-800">
            <SelectItem value="all">Dhammaan qaybaha</SelectItem>
            {Object.entries(CATEGORY_META).map(([v, m]) => (
              <SelectItem key={v} value={v}>{m.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="py-20 flex items-center justify-center">
          <div className="w-8 h-8 border-4 border-amber-500/30 border-t-amber-500 rounded-full animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="py-20 text-center text-zinc-500">
          <FileText className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p className="text-sm">Dukumenti lama helin</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filtered.map((d) => {
            const cat = CATEGORY_META[d.category] || CATEGORY_META.other;
            const isImage = (d.file_type || "").startsWith("image/");
            const url = urls[d.id];
            return (
              <div key={d.id} className="rounded-2xl bg-zinc-900/60 border border-zinc-800 overflow-hidden hover:border-zinc-700 transition-colors flex flex-col">
                <div className="h-40 bg-zinc-800/50 flex items-center justify-center overflow-hidden">
                  {isImage && url ? (
                    <img src={url} alt={d.title} className="w-full h-full object-cover" />
                  ) : isImage ? (
                    <ImageIcon className="w-10 h-10 text-zinc-600" />
                  ) : (
                    <FileIcon className="w-10 h-10 text-zinc-600" />
                  )}
                </div>
                <div className="p-4 flex-1 flex flex-col">
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="text-white text-sm font-semibold truncate">{d.title}</h3>
                  </div>
                  <span className={`inline-flex self-start mt-2 px-2 py-0.5 rounded-full text-xs font-medium ${cat.cls}`}>{cat.label}</span>
                  {custName(d.customer) && <p className="text-zinc-400 text-xs mt-2">{custName(d.customer)}</p>}
                  {d.related_location && <p className="text-zinc-500 text-xs">{d.related_location}</p>}
                  <div className="flex items-center gap-1 mt-3 pt-3 border-t border-zinc-800/50">
                    <Button
                      variant="ghost"
                      size="sm"
                      disabled={!url}
                      onClick={() => url && window.open(url, "_blank", "noopener")}
                      className="text-zinc-300 hover:text-amber-400 h-8"
                    >
                      <ExternalLink className="w-4 h-4 mr-1.5" /> Fur
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => handleDelete(d)} className="h-8 w-8 ml-auto text-zinc-400 hover:text-red-400">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="max-w-lg bg-zinc-900 border-zinc-800 text-white">
          <DialogHeader>
            <DialogTitle>Soo Geli Dukumenti</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label>Faylka *</Label>
              <label className="flex items-center justify-center gap-2 h-24 rounded-xl border border-dashed border-zinc-700 bg-zinc-800/40 cursor-pointer hover:border-amber-500/50 transition-colors">
                <input type="file" className="hidden" onChange={handleFile} accept="image/*,.pdf,.doc,.docx,.xls,.xlsx" />
                {uploading ? (
                  <span className="flex items-center gap-2 text-zinc-300 text-sm"><Loader2 className="w-4 h-4 animate-spin" /> Soo gelinaya...</span>
                ) : form.file_url ? (
                  <span className="flex items-center gap-2 text-emerald-400 text-sm"><FileText className="w-4 h-4" /> Faylka waa la soo geliyay — beddel</span>
                ) : (
                  <span className="flex items-center gap-2 text-zinc-400 text-sm"><Upload className="w-4 h-4" /> Riix si aad fayl u dooratid</span>
                )}
              </label>
            </div>
            <div className="space-y-2">
              <Label>Magaca Dukumentiga *</Label>
              <Input required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" placeholder="T.c. Sawir rakibaad — Hodan" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Qaybta</Label>
                <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
                  <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-zinc-900 border-zinc-800">
                    {Object.entries(CATEGORY_META).map(([v, m]) => <SelectItem key={v} value={v}>{m.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Macmiilka</Label>
                <Select value={form.customer} onValueChange={(v) => setForm({ ...form, customer: v })}>
                  <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white"><SelectValue placeholder="Dooro" /></SelectTrigger>
                  <SelectContent className="bg-zinc-900 border-zinc-800">
                    {customers.map((c) => <SelectItem key={c.id} value={c.id}>{c.full_name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Goobta</Label>
              <Input value={form.related_location} onChange={(e) => setForm({ ...form, related_location: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" />
            </div>
            <div className="space-y-2">
              <Label>Faahfaahinta</Label>
              <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" rows={2} />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setModalOpen(false)} className="border-zinc-700 text-zinc-300 hover:bg-zinc-800">Jooji</Button>
              <Button type="submit" disabled={uploading} className="bg-amber-500 hover:bg-amber-600 text-black font-semibold">Keydi</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}