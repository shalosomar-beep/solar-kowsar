import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, CalendarDays, User, MapPin } from "lucide-react";

const WEEKDAYS = ["Isn", "Tal", "Arb", "Kha", "Jim", "Sab", "Axd"];
const MONTHS = [
  "Jannaayo", "Febraayo", "Maarso", "Abriil", "Maayo", "Juun",
  "Luulyo", "Agoosto", "Sebtembar", "Oktoobar", "Nofembar", "Diseembar",
];

const PRIORITY_META = {
  low: { label: "Hoose", chip: "bg-zinc-500/20 text-zinc-300 border-zinc-500/30" },
  medium: { label: "Dhexdhexaad", chip: "bg-blue-500/20 text-blue-300 border-blue-500/30" },
  high: { label: "Sare", chip: "bg-amber-500/20 text-amber-300 border-amber-500/30" },
  urgent: { label: "Degdeg", chip: "bg-red-500/20 text-red-300 border-red-500/30" },
};

const STATUS_LABELS = {
  open: "Furan",
  assigned: "La Xilsaaray",
  in_progress: "Socda",
  completed: "Dhammaaday",
};

const toKey = (d) => d.toISOString().slice(0, 10);

export default function Jadwalka() {
  const [tasks, setTasks] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [staff, setStaff] = useState([]);
  const [loading, setLoading] = useState(true);
  const [cursor, setCursor] = useState(new Date());
  const [selectedDay, setSelectedDay] = useState(null);

  useEffect(() => {
    Promise.all([
      base44.entities.Task.list("-created_date", 300),
      base44.entities.Customer.list("-created_date", 300),
      base44.entities.Staff.list("-created_date", 200),
    ])
      .then(([t, c, s]) => {
        setTasks(t);
        setCustomers(c);
        setStaff(s);
      })
      .finally(() => setLoading(false));
  }, []);

  const custName = (id) => customers.find((c) => c.id === id)?.full_name || "";
  const techName = (id) => staff.find((s) => s.id === id)?.full_name || "Lama xilsaarin";

  const byDate = {};
  tasks.forEach((t) => {
    if (!t.due_date) return;
    const key = t.due_date.slice(0, 10);
    if (!byDate[key]) byDate[key] = [];
    byDate[key].push(t);
  });

  const year = cursor.getFullYear();
  const monthIdx = cursor.getMonth();
  const startWeekday = (new Date(year, monthIdx, 1).getDay() + 6) % 7;
  const daysInMonth = new Date(year, monthIdx + 1, 0).getDate();
  const todayKey = toKey(new Date());

  const cells = [];
  for (let i = 0; i < startWeekday; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(new Date(year, monthIdx, d));

  const shiftMonth = (delta) => setCursor(new Date(year, monthIdx + delta, 1));

  const monthTasks = tasks.filter((t) => t.due_date?.startsWith(`${year}-${String(monthIdx + 1).padStart(2, "0")}`));
  const openTasks = monthTasks.filter((t) => t.status !== "completed").length;
  const urgentTasks = monthTasks.filter((t) => t.priority === "urgent" || t.priority === "high").length;
  const techCount = new Set(monthTasks.map((t) => t.technician).filter(Boolean)).size;

  const selectedTasks = selectedDay ? byDate[selectedDay] || [] : [];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Jadwalka &amp; Qoondeynta</h1>
        <p className="text-zinc-400 text-sm mt-1">Ballamaha rakibidda iyo booqashada dayactirka ee farsamoyaqaannada</p>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <StatBox label="Hawlaha Bishan" value={monthTasks.length} color="text-blue-400" bg="from-blue-500/10 to-blue-600/5 border-blue-500/15" />
        <StatBox label="Furan" value={openTasks} color="text-amber-400" bg="from-amber-500/10 to-amber-600/5 border-amber-500/15" />
        <StatBox label="Farsamoyaqaanno" value={techCount} color="text-emerald-400" bg="from-emerald-500/10 to-emerald-600/5 border-emerald-500/15" />
      </div>

      {urgentTasks > 0 && (
        <div className="rounded-xl bg-red-500/10 border border-red-500/20 px-4 py-3 text-red-300 text-sm">
          {urgentTasks} hawl oo muhiimad sare ama degdeg ah ayaa bishan jadwalka ku jira.
        </div>
      )}

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-2 rounded-2xl bg-zinc-900/60 border border-zinc-800 p-4 sm:p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-white font-semibold flex items-center gap-2">
              <CalendarDays className="w-4 h-4 text-amber-400" />
              {MONTHS[monthIdx]} {year}
            </h2>
            <div className="flex items-center gap-1">
              <Button variant="ghost" size="icon" onClick={() => shiftMonth(-1)} className="h-8 w-8 text-zinc-400 hover:text-white">
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="sm" onClick={() => { setCursor(new Date()); setSelectedDay(todayKey); }} className="text-zinc-400 hover:text-white h-8">
                Maanta
              </Button>
              <Button variant="ghost" size="icon" onClick={() => shiftMonth(1)} className="h-8 w-8 text-zinc-400 hover:text-white">
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-7 gap-1 mb-2">
            {WEEKDAYS.map((w) => (
              <div key={w} className="text-center text-zinc-500 text-xs font-medium py-1">{w}</div>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-1">
            {cells.map((day, i) => {
              if (!day) return <div key={`e-${i}`} className="min-h-[86px] rounded-lg" />;
              const key = toKey(day);
              const dayTasks = byDate[key] || [];
              const isToday = key === todayKey;
              const isSelected = key === selectedDay;
              return (
                <button
                  key={key}
                  onClick={() => setSelectedDay(key)}
                  className={`min-h-[86px] rounded-lg border p-1.5 text-left transition-colors ${
                    isSelected ? "border-amber-500/60 bg-amber-500/10" : "border-zinc-800 bg-zinc-900/40 hover:border-zinc-700"
                  }`}
                >
                  <span className={`text-xs font-semibold ${isToday ? "text-amber-400" : "text-zinc-400"}`}>{day.getDate()}</span>
                  <div className="mt-1 space-y-0.5">
                    {dayTasks.slice(0, 2).map((t) => {
                      const p = PRIORITY_META[t.priority] || PRIORITY_META.medium;
                      return (
                        <div key={t.id} className={`truncate rounded border px-1 py-0.5 text-[10px] leading-tight ${p.chip}`}>
                          {t.title}
                        </div>
                      );
                    })}
                    {dayTasks.length > 2 && (
                      <div className="text-[10px] text-zinc-500 px-1">+{dayTasks.length - 2} kale</div>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-5">
          <h2 className="text-white font-semibold mb-1">
            {selectedDay ? new Date(selectedDay).toLocaleDateString("so-SO", { weekday: "long", day: "numeric", month: "long" }) : "Dooro Maalin"}
          </h2>
          <p className="text-zinc-500 text-xs mb-4">
            {selectedDay ? `${selectedTasks.length} hawl oo la qoondeeyay` : "Riix maalin jadwalka si aad u aragto ballamaha"}
          </p>

          {loading ? (
            <div className="py-10 flex justify-center">
              <div className="w-6 h-6 border-4 border-amber-500/30 border-t-amber-500 rounded-full animate-spin" />
            </div>
          ) : !selectedDay ? (
            <div className="py-10 text-center text-zinc-600 text-sm">
              <CalendarDays className="w-10 h-10 mx-auto mb-2 opacity-30" />
              Maalin lama dooran
            </div>
          ) : selectedTasks.length === 0 ? (
            <div className="py-10 text-center text-zinc-600 text-sm">Maalintan hawl lama qoondeyn</div>
          ) : (
            <div className="space-y-3">
              {selectedTasks.map((t) => {
                const p = PRIORITY_META[t.priority] || PRIORITY_META.medium;
                return (
                  <div key={t.id} className="rounded-xl bg-zinc-800/50 border border-zinc-700/50 p-3">
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="text-white text-sm font-medium">{t.title}</h3>
                      <span className={`inline-flex px-2 py-0.5 rounded-full text-[10px] font-medium border shrink-0 ${p.chip}`}>{p.label}</span>
                    </div>
                    <div className="mt-2 space-y-1 text-xs text-zinc-400">
                      <p className="flex items-center gap-1.5"><User className="w-3 h-3" /> {techName(t.technician)}</p>
                      {custName(t.customer) && <p className="flex items-center gap-1.5"><User className="w-3 h-3" /> {custName(t.customer)}</p>}
                      {t.location && <p className="flex items-center gap-1.5"><MapPin className="w-3 h-3" /> {t.location}</p>}
                      <p className="text-zinc-500">{STATUS_LABELS[t.status] || t.status}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function StatBox({ label, value, color, bg }) {
  return (
    <div className={`rounded-2xl bg-gradient-to-br border p-5 ${bg}`}>
      <p className="text-zinc-400 text-xs font-medium uppercase tracking-wider">{label}</p>
      <p className={`text-2xl font-bold mt-2 ${color}`}>{value}</p>
    </div>
  );
}