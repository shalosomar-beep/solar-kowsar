import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CloudSun, Sun, CloudRain, Cloud, Loader2, Zap, TrendingUp, RefreshCw, Sparkles } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import CurrentWeatherCard from "@/components/weather/CurrentWeatherCard";
import HourlyForecastStrip from "@/components/weather/HourlyForecastStrip";

const SCHEMA = {
  type: "object",
  properties: {
    location: { type: "string" },
    summary: { type: "string" },
    current: {
      type: "object",
      properties: {
        condition: { type: "string" },
        temp_c: { type: "number" },
        feels_like_c: { type: "number" },
        humidity: { type: "number" },
        wind_speed_kmh: { type: "number" },
        wind_direction: { type: "string" },
        uv_index: { type: "number" },
        cloud_cover: { type: "number" },
        irradiance_wm2: { type: "number" },
      },
    },
    hourly: {
      type: "array",
      items: {
        type: "object",
        properties: {
          time: { type: "string" },
          condition: { type: "string" },
          cloud_cover: { type: "number" },
          temp_c: { type: "number" },
          rain_chance: { type: "number" },
        },
      },
    },
    days: {
      type: "array",
      items: {
        type: "object",
        properties: {
          date: { type: "string" },
          condition: { type: "string" },
          cloud_cover: { type: "number" },
          sun_hours: { type: "number" },
          temp_max: { type: "number" },
          yield_kwh: { type: "number" },
        },
      },
    },
  },
};

function DayIcon({ cloud }) {
  if (cloud >= 70) return <CloudRain className="w-6 h-6 text-blue-400" />;
  if (cloud >= 40) return <Cloud className="w-6 h-6 text-zinc-300" />;
  return <Sun className="w-6 h-6 text-amber-400" />;
}

function yieldColor(v, max) {
  if (!max) return "#f59e0b";
  const r = v / max;
  if (r >= 0.75) return "#10b981";
  if (r >= 0.45) return "#f59e0b";
  return "#ef4444";
}

export default function SaadaashaCimilada() {
  const { toast } = useToast();
  const [locations, setLocations] = useState([]);
  const [city, setCity] = useState("");
  const [capacity, setCapacity] = useState("");
  const [forecast, setForecast] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    base44.entities.Location.list("-created_date", 100)
      .then((locs) => {
        setLocations(locs);
        if (locs[0]) {
          setCity(locs[0].city || locs[0].name || "");
          setCapacity(locs[0].total_capacity_kw ?? "");
        }
      })
      .catch(() => {});
  }, []);

  const pickLocation = (name) => {
    const loc = locations.find((l) => l.name === name);
    if (loc) {
      setCity(loc.city || loc.name);
      setCapacity(loc.total_capacity_kw ?? "");
    }
  };

  const run = async () => {
    if (!city) {
      toast({ variant: "destructive", title: "Khalad", description: "Dooro ama qor magaca magaalada" });
      return;
    }
    setLoading(true);
    setForecast(null);
    try {
      const cap = Number(capacity) || 0;
      const prompt = `You are a solar energy analyst for a solar power company in Somalia.
Location: ${city}, Somalia.
Installed solar capacity: ${cap} kW.

Using the current and forecast weather information available online for this exact location, return the conditions right now, an hourly outlook for the next 6 hours, and a 7-day solar outlook starting today.

For the current conditions return: a short condition in Somali, the current temperature in Celsius, the feels-like temperature in Celsius, the relative humidity percentage (0-100), the wind speed in km/h, the wind direction as a compass point together with its Somali name (e.g. "NE — Waqooyi-Bari"), the current UV index (0-11+), the current cloud cover percentage (0-100), and the current solar irradiance in W/m².

For the hourly outlook return 6 entries starting from the next full hour: the local time in HH:00 format, a short condition in Somali, the cloud cover percentage, the temperature in Celsius, and the chance of rain as a percentage.

For each of the next 7 days return: the date in YYYY-MM-DD format, a short weather condition in Somali (e.g. "Qorrax badan", "Daruuro", "Roob"), the average cloud cover percentage (0-100), the expected peak sun hours for that day, the maximum temperature in Celsius, and the expected solar energy yield in kWh (realistic estimate for a ${cap} kW plant given the expected sun hours and cloud cover).
Also return a 2-sentence summary in Somali advising the operations team which days are best and worst for solar production.
Return only the structured data.`;

      const res = await base44.integrations.Core.InvokeLLM({
        prompt,
        add_context_from_internet: true,
        model: "gemini_3_flash",
        response_json_schema: SCHEMA,
      });
      setForecast(res);
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Saadaasha lama heli karin. Isku day mar kale." });
    } finally {
      setLoading(false);
    }
  };

  const days = forecast?.days || [];
  const hours = forecast?.hourly || [];
  const maxYield = days.length ? Math.max(...days.map((d) => d.yield_kwh || 0)) : 0;
  const totalYield = days.reduce((s, d) => s + (d.yield_kwh || 0), 0);
  const avgCloud = days.length ? days.reduce((s, d) => s + (d.cloud_cover || 0), 0) / days.length : 0;
  const chartData = days.map((d) => ({
    date: d.date?.slice(5),
    yield_kwh: d.yield_kwh || 0,
    color: yieldColor(d.yield_kwh || 0, maxYield),
  }));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Saadaasha Cimilada &amp; Tamarta</h1>
        <p className="text-zinc-400 text-sm mt-1">Saadaasha cimilada 7 maalmood iyo tamarta la filan karo inay soo baxdo</p>
      </div>

      <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
          <div className="space-y-2">
            <Label className="text-zinc-400 text-xs">Goobta</Label>
            <Select value={city} onValueChange={pickLocation}>
              <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white"><SelectValue placeholder="Dooro goob" /></SelectTrigger>
              <SelectContent className="bg-zinc-900 border-zinc-800">
                {locations.map((l) => <SelectItem key={l.id} value={l.name}>{l.name} — {l.city}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label className="text-zinc-400 text-xs">Magaalada</Label>
            <Input value={city} onChange={(e) => setCity(e.target.value)} className="bg-zinc-800 border-zinc-700 text-white" placeholder="T.c. Hargeysa" />
          </div>
          <div className="space-y-2">
            <Label className="text-zinc-400 text-xs">Awoodda (kW)</Label>
            <Input type="number" value={capacity} onChange={(e) => setCapacity(e.target.value)} className="bg-zinc-800 border-zinc-700 text-white" placeholder="50" />
          </div>
          <Button onClick={run} disabled={loading} className="bg-amber-500 hover:bg-amber-600 text-black font-semibold h-9">
            {loading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Saadaalinaya...</> : <><Sparkles className="w-4 h-4 mr-2" /> Soo Saar Saadaasha</>}
          </Button>
        </div>
        <p className="text-zinc-500 text-xs mt-3">
          Saadaashu waxay isticmaashaa xog cimilo oo internetka laga soo qaato — waxay qaadan kartaa dhowr ilbiriqsi.
        </p>
      </div>

      {loading && (
        <div className="py-20 flex flex-col items-center justify-center text-zinc-400">
          <div className="w-10 h-10 border-4 border-amber-500/30 border-t-amber-500 rounded-full animate-spin mb-4" />
          <p className="text-sm">Xogta cimilada ayaa la soo qaadanayaa...</p>
        </div>
      )}

      {!loading && !forecast && (
        <div className="py-20 text-center text-zinc-500">
          <CloudSun className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p className="text-sm">Dooro goob oo riix "Soo Saar Saadaasha"</p>
        </div>
      )}

      {!loading && forecast && (
        <>
          {forecast.summary && (
            <div className="rounded-2xl bg-gradient-to-br from-amber-500/10 to-amber-600/5 border border-amber-500/20 p-5 flex items-start gap-3">
              <Sparkles className="w-5 h-5 text-amber-400 mt-0.5 shrink-0" />
              <div>
                <p className="text-amber-300 text-sm font-medium">Talooyin Hawlgal</p>
                <p className="text-zinc-300 text-sm mt-1">{forecast.summary}</p>
              </div>
            </div>
          )}

          {forecast.current && <CurrentWeatherCard current={forecast.current} />}

          {hours.length > 0 && <HourlyForecastStrip hours={hours} />}

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <StatBox label="Tamarta La Filan (7 maalmood)" value={`${totalYield.toFixed(0)} kWh`} icon={Zap} color="text-amber-400" bg="from-amber-500/10 to-amber-600/5 border-amber-500/15" />
            <StatBox label="Celceliska Daruurta" value={`${avgCloud.toFixed(0)}%`} icon={Cloud} color="text-blue-400" bg="from-blue-500/10 to-blue-600/5 border-blue-500/15" />
            <StatBox label="Maalmaha La Saadaaliyay" value={days.length} icon={TrendingUp} color="text-emerald-400" bg="from-emerald-500/10 to-emerald-600/5 border-emerald-500/15" />
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-3">
            {days.map((d) => (
              <div key={d.date} className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-4 text-center">
                <p className="text-zinc-500 text-xs">{d.date?.slice(5)}</p>
                <div className="flex justify-center my-2"><DayIcon cloud={d.cloud_cover || 0} /></div>
                <p className="text-white text-xs font-medium truncate">{d.condition}</p>
                <p className="text-amber-400 text-lg font-bold mt-2">{(d.yield_kwh || 0).toFixed(0)}</p>
                <p className="text-zinc-500 text-[10px]">kWh</p>
                <div className="mt-2 pt-2 border-t border-zinc-800 text-[10px] text-zinc-500 space-y-0.5">
                  <p>☁ {d.cloud_cover ?? "—"}%</p>
                  <p>☀ {d.sun_hours ?? "—"} h</p>
                  <p>🌡 {d.temp_max ?? "—"}°C</p>
                </div>
              </div>
            ))}
          </div>

          <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-5">
            <h2 className="text-white font-semibold mb-1">Tamarta La Filan Maalin kasta</h2>
            <p className="text-zinc-500 text-xs mb-4">kWh la filan karo inay soo baxdo</p>
            <div style={{ width: "100%", height: 260 }}>
              <ResponsiveContainer>
                <BarChart data={chartData} margin={{ top: 4, right: 8, left: -18, bottom: 4 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                  <XAxis dataKey="date" tick={{ fill: "#a1a1aa", fontSize: 11 }} axisLine={{ stroke: "#3f3f46" }} tickLine={false} />
                  <YAxis tick={{ fill: "#a1a1aa", fontSize: 11 }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ background: "#18181b", border: "1px solid #3f3f46", borderRadius: 12, color: "#fff" }} formatter={(v) => [`${v} kWh`, "Tamarta"]} />
                  <Bar dataKey="yield_kwh" radius={[6, 6, 0, 0]}>
                    {chartData.map((d, i) => <Cell key={i} fill={d.color} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="flex justify-end">
            <Button variant="outline" onClick={run} className="border-zinc-700 text-zinc-300 hover:bg-zinc-800">
              <RefreshCw className="w-4 h-4 mr-2" /> Cusboonaysii Saadaasha
            </Button>
          </div>
        </>
      )}
    </div>
  );
}

function StatBox({ label, value, icon: Icon, color, bg }) {
  return (
    <div className={`rounded-2xl bg-gradient-to-br border p-5 ${bg}`}>
      <div className="flex items-center justify-between mb-3">
        <p className="text-zinc-400 text-xs font-medium uppercase tracking-wider">{label}</p>
        <Icon className={`w-4 h-4 ${color}`} />
      </div>
      <p className={`text-2xl font-bold ${color}`}>{value}</p>
    </div>
  );
}