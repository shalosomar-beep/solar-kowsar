import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { useT } from "@/lib/i18n";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Flame, Search } from "lucide-react";
import HeatRequestTable from "@/components/maintenance/HeatRequestTable";

// Requests the system creates on its own when a unit overheats are titled
// "Dayactir heerkul: <equipment> — <temp>°C" (see src/lib/alertNotifications.js).
const AUTO_TITLE_PREFIX = "Dayactir heerkul:";
const PRIORITY_ORDER = { critical: 0, high: 1, medium: 2, low: 3 };

const parseAutoTitle = (title = "") => {
  const rest = title.slice(AUTO_TITLE_PREFIX.length).trim();
  const [rawName, rawTemp] = rest.split("—").map((s) => s.trim());
  const temp = rawTemp ? Number(rawTemp.replace(/[^\d.-]/g, "")) : null;
  return { name: rawName || title, temp: Number.isFinite(temp) ? temp : null };
};

export default function HawlahaDayactirka() {
  const { t } = useT();
  const { toast } = useToast();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("all");
  const [priority, setPriority] = useState("all");

  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true);
        const data = await base44.entities.MaintenanceRequest.list("-created_date", 200);
        const heatRequests = (data || [])
          .filter((r) => (r.title || "").startsWith(AUTO_TITLE_PREFIX))
          .map((r) => ({ ...r, ...parseAutoTitle(r.title) }))
          .sort((a, b) => (PRIORITY_ORDER[a.priority] ?? 9) - (PRIORITY_ORDER[b.priority] ?? 9));
        setItems(heatRequests);
      } catch {
        toast({ variant: "destructive", title: t("common.error"), description: t("heatreq.error") });
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const query = search.trim().toLowerCase();
  const visible = items.filter(
    (i) =>
      (status === "all" || i.status === status) &&
      (priority === "all" || i.priority === priority) &&
      (!query ||
        (i.name || "").toLowerCase().includes(query) ||
        (i.customer_name || "").toLowerCase().includes(query))
  );

  const counts = {
    total: items.length,
    critical: items.filter((i) => i.priority === "critical").length,
    open: items.filter((i) => i.status === "open").length,
    resolved: items.filter((i) => i.status === "resolved").length,
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-lg bg-orange-500/10 flex items-center justify-center">
          <Flame className="w-5 h-5 text-orange-500" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white">{t("heatreq.title")}</h1>
          <p className="text-zinc-400 text-sm">{t("heatreq.subtitle")}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label={t("heatreq.stat.total")} sub={t("heatreq.stat.totalSub")} value={counts.total} bg="bg-zinc-800/60" text="text-white" />
        <StatCard label={t("heatreq.stat.critical")} sub={t("heatreq.stat.criticalSub")} value={counts.critical} bg="bg-red-500/10" text="text-red-400" />
        <StatCard label={t("heatreq.stat.open")} sub={t("heatreq.stat.openSub")} value={counts.open} bg="bg-amber-500/10" text="text-amber-400" />
        <StatCard label={t("heatreq.stat.resolved")} sub={t("heatreq.stat.resolvedSub")} value={counts.resolved} bg="bg-emerald-500/10" text="text-emerald-400" />
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t("heatreq.search")}
            className="ps-10 bg-zinc-900 border-zinc-800 text-white placeholder:text-zinc-600"
          />
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Select value={priority} onValueChange={setPriority}>
            <SelectTrigger className="w-44 bg-zinc-900 border-zinc-800 text-white"><SelectValue /></SelectTrigger>
            <SelectContent className="bg-zinc-900 border-zinc-800">
              <SelectItem value="all">{t("heatreq.filter.allPriorities")}</SelectItem>
              <SelectItem value="critical">{t("heatreq.priority.critical")}</SelectItem>
              <SelectItem value="high">{t("heatreq.priority.high")}</SelectItem>
              <SelectItem value="medium">{t("heatreq.priority.medium")}</SelectItem>
              <SelectItem value="low">{t("heatreq.priority.low")}</SelectItem>
            </SelectContent>
          </Select>
          <Select value={status} onValueChange={setStatus}>
            <SelectTrigger className="w-44 bg-zinc-900 border-zinc-800 text-white"><SelectValue /></SelectTrigger>
            <SelectContent className="bg-zinc-900 border-zinc-800">
              <SelectItem value="all">{t("heatreq.filter.allStatuses")}</SelectItem>
              <SelectItem value="open">{t("heatreq.status.open")}</SelectItem>
              <SelectItem value="in_progress">{t("heatreq.status.in_progress")}</SelectItem>
              <SelectItem value="resolved">{t("heatreq.status.resolved")}</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <HeatRequestTable items={visible} total={items.length} loading={loading} />
    </div>
  );
}

function StatCard({ label, sub, value, bg, text }) {
  return (
    <div className={`rounded-2xl border border-zinc-800 p-5 ${bg}`}>
      <p className="text-zinc-400 text-xs font-medium uppercase tracking-wider">{label}</p>
      <p className={`text-3xl font-bold mt-2 ${text}`}>{value}</p>
      <p className="text-zinc-500 text-xs mt-1">{sub}</p>
    </div>
  );
}