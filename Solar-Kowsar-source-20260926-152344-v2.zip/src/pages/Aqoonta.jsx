import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { BookOpen, Plus, Search, Upload, Loader2, Paperclip, ExternalLink, Pencil, Trash2 } from "lucide-react";

const CATEGORIES = {
  manual: { label: "Buugga Hagaha", cls: "bg-blue-500/15 text-blue-400 border-blue-500/25" },
  installation: { label: "Habka Dhisidda", cls: "bg-emerald-500/15 text-emerald-400 border-emerald-500/25" },
  troubleshooting: { label: "Cilad-baaris", cls: "bg-amber-500/15 text-amber-400 border-amber-500/25" },
  safety: { label: "Badbaado", cls: "bg-red-500/15 text-red-400 border-red-500/25" },
  faq: { label: "Su'aalo", cls: "bg-purple-500/15 text-purple-400 border-purple-500/25" },
  other: { label: "Kale", cls: "bg-zinc-700/40 text-zinc-300 border-zinc-600/40" },
};

const EQUIPMENT = {
  general: "Guud",
  battery: "Battery",
  inverter: "Inverter",
  solar_panel: "Solar Panel",
  generator: "Generator",
  smart_meter: "Mitaar Casri ah",
};

const emptyForm = {
  title: "", category: "manual", equipment_category: "general", summary: "",
  content: "", file_url: "", file_name: "", video_url: "", tags: "", author: "",
};

export default function Aqoonta() {
  const { toast } = useToast();
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [catFilter, setCatFilter] = useState("all");
  const [selected, setSelected] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [uploading, setUploading] = useState(false);

  const fetchData = async () => {
    try {
      setLoading(true);
      const data = await base44.entities.KnowledgeArticle.list("-created_date", 300);
      setArticles(data);
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Dukumentiyada lama keeni karin" });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  const openCreate = () => { setEditing(null); setForm(emptyForm); setModalOpen(true); };
  const openEdit = (a) => {
    setEditing(a);
    setForm({
      title: a.title ?? "", category: a.category ?? "manual", equipment_category: a.equipment_category ?? "general",
      summary: a.summary ?? "", content: a.content ?? "", file_url: a.file_url ?? "", file_name: a.file_name ?? "",
      video_url: a.video_url ?? "", tags: a.tags ?? "", author: a.author ?? "",
    });
    setModalOpen(true);
  };

  const handleUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadPublicFile({ file });
      setForm((f) => ({ ...f, file_url, file_name: file.name }));
      toast({ title: "Faylka waa la soo geliyay" });
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Faylka lama soo gelin karin" });
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editing) {
        await base44.entities.KnowledgeArticle.update(editing.id, form);
        toast({ title: "Dukumentiga waa la cusboonaysiiyay" });
      } else {
        await base44.entities.KnowledgeArticle.create(form);
        toast({ title: "Dukumenti cusub waa la abuuray" });
      }
      setModalOpen(false);
      fetchData();
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Dukumentiga lama keydin karin" });
    }
  };

  const handleDelete = async (a) => {
    if (!confirm("Ma hubtaa inaad tirtirto dukumentigan?")) return;
    try {
      await base44.entities.KnowledgeArticle.delete(a.id);
      toast({ title: "Waa la tirtiray" });
      setSelected(null);
      fetchData();
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Lama tirtiri karo" });
    }
  };

  const filtered = articles.filter((a) => {
    const matchesCat = catFilter === "all" || a.category === catFilter;
    const q = search.trim().toLowerCase();
    const matchesSearch = !q ||
      [a.title, a.summary, a.content, a.tags, EQUIPMENT[a.equipment_category]].filter(Boolean).join(" ").toLowerCase().includes(q);
    return matchesCat && matchesSearch;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Xarunta Tababarka &amp; Dukumentaasiyada</h1>
          <p className="text-zinc-400 text-sm mt-1">Buugaagta hagaha iyo tilmaamaha qalabka — farsamoyaqaannada cusub</p>
        </div>
        <Button onClick={openCreate} className="gap-2 bg-amber-500 hover:bg-amber-600 text-black font-semibold">
          <Plus className="w-4 h-4" /> Dukumenti Cusub
        </Button>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Raadi buug, tilmaame ama qalab..."
            className="pl-9 bg-zinc-900/60 border-zinc-800 text-white"
          />
        </div>
        <Select value={catFilter} onValueChange={setCatFilter}>
          <SelectTrigger className="w-full sm:w-56 bg-zinc-900/60 border-zinc-800 text-white"><SelectValue /></SelectTrigger>
          <SelectContent className="bg-zinc-900 border-zinc-800">
            <SelectItem value="all">Dhammaan qaybaha</SelectItem>
            {Object.entries(CATEGORIES).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="py-24 flex items-center justify-center">
          <div className="w-8 h-8 border-4 border-amber-500/30 border-t-amber-500 rounded-full animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="py-20 text-center text-zinc-500 rounded-2xl bg-zinc-900/60 border border-zinc-800">
          <BookOpen className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p className="text-sm">{articles.length === 0 ? "Weli dukumenti lama abuurin" : "Waxba lama helin"}</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map((a) => {
            const c = CATEGORIES[a.category] || CATEGORIES.other;
            return (
              <button
                key={a.id}
                onClick={() => setSelected(a)}
                className="text-left rounded-2xl bg-zinc-900/60 border border-zinc-800 p-5 hover:border-zinc-700 transition-colors"
              >
                <div className="flex items-start gap-3 mb-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/15 flex items-center justify-center shrink-0">
                    <BookOpen className="w-5 h-5 text-amber-400" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <h3 className="text-white font-semibold text-sm leading-snug line-clamp-2">{a.title}</h3>
                    <p className="text-zinc-500 text-xs mt-1">{EQUIPMENT[a.equipment_category] || "Guud"}</p>
                  </div>
                </div>
                {a.summary && <p className="text-zinc-400 text-xs leading-relaxed line-clamp-2 mb-3">{a.summary}</p>}
                <div className="flex items-center gap-2 flex-wrap">
                  <span className={`px-2.5 py-1 rounded-full text-[10px] font-semibold border ${c.cls}`}>{c.label}</span>
                  {a.file_url && <Paperclip className="w-3.5 h-3.5 text-zinc-500" />}
                </div>
              </button>
            );
          })}
        </div>
      )}

      {/* Detail dialog */}
      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="max-w-3xl bg-zinc-900 border-zinc-800 text-white max-h-[90vh] overflow-y-auto">
          {selected && (
            <>
              <DialogHeader>
                <DialogTitle className="pr-8">{selected.title}</DialogTitle>
              </DialogHeader>
              <div className="flex flex-wrap items-center gap-2">
                <span className={`px-2.5 py-1 rounded-full text-[10px] font-semibold border ${(CATEGORIES[selected.category] || CATEGORIES.other).cls}`}>
                  {(CATEGORIES[selected.category] || CATEGORIES.other).label}
                </span>
                <span className="px-2.5 py-1 rounded-full text-[10px] font-medium bg-zinc-800 text-zinc-300">
                  {EQUIPMENT[selected.equipment_category] || "Guud"}
                </span>
                {selected.author && <span className="text-zinc-500 text-xs">{selected.author}</span>}
              </div>
              {selected.summary && <p className="text-zinc-400 text-sm italic border-l-2 border-amber-500/40 pl-3">{selected.summary}</p>}
              <div className="text-zinc-300 text-sm whitespace-pre-wrap leading-relaxed">{selected.content}</div>
              {selected.tags && (
                <div className="flex flex-wrap gap-2">
                  {selected.tags.split(",").map((t, i) => (
                    <span key={i} className="px-2 py-1 rounded-md bg-zinc-800 text-zinc-400 text-[10px]">{t.trim()}</span>
                  ))}
                </div>
              )}
              <div className="flex flex-wrap gap-2 pt-2 border-t border-zinc-800">
                {selected.file_url && (
                  <Button asChild variant="outline" className="border-zinc-700 text-zinc-200 hover:bg-zinc-800">
                    <a href={selected.file_url} target="_blank" rel="noreferrer">
                      <Paperclip className="w-4 h-4 mr-2" /> {selected.file_name || "Fur Faylka"}
                    </a>
                  </Button>
                )}
                {selected.video_url && (
                  <Button asChild variant="outline" className="border-zinc-700 text-zinc-200 hover:bg-zinc-800">
                    <a href={selected.video_url} target="_blank" rel="noreferrer"><ExternalLink className="w-4 h-4 mr-2" /> Video</a>
                  </Button>
                )}
              </div>
              <DialogFooter className="gap-2">
                <Button variant="outline" onClick={() => { const a = selected; setSelected(null); openEdit(a); }} className="border-zinc-700 text-zinc-300 hover:bg-zinc-800">
                  <Pencil className="w-4 h-4 mr-2" /> Wax Ka Bedel
                </Button>
                <Button variant="destructive" onClick={() => handleDelete(selected)}>
                  <Trash2 className="w-4 h-4 mr-2" /> Tirtir
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Form dialog */}
      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="max-w-2xl bg-zinc-900 border-zinc-800 text-white max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? "Wax Ka Bedel Dukumentiga" : "Dukumenti Cusub"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label>Cinwaanka *</Label>
              <Input required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" placeholder="T.c. Sida loo xiro Inverter-ka 5kW" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Qaybta *</Label>
                <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
                  <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-zinc-900 border-zinc-800">
                    {Object.entries(CATEGORIES).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Qalabka La Xiriira</Label>
                <Select value={form.equipment_category} onValueChange={(v) => setForm({ ...form, equipment_category: v })}>
                  <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-zinc-900 border-zinc-800">
                    {Object.entries(EQUIPMENT).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Soo Koobid</Label>
              <Input value={form.summary} onChange={(e) => setForm({ ...form, summary: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" />
            </div>
            <div className="space-y-2">
              <Label>Nuxurka / Tilmaamaha *</Label>
              <Textarea required rows={8} value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" placeholder="Ku qor tallaabooyinka..." />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Faylka (PDF / Manual)</Label>
                <div className="flex items-center gap-2">
                  <label className="flex-1 flex items-center justify-center gap-2 h-9 rounded-md border border-dashed border-zinc-700 text-zinc-400 text-xs cursor-pointer hover:border-zinc-600">
                    {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                    {form.file_name ? form.file_name.slice(0, 20) : "Soo geli fayl"}
                    <input type="file" className="hidden" onChange={handleUpload} />
                  </label>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Video Link</Label>
                <Input value={form.video_url} onChange={(e) => setForm({ ...form, video_url: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" placeholder="https://..." />
              </div>
              <div className="space-y-2">
                <Label>Tilmaamayaal (comma)</Label>
                <Input value={form.tags} onChange={(e) => setForm({ ...form, tags: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" placeholder="inverter, 5kW, xirid" />
              </div>
              <div className="space-y-2">
                <Label>Qoraaga</Label>
                <Input value={form.author} onChange={(e) => setForm({ ...form, author: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setModalOpen(false)} className="border-zinc-700 text-zinc-300 hover:bg-zinc-800">Jooji</Button>
              <Button type="submit" className="bg-amber-500 hover:bg-amber-600 text-black font-semibold">{editing ? "Cusboonaysii" : "Abuur"}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}