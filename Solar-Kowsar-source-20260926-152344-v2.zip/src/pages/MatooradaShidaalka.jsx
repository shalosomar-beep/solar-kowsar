import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Fuel, Plus, Pencil, Trash2, Clock, Droplet, DollarSign, Gauge } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

const emptyForm = {
  generator_name: "", log_date: new Date().toISOString().slice(0, 10),
  running_hours: "", fuel_consumed_liters: "", fuel_added_liters: "", fuel_cost: "", location: "", notes: "",
};

export default function MatooradaShidaalka() {
  const { toast } = useToast();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyForm);

  const fetchData = async () => {
    try {
      setLoading(true);
      const data = await base44.entities.GeneratorLog.list("-log_date", 300);
      setItems(data);
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Diiwaanka matoorada lama keeni karo" });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  const openCreate = () => { setEditing(null); setForm(emptyForm); setModalOpen(true); };
  const openEdit = (item) => {
    setEditing(item);
    setForm({
      generator_name: item.generator_name ?? "", log_date: item.log_date?.slice(0, 10) ?? "",
      running_hours: item.running_hours ?? "", fuel_consumed_liters: item.fuel_consumed_liters ?? "",
      fuel_added_liters: item.fuel_added_liters ?? "", fuel_cost: item.fuel_cost ?? "",
      location: item.location ?? "", notes: item.notes ?? "",
    });
    setModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const num = (v) => (v === "" ? undefined : Number(v));
    const payload = {
      ...form,
      running_hours: num(form.running_hours),
      fuel_consumed_liters: num(form.fuel_consumed_liters),
      fuel_added_liters: num(form.fuel_added_liters),
      fuel_cost: num(form.fuel_cost),
    };
    try {
      if (editing) {
        await base44.entities.GeneratorLog.update(editing.id, payload);
        toast({ title: "Diiwaanka waa la cusboonaysiiyay" });
      } else {
        await base44.entities.GeneratorLog.create(payload);
        toast({ title: "Diiwaan cusub waa la abuuray" });
      }
      setModalOpen(false);
      fetchData();
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Diiwaanka lama keydin karin" });
    }
  };

  const handleDelete = async (item) => {
    if (!confirm("Ma hubtaa inaad tirtirto diiwaankan?")) return;
    try {
      await base44.entities.GeneratorLog.delete(item.id);
      toast({ title: "Waa la tirtiray" });
      fetchData();
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Lama tirtiri karo" });
    }
  };

  const totalHours = items.reduce((s, i) => s + (i.running_hours || 0), 0);
  const totalFuel = items.reduce((s, i) => s + (i.fuel_consumed_liters || 0), 0);
  const totalCost = items.reduce((s, i) => s + (i.fuel_cost || 0), 0);
  const avgRate = totalHours > 0 ? totalFuel / totalHours : 0;

  const chartData = [...items]
    .filter((i) => i.log_date)
    .sort((a, b) => new Date(a.log_date) - new Date(b.log_date))
    .slice(-14)
    .map((i) => ({
      date: i.log_date?.slice(5),
      fuel: i.fuel_consumed_liters || 0,
      hours: i.running_hours || 0,
    }));

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Matoorada Shidaalka (Generator)</h1>
          <p className="text-zinc-400 text-sm mt-1">La soco isticmaalka shidaalka iyo saacadaha matooradu shaqaynayso</p>
        </div>
        <Button onClick={openCreate} className="gap-2 bg-amber-500 hover:bg-amber-600 text-black font-semibold">
          <Plus className="w-4 h-4" /> Diiwaan Cusub
        </Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatBox label="Saacadaha Shaqada" value={`${totalHours.toFixed(1)} h`} icon={Clock} color="text-blue-400" bg="from-blue-500/10 to-blue-600/5 border-blue-500/15" />
        <StatBox label="Shidaalka La Isticmaalay" value={`${totalFuel.toFixed(1)} L`} icon={Droplet} color="text-amber-400" bg="from-amber-500/10 to-amber-600/5 border-amber-500/15" />
        <StatBox label="Qiimaha Shidaalka" value={`$${totalCost.toLocaleString()}`} icon={DollarSign} color="text-red-400" bg="from-red-500/10 to-red-600/5 border-red-500/15" />
        <StatBox label="Celcelis L/Saacad" value={avgRate.toFixed(2)} icon={Gauge} color="text-emerald-400" bg="from-emerald-500/10 to-emerald-600/5 border-emerald-500/15" />
      </div>

      {chartData.length > 0 && (
        <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-5">
          <h2 className="text-white font-semibold mb-1">Isticmaalka Shidaalka</h2>
          <p className="text-zinc-500 text-xs mb-4">Litre maalin kasta (14 diiwaan ee ugu dambeeyay)</p>
          <div style={{ width: "100%", height: 260 }}>
            <ResponsiveContainer>
              <BarChart data={chartData} margin={{ top: 4, right: 8, left: -18, bottom: 4 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                <XAxis dataKey="date" tick={{ fill: "#a1a1aa", fontSize: 11 }} axisLine={{ stroke: "#3f3f46" }} tickLine={false} />
                <YAxis tick={{ fill: "#a1a1aa", fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ background: "#18181b", border: "1px solid #3f3f46", borderRadius: 12, color: "#fff" }} />
                <Bar dataKey="fuel" name="Litre" fill="#f59e0b" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 overflow-hidden">
        {loading ? (
          <div className="py-16 flex items-center justify-center">
            <div className="w-8 h-8 border-4 border-amber-500/30 border-t-amber-500 rounded-full animate-spin" />
          </div>
        ) : items.length === 0 ? (
          <div className="py-16 text-center text-zinc-500">
            <Fuel className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="text-sm">Diiwaan lama helin</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-zinc-800 text-zinc-400 text-xs uppercase tracking-wider">
                  <th className="text-left px-5 py-3 font-medium">Matoora</th>
                  <th className="text-left px-5 py-3 font-medium">Taariikhda</th>
                  <th className="text-right px-5 py-3 font-medium">Saacado</th>
                  <th className="text-right px-5 py-3 font-medium">Shidaal (L)</th>
                  <th className="text-right px-5 py-3 font-medium">La Kudaray (L)</th>
                  <th className="text-right px-5 py-3 font-medium">Qiimaha</th>
                  <th className="text-left px-5 py-3 font-medium">Goobta</th>
                  <th className="text-right px-5 py-3 font-medium">Ficil</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/50">
                {items.map((i) => (
                  <tr key={i.id} className="hover:bg-zinc-900/50 transition-colors">
                    <td className="px-5 py-3 text-white font-medium">{i.generator_name}</td>
                    <td className="px-5 py-3 text-zinc-400">{i.log_date}</td>
                    <td className="px-5 py-3 text-right text-zinc-300">{i.running_hours ?? "—"}</td>
                    <td className="px-5 py-3 text-right text-amber-400">{i.fuel_consumed_liters ?? "—"}</td>
                    <td className="px-5 py-3 text-right text-zinc-300">{i.fuel_added_liters ?? "—"}</td>
                    <td className="px-5 py-3 text-right text-zinc-300">{i.fuel_cost != null ? `$${i.fuel_cost}` : "—"}</td>
                    <td className="px-5 py-3 text-zinc-400">{i.location || "—"}</td>
                    <td className="px-5 py-3 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Button variant="ghost" size="icon" onClick={() => openEdit(i)} className="h-8 w-8 text-zinc-400 hover:text-amber-400">
                          <Pencil className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleDelete(i)} className="h-8 w-8 text-zinc-400 hover:text-red-400">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="max-w-lg bg-zinc-900 border-zinc-800 text-white">
          <DialogHeader>
            <DialogTitle>{editing ? "Wax Ka Bedel Diiwaanka" : "Diiwaan Cusub"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Magaca Matoora *</Label>
                <Input required value={form.generator_name} onChange={(e) => setForm({ ...form, generator_name: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" placeholder="T.c. Generator A" />
              </div>
              <div className="space-y-2">
                <Label>Taariikhda *</Label>
                <Input required type="date" value={form.log_date} onChange={(e) => setForm({ ...form, log_date: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" />
              </div>
              <div className="space-y-2">
                <Label>Saacadaha Shaqada</Label>
                <Input type="number" step="0.1" value={form.running_hours} onChange={(e) => setForm({ ...form, running_hours: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" />
              </div>
              <div className="space-y-2">
                <Label>Shidaal La Isticmaalay (L)</Label>
                <Input type="number" step="0.1" value={form.fuel_consumed_liters} onChange={(e) => setForm({ ...form, fuel_consumed_liters: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" />
              </div>
              <div className="space-y-2">
                <Label>Shidaal La Kudaray (L)</Label>
                <Input type="number" step="0.1" value={form.fuel_added_liters} onChange={(e) => setForm({ ...form, fuel_added_liters: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" />
              </div>
              <div className="space-y-2">
                <Label>Qiimaha Shidaalka ($)</Label>
                <Input type="number" step="0.01" value={form.fuel_cost} onChange={(e) => setForm({ ...form, fuel_cost: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" />
              </div>
              <div className="col-span-2 space-y-2">
                <Label>Goobta</Label>
                <Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setModalOpen(false)} className="border-zinc-700 text-zinc-300 hover:bg-zinc-800">Jooji</Button>
              <Button type="submit" className="bg-amber-500 hover:bg-amber-600 text-black font-semibold">{editing ? "Cusboonaysii" : "Abuur"}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function StatBox({ label, value, icon: Icon, color, bg }) {
  return (
    <div className={`rounded-2xl bg-gradient-to-br border p-5 ${bg}`}>
      <div className="flex items-center justify-between mb-3">
        <p className="text-zinc-400 text-xs font-medium uppercase tracking-wider">{label}</p>
        <Icon className={`w-4 h-4 ${color}`} />
      </div>
      <p className={`text-2xl font-bold ${color}`}>{value}</p>
    </div>
  );
}