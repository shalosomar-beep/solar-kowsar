import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { History, Search, ShieldCheck, Users, FileText, Wallet, Package, LifeBuoy, Banknote } from "lucide-react";

const SOURCES = [
  { type: "customer", entity: "Customer", label: "Macmiil", titleField: "full_name", icon: Users, color: "text-blue-400" },
  { type: "billing", entity: "Billing", label: "Biil", titleField: "billing_month", icon: FileText, color: "text-emerald-400" },
  { type: "expense", entity: "Expense", label: "Kharash", titleField: "title", icon: Wallet, color: "text-orange-400" },
  { type: "equipment", entity: "Equipment", label: "Qalab", titleField: "name", icon: Package, color: "text-purple-400" },
  { type: "ticket", entity: "SupportTicket", label: "Tikidh", titleField: "subject", icon: LifeBuoy, color: "text-amber-400" },
];

export default function Diiwaanka() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [kind, setKind] = useState("all");

  useEffect(() => {
    (async () => {
      try {
        const [logs, ...lists] = await Promise.all([
          base44.entities.AuditLog.list("-created_date", 100).catch(() => []),
          ...SOURCES.map((s) => base44.entities[s.entity].list("-created_date", 15).catch(() => [])),
        ]);

        let userMap = {};
        try {
          const users = await base44.entities.User.list();
          users.forEach((u) => { userMap[u.id] = u.full_name || u.email; });
        } catch {
          userMap = {};
        }

        const auditEvents = (logs || []).map((l) => {
          const isFinance = l.category === "finance";
          return {
            id: `audit-${l.id}`,
            kind: isFinance ? "finance" : "audit",
            label: l.action || "Hawl",
            title: l.details || l.target_email || "—",
            who: l.performed_by_name || l.performed_by_email || "",
            date: l.timestamp || l.created_date,
            icon: isFinance ? Banknote : ShieldCheck,
            color: isFinance ? "text-amber-400" : "text-emerald-400",
          };
        });

        const activityEvents = SOURCES.flatMap((s, i) =>
          (lists[i] || []).map((r) => ({
            id: `${s.type}-${r.id}`,
            kind: "activity",
            label: s.label,
            title: r[s.titleField] || "—",
            who: userMap[r.created_by_id] || "",
            date: r.created_date,
            icon: s.icon,
            color: s.color,
          }))
        );

        const merged = [...auditEvents, ...activityEvents]
          .filter((e) => e.date)
          .sort((a, b) => new Date(b.date) - new Date(a.date))
          .slice(0, 80);

        setEvents(merged);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const filtered = events.filter((e) => {
    const q = search.toLowerCase();
    const matchQ =
      !q ||
      e.title?.toLowerCase().includes(q) ||
      e.who?.toLowerCase().includes(q) ||
      e.label?.toLowerCase().includes(q);
    const matchKind = kind === "all" || e.kind === kind;
    return matchQ && matchKind;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-lg bg-orange-500/10 flex items-center justify-center">
          <History className="w-5 h-5 text-orange-500" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white">Diiwaanka Nidaamka</h1>
          <p className="text-zinc-400 text-sm">Dhaqdhaqaaqa nidaamka iyo hawlaha shaqaalaha</p>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
          <Input
            placeholder="Raadi hawl, qof ama diiwaan..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 bg-zinc-900 border-zinc-800 text-white placeholder:text-zinc-600"
          />
        </div>
        <Select value={kind} onValueChange={setKind}>
          <SelectTrigger className="w-48 bg-zinc-900 border-zinc-800 text-white"><SelectValue /></SelectTrigger>
          <SelectContent className="bg-zinc-900 border-zinc-800">
            <SelectItem value="all">Dhammaan</SelectItem>
            <SelectItem value="audit">Hawlaha Shaqaalaha</SelectItem>
            <SelectItem value="finance">Maaliyadda (Biilasha & Lacagaha)</SelectItem>
            <SelectItem value="activity">Dhaqdhaqaaqa Xogta</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="py-20 flex items-center justify-center">
          <div className="w-8 h-8 border-4 border-orange-500/30 border-t-orange-500 rounded-full animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="py-20 text-center text-zinc-500">
          <History className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p className="text-sm">Diiwaan lama helin</p>
        </div>
      ) : (
        <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 divide-y divide-zinc-800/60 overflow-hidden">
          {filtered.map((e) => {
            const Icon = e.icon;
            return (
              <div key={e.id} className="flex items-start gap-4 p-4 hover:bg-zinc-900/80 transition-colors">
                <div className={`w-9 h-9 rounded-lg bg-zinc-800/80 flex items-center justify-center shrink-0 ${e.color}`}>
                  <Icon className="w-4 h-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-white text-sm font-medium">{e.label}</span>
                    {e.kind === "audit" && (
                      <span className="inline-flex px-2 py-0.5 rounded-full text-[10px] font-medium bg-emerald-500/15 text-emerald-400">
                        Audit
                      </span>
                    )}
                    {e.kind === "finance" && (
                      <span className="inline-flex px-2 py-0.5 rounded-full text-[10px] font-medium bg-amber-500/15 text-amber-400">
                        Maaliyadda
                      </span>
                    )}
                  </div>
                  <p className="text-zinc-300 text-sm mt-0.5 truncate">{e.title}</p>
                  {e.who && <p className="text-zinc-500 text-xs mt-0.5">Fuliyaha: {e.who}</p>}
                </div>
                <span className="text-zinc-500 text-xs whitespace-nowrap shrink-0">
                  {e.date ? new Date(e.date).toLocaleString() : "—"}
                </span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}