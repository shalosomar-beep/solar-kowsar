import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Wallet, Plus, Smartphone, CreditCard, Building2, Banknote, Loader2, Pencil, Trash2, Star } from "lucide-react";

const PROVIDER_META = {
  evc_plus: { label: "EVC Plus", icon: Smartphone, color: "#f59e0b" },
  zaad: { label: "Zaad", icon: Smartphone, color: "#22c55e" },
  premier_wallet: { label: "Premier Wallet", icon: Smartphone, color: "#3b82f6" },
  edahab: { label: "eDahab", icon: Smartphone, color: "#a855f7" },
  bank_transfer: { label: "Wareejin Bangi", icon: Building2, color: "#06b6d4" },
  card: { label: "Kaararka Bangiga", icon: CreditCard, color: "#ec4899" },
  cash: { label: "Cash", icon: Banknote, color: "#84cc16" },
  other: { label: "Kale", icon: Wallet, color: "#71717a" },
};

const emptyForm = {
  name: "",
  provider: "evc_plus",
  account_name: "",
  account_number: "",
  instructions: "",
  enabled: true,
  is_default: false,
};

export default function HababkaLacagta() {
  const { toast } = useToast();
  const [methods, setMethods] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);

  const fetch = async () => {
    try {
      setLoading(true);
      const data = await base44.entities.PaymentMethod.list("-created_date", 200);
      setMethods(data);
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Hababka lacagta lama keeni karo" });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetch(); }, []);

  const openCreate = () => { setEditing(null); setForm(emptyForm); setModalOpen(true); };
  const openEdit = (m) => {
    setEditing(m);
    setForm({
      name: m.name || "",
      provider: m.provider || "evc_plus",
      account_name: m.account_name || "",
      account_number: m.account_number || "",
      instructions: m.instructions || "",
      enabled: m.enabled ?? true,
      is_default: m.is_default ?? false,
    });
    setModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (editing) {
        await base44.entities.PaymentMethod.update(editing.id, form);
        toast({ title: "Waa la cusboonaysiiyay", description: "Habka lacagta waa la bedelay" });
      } else {
        await base44.entities.PaymentMethod.create(form);
        toast({ title: "Waa la diiwaangeliyay", description: "Hab lacag bixin cusub waa la xareeyay" });
      }
      setModalOpen(false);
      fetch();
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Hawl lama soosaarin karo" });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (m) => {
    try {
      await base44.entities.PaymentMethod.delete(m.id);
      toast({ title: "Waa la tirtiray", description: "Habka lacagta waa la saaray" });
      fetch();
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Lama tirtiri karo" });
    }
  };

  const toggleEnabled = async (m) => {
    try {
      await base44.entities.PaymentMethod.update(m.id, { enabled: !m.enabled });
      fetch();
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Lama beddeli karo" });
    }
  };

  const enabledCount = methods.filter((m) => m.enabled).length;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Hababka Lacag Bixinta</h1>
          <p className="text-zinc-400 text-sm mt-1">Maamul EVC Plus, Zaad, Premier Wallet, kaararka bangiga iyo kuwa kale</p>
        </div>
        <Button onClick={openCreate} className="gap-2 bg-orange-500 hover:bg-orange-600 text-white">
          <Plus className="w-4 h-4" /> Kudar Hab Lacag
        </Button>
      </div>

      <div className="flex items-center gap-4 text-sm text-zinc-400">
        <span><span className="text-white font-semibold">{methods.length}</span> hab</span>
        <span className="text-zinc-700">·</span>
        <span><span className="text-emerald-400 font-semibold">{enabledCount}</span> firfircoon</span>
      </div>

      {loading ? (
        <div className="py-20 flex items-center justify-center">
          <div className="w-8 h-8 border-4 border-orange-500/30 border-t-orange-500 rounded-full animate-spin" />
        </div>
      ) : methods.length === 0 ? (
        <div className="py-20 text-center text-zinc-500">
          <Wallet className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p className="text-sm">Hab lacag bixin lama helin. Kudar hab cusub.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {methods.map((m) => {
            const meta = PROVIDER_META[m.provider] || PROVIDER_META.other;
            const Icon = meta.icon;
            return (
              <div key={m.id} className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-5 hover:border-zinc-700 transition-colors group">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ background: `${meta.color}1a`, color: meta.color }}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <h3 className="text-white font-semibold text-sm truncate">{m.name}</h3>
                      <p className="text-zinc-500 text-xs mt-0.5">{meta.label}</p>
                    </div>
                  </div>
                  {m.is_default && (
                    <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-medium text-amber-400 bg-amber-500/10 border border-amber-500/20 shrink-0">
                      <Star className="w-3 h-3" /> Caadi
                    </span>
                  )}
                </div>

                <div className="space-y-2.5 text-sm">
                  {m.account_name && <Row label="Magaca Akawnta" value={m.account_name} />}
                  {m.account_number && <Row label="Lambarka" value={m.account_number} mono />}
                  {m.instructions && <p className="text-zinc-500 text-xs leading-relaxed pt-1">{m.instructions}</p>}
                </div>

                <div className="flex items-center justify-between mt-4 pt-4 border-t border-zinc-800/60">
                  <button onClick={() => toggleEnabled(m)} className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border transition-colors ${m.enabled ? "text-emerald-400 bg-emerald-500/10 border-emerald-500/20" : "text-zinc-500 bg-zinc-500/10 border-zinc-500/20"}`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${m.enabled ? "bg-emerald-500" : "bg-zinc-500"}`} />
                    {m.enabled ? "Firfircoon" : "Daman"}
                  </button>
                  <div className="flex items-center gap-1">
                    <button onClick={() => openEdit(m)} className="text-zinc-400 hover:text-blue-400 transition-colors p-1.5"><Pencil className="w-4 h-4" /></button>
                    <button onClick={() => handleDelete(m)} className="text-zinc-400 hover:text-red-400 transition-colors p-1.5"><Trash2 className="w-4 h-4" /></button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="bg-zinc-900 border-zinc-800 text-white sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{editing ? "Wax Ka Beddel Habka" : "Kudar Hab Lacag Bixin"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label className="text-zinc-300">Magaca Habka *</Label>
              <Input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" placeholder="T.c. EVC Plus Shirkadda" />
            </div>
            <div className="space-y-2">
              <Label className="text-zinc-300">Bixiyaha</Label>
              <Select value={form.provider} onValueChange={(v) => setForm({ ...form, provider: v })}>
                <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-zinc-900 border-zinc-800">
                  {Object.entries(PROVIDER_META).map(([v, m]) => (
                    <SelectItem key={v} value={v}>{m.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-zinc-300">Magaca Akawnta</Label>
                <Input value={form.account_name} onChange={(e) => setForm({ ...form, account_name: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" placeholder="Solar Kowsar" />
              </div>
              <div className="space-y-2">
                <Label className="text-zinc-300">Lambarka Akawnta</Label>
                <Input value={form.account_number} onChange={(e) => setForm({ ...form, account_number: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" placeholder="0615XXXXXX" />
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-zinc-300">Tilmaamaha Lacag Bixinta</Label>
              <Textarea rows={3} value={form.instructions} onChange={(e) => setForm({ ...form, instructions: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" placeholder="T.c. U dir lacagta lambarka sare kadibna soo dir sawirka xaqiijinta." />
            </div>
            <div className="flex items-center justify-between rounded-xl bg-zinc-800/50 border border-zinc-800 px-4 py-3">
              <Label className="text-zinc-300">Firfircoon</Label>
              <Switch checked={form.enabled} onCheckedChange={(v) => setForm({ ...form, enabled: v })} />
            </div>
            <div className="flex items-center justify-between rounded-xl bg-zinc-800/50 border border-zinc-800 px-4 py-3">
              <Label className="text-zinc-300">Habka Caadiga ah</Label>
              <Switch checked={form.is_default} onCheckedChange={(v) => setForm({ ...form, is_default: v })} />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setModalOpen(false)} className="border-zinc-700 text-zinc-300">Jooji</Button>
              <Button type="submit" disabled={saving} className="bg-orange-500 hover:bg-orange-600 text-white">
                {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
                {editing ? "Kaydi" : "Ku Dar"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Row({ label, value, mono }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-zinc-500 shrink-0">{label}</span>
      <span className={`font-medium text-zinc-200 truncate ${mono ? "font-mono text-xs" : ""}`}>{value}</span>
    </div>
  );
}