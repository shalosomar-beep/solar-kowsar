import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import DataPagination from "@/components/common/DataPagination";
import DataErrorState from "@/components/common/DataErrorState";
import { Plus, FileText, Search, Pencil, Trash2, ShieldCheck, AlertTriangle, Clock } from "lucide-react";

const SORTS = {
  newest: { label: "Ugu Dambeeyay", fn: (a, b) => new Date(b.created_date || 0) - new Date(a.created_date || 0) },
  value: { label: "Qiimaha (sare → hoose)", fn: (a, b) => (b.value || 0) - (a.value || 0) },
  endDate: { label: "Dhammaadka (ugu dhow)", fn: (a, b) => new Date(a.end_date || 0) - new Date(b.end_date || 0) },
  title: { label: "Cinwaanka (A–Z)", fn: (a, b) => (a.title || "").localeCompare(b.title || "") },
};

const PER_PAGE = 6;

const TYPE_LABELS = {
  service: "Adeeg",
  maintenance: "Dayactir",
  rental: "Kiro",
  sla: "SLA",
  warranty: "Dammaanad",
};

const STATUS_META = {
  active: { label: "Firfircoon", cls: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30" },
  pending: { label: "Sugaya", cls: "bg-amber-500/15 text-amber-400 border-amber-500/30" },
  expired: { label: "Dhacay", cls: "bg-red-500/15 text-red-400 border-red-500/30" },
  terminated: { label: "La Joojiyay", cls: "bg-zinc-500/15 text-zinc-400 border-zinc-500/30" },
};

const emptyForm = {
  title: "", contract_number: "", customer: "", type: "service",
  start_date: "", end_date: "", value: "", sla_response_hours: "",
  warranty_months: "", status: "active", terms: "", notes: "",
};

function daysLeft(endDate) {
  if (!endDate) return null;
  const diff = Math.ceil((new Date(endDate) - new Date()) / (1000 * 60 * 60 * 24));
  return diff;
}

export default function Heshiisyada() {
  const { toast } = useToast();
  const [items, setItems] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [sortBy, setSortBy] = useState("newest");
  const [page, setPage] = useState(1);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyForm);

  const fetchData = async () => {
    try {
      setLoading(true);
      setError(false);
      const [data, custs] = await Promise.all([
        base44.entities.Contract.list("-created_date", 200),
        base44.entities.Customer.list("-created_date", 300),
      ]);
      setItems(data);
      setCustomers(custs);
    } catch {
      setError(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  const custName = (id) => customers.find((c) => c.id === id)?.full_name || "—";

  const openCreate = () => { setEditing(null); setForm(emptyForm); setModalOpen(true); };
  const openEdit = (item) => {
    setEditing(item);
    setForm({
      title: item.title ?? "", contract_number: item.contract_number ?? "", customer: item.customer ?? "",
      type: item.type ?? "service", start_date: item.start_date ?? "", end_date: item.end_date ?? "",
      value: item.value ?? "", sla_response_hours: item.sla_response_hours ?? "",
      warranty_months: item.warranty_months ?? "", status: item.status ?? "active",
      terms: item.terms ?? "", notes: item.notes ?? "",
    });
    setModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const payload = {
        ...form,
        customer: form.customer || null,
        value: form.value === "" ? undefined : Number(form.value),
        sla_response_hours: form.sla_response_hours === "" ? undefined : Number(form.sla_response_hours),
        warranty_months: form.warranty_months === "" ? undefined : Number(form.warranty_months),
      };
      if (editing) {
        await base44.entities.Contract.update(editing.id, payload);
        toast({ title: "Heshiiska waa la cusboonaysiiyay" });
      } else {
        await base44.entities.Contract.create(payload);
        toast({ title: "Heshiis cusub waa la abuuray" });
      }
      setModalOpen(false);
      fetchData();
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Heshiiska lama keydin karin" });
    }
  };

  const handleDelete = async (item) => {
    try {
      await base44.entities.Contract.delete(item.id);
      toast({ title: "Waa la tirtiray" });
      fetchData();
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Lama tirtiri karo" });
    }
  };

  const activeCount = items.filter((i) => i.status === "active").length;
  const expiringCount = items.filter((i) => {
    const d = daysLeft(i.end_date);
    return i.status === "active" && d !== null && d >= 0 && d <= 30;
  }).length;
  const expiredCount = items.filter((i) => i.status === "expired" || (daysLeft(i.end_date) !== null && daysLeft(i.end_date) < 0)).length;
  const totalValue = items.filter((i) => i.status === "active").reduce((s, i) => s + (i.value || 0), 0);

  const filtered = items.filter((i) => {
    const q = search.toLowerCase();
    const matchQ =
      !q ||
      i.title?.toLowerCase().includes(q) ||
      i.contract_number?.toLowerCase().includes(q) ||
      custName(i.customer).toLowerCase().includes(q);
    const matchStatus = statusFilter === "all" || i.status === statusFilter;
    return matchQ && matchStatus;
  });

  const sorted = [...filtered].sort(SORTS[sortBy].fn);
  const pageCount = Math.max(1, Math.ceil(sorted.length / PER_PAGE));
  const safePage = Math.min(page, pageCount);
  const visible = sorted.slice((safePage - 1) * PER_PAGE, safePage * PER_PAGE);
  const from = sorted.length === 0 ? 0 : (safePage - 1) * PER_PAGE + 1;
  const to = Math.min(safePage * PER_PAGE, sorted.length);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Heshiisyada &amp; SLA</h1>
          <p className="text-zinc-400 text-sm mt-1">Heshiisyada rasmiga ah, heerarka adeegga (SLA) iyo dammaanadda qalabka</p>
        </div>
        <Button onClick={openCreate} className="gap-2 bg-amber-500 hover:bg-amber-600 text-black font-semibold">
          <Plus className="w-4 h-4" /> Heshiis Cusub
        </Button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatBox label="Firfircoon" value={activeCount} icon={ShieldCheck} color="text-emerald-400" bg="from-emerald-500/10 to-emerald-600/5 border-emerald-500/15" />
        <StatBox label="Dhammaanaya 30 Maalmood" value={expiringCount} icon={Clock} color="text-amber-400" bg="from-amber-500/10 to-amber-600/5 border-amber-500/15" />
        <StatBox label="Dhacay" value={expiredCount} icon={AlertTriangle} color="text-red-400" bg="from-red-500/10 to-red-600/5 border-red-500/15" />
        <StatBox label="Qiimaha Firfircoon" value={`$${totalValue.toLocaleString()}`} icon={FileText} color="text-blue-400" bg="from-blue-500/10 to-blue-600/5 border-blue-500/15" />
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
          <Input
            placeholder="Raadi heshiis, lambar ama macmiil..."
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            className="pl-10 bg-zinc-900 border-zinc-800 text-white placeholder:text-zinc-600"
          />
        </div>
        <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setPage(1); }}>
          <SelectTrigger className="w-44 bg-zinc-900 border-zinc-800 text-white"><SelectValue /></SelectTrigger>
          <SelectContent className="bg-zinc-900 border-zinc-800">
            <SelectItem value="all">Dhammaan</SelectItem>
            {Object.entries(STATUS_META).map(([v, m]) => (
              <SelectItem key={v} value={v}>{m.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={sortBy} onValueChange={(v) => { setSortBy(v); setPage(1); }}>
          <SelectTrigger className="w-52 bg-zinc-900 border-zinc-800 text-white"><SelectValue /></SelectTrigger>
          <SelectContent className="bg-zinc-900 border-zinc-800">
            {Object.entries(SORTS).map(([v, s]) => (
              <SelectItem key={v} value={v}>{s.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="py-20 flex items-center justify-center">
          <div className="w-8 h-8 border-4 border-amber-500/30 border-t-amber-500 rounded-full animate-spin" />
        </div>
      ) : error ? (
        <DataErrorState onRetry={fetchData} />
      ) : sorted.length === 0 ? (
        <div className="py-20 text-center text-zinc-500">
          <FileText className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p className="text-sm">Heshiis lama helin</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {visible.map((c) => {
            const st = STATUS_META[c.status] || STATUS_META.active;
            const left = daysLeft(c.end_date);
            return (
              <div key={c.id} className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-5 hover:border-zinc-700 transition-colors">
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="min-w-0">
                    <h3 className="text-white font-semibold truncate">{c.title}</h3>
                    <p className="text-zinc-500 text-xs mt-0.5">
                      {custName(c.customer)}
                      {c.contract_number ? ` · ${c.contract_number}` : ""}
                    </p>
                  </div>
                  <span className={`inline-flex px-2.5 py-1 rounded-full text-xs font-medium border shrink-0 ${st.cls}`}>{st.label}</span>
                </div>

                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <p className="text-zinc-500 text-xs">Nooca</p>
                    <p className="text-zinc-200">{TYPE_LABELS[c.type] || c.type}</p>
                  </div>
                  <div>
                    <p className="text-zinc-500 text-xs">Qiimaha</p>
                    <p className="text-zinc-200">{c.value != null ? `$${c.value.toLocaleString()}` : "—"}</p>
                  </div>
                  <div>
                    <p className="text-zinc-500 text-xs">Mudada</p>
                    <p className="text-zinc-200">{c.start_date || "—"} → {c.end_date || "—"}</p>
                  </div>
                  <div>
                    <p className="text-zinc-500 text-xs">SLA / Dammaanad</p>
                    <p className="text-zinc-200">
                      {c.sla_response_hours != null ? `${c.sla_response_hours}h` : "—"}
                      {c.warranty_months != null ? ` · ${c.warranty_months} bil` : ""}
                    </p>
                  </div>
                </div>

                {left !== null && (
                  <p className={`text-xs mt-3 ${left < 0 ? "text-red-400" : left <= 30 ? "text-amber-400" : "text-zinc-500"}`}>
                    {left < 0 ? `Waxay dhacday ${Math.abs(left)} maalmood ka hor` : `${left} maalmood ayaa ka hadhay`}
                  </p>
                )}

                <div className="flex justify-end gap-1 mt-3 pt-3 border-t border-zinc-800/50">
                  <Button variant="ghost" size="icon" onClick={() => openEdit(c)} className="h-8 w-8 text-zinc-400 hover:text-amber-400">
                    <Pencil className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => handleDelete(c)} className="h-8 w-8 text-zinc-400 hover:text-red-400">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {!loading && !error && (
        <DataPagination page={safePage} pageCount={pageCount} total={sorted.length} from={from} to={to} onPage={setPage} />
      )}

      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="max-w-2xl bg-zinc-900 border-zinc-800 text-white max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? "Wax Ka Bedel Heshiiska" : "Heshiis Cusub"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2 space-y-2">
                <Label>Cinwaanka Heshiiska *</Label>
                <Input required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" placeholder="T.c. Heshiis Dayactir Sanadle" />
              </div>
              <div className="space-y-2">
                <Label>Lambarka Heshiiska</Label>
                <Input value={form.contract_number} onChange={(e) => setForm({ ...form, contract_number: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" placeholder="CNT-001" />
              </div>
              <div className="space-y-2">
                <Label>Macmiilka *</Label>
                <Select value={form.customer} onValueChange={(v) => setForm({ ...form, customer: v })}>
                  <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white"><SelectValue placeholder="Dooro macmiil" /></SelectTrigger>
                  <SelectContent className="bg-zinc-900 border-zinc-800">
                    {customers.map((c) => <SelectItem key={c.id} value={c.id}>{c.full_name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Nooca</Label>
                <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
                  <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-zinc-900 border-zinc-800">
                    {Object.entries(TYPE_LABELS).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Xaaladda</Label>
                <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                  <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-zinc-900 border-zinc-800">
                    {Object.entries(STATUS_META).map(([v, m]) => <SelectItem key={v} value={v}>{m.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Taariikhda Bilowga *</Label>
                <Input required type="date" value={form.start_date} onChange={(e) => setForm({ ...form, start_date: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" />
              </div>
              <div className="space-y-2">
                <Label>Taariikhda Dhammaadka</Label>
                <Input type="date" value={form.end_date} onChange={(e) => setForm({ ...form, end_date: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" />
              </div>
              <div className="space-y-2">
                <Label>Qiimaha ($)</Label>
                <Input type="number" step="any" value={form.value} onChange={(e) => setForm({ ...form, value: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" />
              </div>
              <div className="space-y-2">
                <Label>SLA — Saacadaha Jawaabta</Label>
                <Input type="number" value={form.sla_response_hours} onChange={(e) => setForm({ ...form, sla_response_hours: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" placeholder="24" />
              </div>
              <div className="space-y-2">
                <Label>Dammaanad Qalabka (Bilood)</Label>
                <Input type="number" value={form.warranty_months} onChange={(e) => setForm({ ...form, warranty_months: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" placeholder="12" />
              </div>
              <div className="col-span-2 space-y-2">
                <Label>Shuruudaha Heshiiska</Label>
                <Textarea value={form.terms} onChange={(e) => setForm({ ...form, terms: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" rows={3} />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setModalOpen(false)} className="border-zinc-700 text-zinc-300 hover:bg-zinc-800">Jooji</Button>
              <Button type="submit" className="bg-amber-500 hover:bg-amber-600 text-black font-semibold">{editing ? "Cusboonaysii" : "Abuur"}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function StatBox({ label, value, icon: Icon, color, bg }) {
  return (
    <div className={`rounded-2xl bg-gradient-to-br border p-5 ${bg}`}>
      <div className="flex items-center justify-between mb-3">
        <p className="text-zinc-400 text-xs font-medium uppercase tracking-wider">{label}</p>
        <Icon className={`w-4 h-4 ${color}`} />
      </div>
      <p className={`text-2xl font-bold ${color}`}>{value}</p>
    </div>
  );
}