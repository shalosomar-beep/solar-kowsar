import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { ShoppingCart, Plus, Pencil, Trash2, Truck, PackageCheck, DollarSign, Ship } from "lucide-react";
import { useT } from "@/lib/i18n";

const CATEGORIES = [
  { value: "solar_panel", labelKey: "equip.solar_panel" },
  { value: "battery", labelKey: "equip.battery" },
  { value: "inverter", labelKey: "equip.inverter" },
  { value: "generator", labelKey: "equip.generator" },
  { value: "smart_meter", labelKey: "equip.smart_meter" },
  { value: "cable", labelKey: "proc.cat.cable" },
  { value: "other", labelKey: "proc.cat.other" },
];

const MODES = [
  { value: "sea", labelKey: "proc.mode.sea" },
  { value: "air", labelKey: "proc.mode.air" },
  { value: "road", labelKey: "proc.mode.road" },
  { value: "local", labelKey: "proc.mode.local" },
];

const STATUS = {
  draft: { labelKey: "proc.status.draft", cls: "bg-zinc-700/40 text-zinc-300 border-zinc-600/40" },
  ordered: { labelKey: "status.ordered", cls: "bg-blue-500/15 text-blue-400 border-blue-500/25" },
  in_transit: { labelKey: "status.inTransit", cls: "bg-amber-500/15 text-amber-400 border-amber-500/25" },
  customs: { labelKey: "proc.status.customs", cls: "bg-purple-500/15 text-purple-400 border-purple-500/25" },
  delivered: { labelKey: "status.delivered", cls: "bg-emerald-500/15 text-emerald-400 border-emerald-500/25" },
  cancelled: { labelKey: "status.cancelled", cls: "bg-red-500/15 text-red-400 border-red-500/25" },
};

const emptyForm = {
  order_number: "", supplier_name: "", item_name: "", category: "solar_panel",
  quantity: "", unit_cost: "", order_date: new Date().toISOString().slice(0, 10),
  expected_date: "", status: "ordered", shipment_mode: "sea",
  tracking_number: "", carrier: "", notes: "",
};

export default function Iibsashada() {
  const { t } = useT();
  const { toast } = useToast();
  const [orders, setOrders] = useState([]);
  const [vendors, setVendors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyForm);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [o, v] = await Promise.all([
        base44.entities.PurchaseOrder.list("-order_date", 300),
        base44.entities.Vendor.list("name", 200),
      ]);
      setOrders(o);
      setVendors(v);
    } catch {
      toast({ variant: "destructive", title: t("common.error"), description: t("proc.toast.loadError") });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  const openCreate = () => { setEditing(null); setForm(emptyForm); setModalOpen(true); };
  const openEdit = (o) => {
    setEditing(o);
    setForm({
      order_number: o.order_number ?? "", supplier_name: o.supplier_name ?? "", item_name: o.item_name ?? "",
      category: o.category ?? "solar_panel", quantity: o.quantity ?? "", unit_cost: o.unit_cost ?? "",
      order_date: o.order_date?.slice(0, 10) ?? "", expected_date: o.expected_date?.slice(0, 10) ?? "",
      status: o.status ?? "ordered", shipment_mode: o.shipment_mode ?? "sea",
      tracking_number: o.tracking_number ?? "", carrier: o.carrier ?? "", notes: o.notes ?? "",
    });
    setModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const qty = Number(form.quantity) || 0;
    const unit = Number(form.unit_cost) || 0;
    const payload = {
      ...form,
      quantity: qty || undefined,
      unit_cost: unit || undefined,
      total_cost: qty && unit ? qty * unit : undefined,
    };
    try {
      if (editing) {
        await base44.entities.PurchaseOrder.update(editing.id, payload);
        toast({ title: t("proc.toast.updated") });
      } else {
        await base44.entities.PurchaseOrder.create(payload);
        toast({ title: t("proc.toast.created") });
      }
      setModalOpen(false);
      fetchData();
    } catch {
      toast({ variant: "destructive", title: t("common.error"), description: t("proc.toast.saveError") });
    }
  };

  const handleDelete = async (o) => {
    if (!confirm(t("proc.confirmDelete"))) return;
    try {
      await base44.entities.PurchaseOrder.delete(o.id);
      toast({ title: t("proc.toast.deleted") });
      fetchData();
    } catch {
      toast({ variant: "destructive", title: t("common.error"), description: t("proc.toast.deleteError") });
    }
  };

  const totalValue = orders.reduce((s, o) => s + (o.total_cost || 0), 0);
  const inTransit = orders.filter((o) => ["ordered", "in_transit", "customs"].includes(o.status));
  const delivered = orders.filter((o) => o.status === "delivered").length;

  const filtered = filter === "all" ? orders : orders.filter((o) => o.status === filter);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">{t("proc.title")}</h1>
          <p className="text-zinc-400 text-sm mt-1">{t("proc.sub")}</p>
        </div>
        <Button onClick={openCreate} className="gap-2 bg-amber-500 hover:bg-amber-600 text-black font-semibold">
          <Plus className="w-4 h-4" /> {t("proc.new")}
        </Button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatBox label={t("proc.stat.total")} value={orders.length} icon={ShoppingCart} color="text-blue-400" />
        <StatBox label={t("proc.stat.inTransit")} value={inTransit.length} icon={Ship} color="text-amber-400" />
        <StatBox label={t("proc.stat.delivered")} value={delivered} icon={PackageCheck} color="text-emerald-400" />
        <StatBox label={t("proc.stat.value")} value={`$${totalValue.toLocaleString()}`} icon={DollarSign} color="text-purple-400" />
      </div>

      {inTransit.length > 0 && (
        <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-5">
          <h2 className="text-white font-semibold mb-1 flex items-center gap-2">
            <Truck className="w-4 h-4 text-amber-400" /> {t("proc.track.title")}
          </h2>
          <p className="text-zinc-500 text-xs mb-4">{t("proc.track.count", { count: inTransit.length })}</p>
          <div className="space-y-2">
            {inTransit.map((o) => (
              <div key={o.id} className="flex flex-wrap items-center gap-3 rounded-xl bg-zinc-800/40 border border-zinc-800 px-4 py-3">
                <span className="text-white text-sm font-medium">{o.item_name}</span>
                <span className="text-zinc-500 text-xs">×{o.quantity ?? "—"}</span>
                <span className="text-zinc-400 text-xs">{o.supplier_name || "—"}</span>
                <span className="ml-auto flex items-center gap-3">
                  {o.tracking_number && <span className="text-zinc-500 text-xs font-mono">{o.tracking_number}</span>}
                  {o.carrier && <span className="text-zinc-400 text-xs">{o.carrier}</span>}
                  {o.expected_date && <span className="text-amber-400 text-xs">ETA {o.expected_date}</span>}
                  <span className={`px-2.5 py-1 rounded-full text-[10px] font-semibold border ${STATUS[o.status]?.cls}`}>
                    {STATUS[o.status] ? t(STATUS[o.status].labelKey) : o.status}
                  </span>
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="flex flex-wrap gap-2">
        {[{ key: "all", labelKey: "proc.filter.all" }, ...Object.entries(STATUS).map(([k, v]) => ({ key: k, labelKey: v.labelKey }))].map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={`px-3.5 py-1.5 rounded-full text-xs font-medium border transition-colors ${
              filter === f.key ? "bg-amber-500 text-black border-amber-500" : "bg-zinc-900/60 text-zinc-400 border-zinc-800 hover:border-zinc-700"
            }`}
          >
            {t(f.labelKey)}
          </button>
        ))}
      </div>

      <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 overflow-hidden">
        {loading ? (
          <div className="py-16 flex items-center justify-center">
            <div className="w-8 h-8 border-4 border-amber-500/30 border-t-amber-500 rounded-full animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="py-16 text-center text-zinc-500">
            <ShoppingCart className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="text-sm">{t("proc.empty")}</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-zinc-800 text-zinc-400 text-xs uppercase tracking-wider">
                  <th className="text-left px-5 py-3 font-medium">{t("proc.col.item")}</th>
                  <th className="text-left px-5 py-3 font-medium">{t("proc.col.supplier")}</th>
                  <th className="text-right px-5 py-3 font-medium">{t("proc.col.qty")}</th>
                  <th className="text-right px-5 py-3 font-medium">{t("proc.col.total")}</th>
                  <th className="text-left px-5 py-3 font-medium">{t("proc.col.orderDate")}</th>
                  <th className="text-left px-5 py-3 font-medium">{t("proc.col.expected")}</th>
                  <th className="text-left px-5 py-3 font-medium">{t("proc.col.status")}</th>
                  <th className="text-right px-5 py-3 font-medium">{t("proc.col.action")}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/50">
                {filtered.map((o) => (
                  <tr key={o.id} className="hover:bg-zinc-900/50 transition-colors">
                    <td className="px-5 py-3">
                      <p className="text-white font-medium">{o.item_name}</p>
                      <p className="text-zinc-500 text-xs">{CATEGORIES.find((c) => c.value === o.category) ? t(CATEGORIES.find((c) => c.value === o.category).labelKey) : o.category}</p>
                    </td>
                    <td className="px-5 py-3 text-zinc-400">{o.supplier_name || "—"}</td>
                    <td className="px-5 py-3 text-right text-zinc-300">{o.quantity ?? "—"}</td>
                    <td className="px-5 py-3 text-right text-zinc-300">{o.total_cost != null ? `$${o.total_cost.toLocaleString()}` : "—"}</td>
                    <td className="px-5 py-3 text-zinc-400">{o.order_date || "—"}</td>
                    <td className="px-5 py-3 text-zinc-400">{o.expected_date || "—"}</td>
                    <td className="px-5 py-3">
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-semibold border ${STATUS[o.status]?.cls}`}>
                        {STATUS[o.status] ? t(STATUS[o.status].labelKey) : o.status}
                      </span>
                    </td>
                    <td className="px-5 py-3 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Button variant="ghost" size="icon" onClick={() => openEdit(o)} className="h-8 w-8 text-zinc-400 hover:text-amber-400">
                          <Pencil className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleDelete(o)} className="h-8 w-8 text-zinc-400 hover:text-red-400">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="max-w-2xl bg-zinc-900 border-zinc-800 text-white max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? t("proc.edit.title") : t("proc.new")}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>{t("proc.form.item")}</Label>
                <Input required value={form.item_name} onChange={(e) => setForm({ ...form, item_name: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" placeholder="T.c. Panel 550W" />
              </div>
              <div className="space-y-2">
                <Label>{t("proc.form.category")}</Label>
                <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
                  <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-zinc-900 border-zinc-800">
                    {CATEGORIES.map((c) => <SelectItem key={c.value} value={c.value}>{t(c.labelKey)}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>{t("proc.form.supplier")}</Label>
                <Select value={form.supplier_name} onValueChange={(v) => setForm({ ...form, supplier_name: v })}>
                  <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white"><SelectValue placeholder={t("proc.form.supplierPlaceholder")} /></SelectTrigger>
                  <SelectContent className="bg-zinc-900 border-zinc-800">
                    {vendors.map((v) => <SelectItem key={v.id} value={v.name}>{v.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>{t("proc.form.orderNumber")}</Label>
                <Input value={form.order_number} onChange={(e) => setForm({ ...form, order_number: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" placeholder="PO-2026-001" />
              </div>
              <div className="space-y-2">
                <Label>{t("proc.form.qty")}</Label>
                <Input type="number" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" />
              </div>
              <div className="space-y-2">
                <Label>{t("proc.form.unitCost")}</Label>
                <Input type="number" step="0.01" value={form.unit_cost} onChange={(e) => setForm({ ...form, unit_cost: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" />
              </div>
              <div className="space-y-2">
                <Label>{t("proc.form.orderDate")}</Label>
                <Input type="date" value={form.order_date} onChange={(e) => setForm({ ...form, order_date: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" />
              </div>
              <div className="space-y-2">
                <Label>{t("proc.form.expectedDate")}</Label>
                <Input type="date" value={form.expected_date} onChange={(e) => setForm({ ...form, expected_date: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" />
              </div>
              <div className="space-y-2">
                <Label>{t("proc.form.status")}</Label>
                <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                  <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-zinc-900 border-zinc-800">
                    {Object.entries(STATUS).map(([k, v]) => <SelectItem key={k} value={k}>{t(v.labelKey)}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>{t("proc.form.mode")}</Label>
                <Select value={form.shipment_mode} onValueChange={(v) => setForm({ ...form, shipment_mode: v })}>
                  <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-zinc-900 border-zinc-800">
                    {MODES.map((m) => <SelectItem key={m.value} value={m.value}>{t(m.labelKey)}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>{t("proc.form.tracking")}</Label>
                <Input value={form.tracking_number} onChange={(e) => setForm({ ...form, tracking_number: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" placeholder="MSCU1234567" />
              </div>
              <div className="space-y-2">
                <Label>{t("proc.form.carrier")}</Label>
                <Input value={form.carrier} onChange={(e) => setForm({ ...form, carrier: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" />
              </div>
              <div className="col-span-2 space-y-2">
                <Label>{t("proc.form.notes")}</Label>
                <Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" rows={2} />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setModalOpen(false)} className="border-zinc-700 text-zinc-300 hover:bg-zinc-800">{t("proc.cancel")}</Button>
              <Button type="submit" className="bg-amber-500 hover:bg-amber-600 text-black font-semibold">{editing ? t("proc.update") : t("proc.create")}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function StatBox({ label, value, icon: Icon, color }) {
  return (
    <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-4">
      <div className="flex items-center justify-between mb-2">
        <p className="text-zinc-500 text-[11px] font-medium uppercase tracking-wider">{label}</p>
        <Icon className={`w-4 h-4 ${color}`} />
      </div>
      <p className={`text-xl font-bold ${color}`}>{value}</p>
    </div>
  );
}