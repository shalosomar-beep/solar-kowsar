import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Activity, TrendingDown, Zap, Gauge, AlertTriangle, DollarSign } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { useT } from "@/lib/i18n";

export default function LumitaankaTamarta() {
  const { t } = useT();
  const [items, setItems] = useState([]);
  const [rate, setRate] = useState(0);
  const [loading, setLoading] = useState(true);
  const [locFilter, setLocFilter] = useState("all");

  useEffect(() => {
    Promise.all([
      base44.entities.SolarData.list("-usage_date", 300),
      base44.entities.Settings.list().catch(() => []),
    ])
      .then(([data, settings]) => {
        setItems(data);
        if (settings && settings[0]?.rate_per_kwh) setRate(Number(settings[0].rate_per_kwh) || 0);
      })
      .finally(() => setLoading(false));
  }, []);

  const locations = [...new Set(items.map((i) => i.location).filter(Boolean))];
  const scoped = locFilter === "all" ? items : items.filter((i) => i.location === locFilter);

  const totalProduction = scoped.reduce((s, i) => s + (i.production_kwh || 0), 0);
  const totalConsumption = scoped.reduce((s, i) => s + (i.consumption_kwh || 0), 0);
  const totalLoss = Math.max(0, totalProduction - totalConsumption);
  const lossPct = totalProduction > 0 ? (totalLoss / totalProduction) * 100 : 0;
  const withEff = scoped.filter((i) => typeof i.efficiency === "number");
  const avgEff = withEff.length ? withEff.reduce((s, i) => s + i.efficiency, 0) / withEff.length : 0;
  const lossValue = totalLoss * rate;

  const byLoc = {};
  scoped.forEach((i) => {
    const k = i.location || "—";
    if (!byLoc[k]) byLoc[k] = { prod: 0, cons: 0, effSum: 0, effN: 0 };
    byLoc[k].prod += i.production_kwh || 0;
    byLoc[k].cons += i.consumption_kwh || 0;
    if (typeof i.efficiency === "number") {
      byLoc[k].effSum += i.efficiency;
      byLoc[k].effN += 1;
    }
  });
  const locRows = Object.entries(byLoc)
    .map(([name, v]) => {
      const loss = Math.max(0, v.prod - v.cons);
      return {
        name,
        prod: v.prod,
        cons: v.cons,
        loss,
        lossPct: v.prod > 0 ? (loss / v.prod) * 100 : 0,
        eff: v.effN ? v.effSum / v.effN : null,
      };
    })
    .sort((a, b) => b.lossPct - a.lossPct);

  const highLoss = locRows.filter((r) => r.lossPct > 15);

  const chartData = [...scoped]
    .filter((i) => i.usage_date)
    .sort((a, b) => new Date(a.usage_date) - new Date(b.usage_date))
    .slice(-30)
    .map((i) => ({
      date: i.usage_date?.slice(5),
      production: i.production_kwh || 0,
      consumption: i.consumption_kwh || 0,
      loss: Math.max(0, (i.production_kwh || 0) - (i.consumption_kwh || 0)),
    }));

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">{t("loss.title")}</h1>
          <p className="text-zinc-400 text-sm mt-1">{t("loss.subtitle")}</p>
        </div>
        <Select value={locFilter} onValueChange={setLocFilter}>
          <SelectTrigger className="w-52 bg-zinc-900 border-zinc-800 text-white"><SelectValue /></SelectTrigger>
          <SelectContent className="bg-zinc-900 border-zinc-800">
            <SelectItem value="all">{t("loss.filter.all")}</SelectItem>
            {locations.map((l) => <SelectItem key={l} value={l}>{l}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatBox label={t("loss.production")} value={`${totalProduction.toLocaleString()} kWh`} icon={Zap} color="text-amber-400" bg="from-amber-500/10 to-amber-600/5 border-amber-500/15" />
        <StatBox label={t("loss.consumption")} value={`${totalConsumption.toLocaleString()} kWh`} icon={Activity} color="text-cyan-400" bg="from-cyan-500/10 to-cyan-600/5 border-cyan-500/15" />
        <StatBox label={t("loss.lost")} value={`${totalLoss.toLocaleString()} kWh`} icon={TrendingDown} color="text-red-400" bg="from-red-500/10 to-red-600/5 border-red-500/15" sub={t("loss.lossPct", { pct: lossPct.toFixed(1) })} />
        <StatBox label={t("loss.avgEfficiency")} value={`${avgEff.toFixed(1)}%`} icon={Gauge} color="text-emerald-400" bg="from-emerald-500/10 to-emerald-600/5 border-emerald-500/15" />
      </div>

      {rate > 0 && (
        <div className="rounded-2xl bg-gradient-to-br from-red-500/10 to-red-600/5 border border-red-500/15 p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-500/15 flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-red-400" />
            </div>
            <div>
              <p className="text-zinc-400 text-xs font-medium uppercase tracking-wider">{t("loss.cost.title")}</p>
              <p className="text-zinc-500 text-xs mt-0.5">{t("loss.cost.sub", { rate })}</p>
            </div>
          </div>
          <p className="text-2xl font-bold text-red-400">${lossValue.toLocaleString(undefined, { maximumFractionDigits: 2 })}</p>
        </div>
      )}

      {highLoss.length > 0 && (
        <div className="rounded-2xl bg-amber-500/10 border border-amber-500/20 p-5">
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            <h2 className="text-amber-300 font-semibold text-sm">{t("loss.highZones")}</h2>
          </div>
          <div className="flex flex-wrap gap-2">
            {highLoss.map((r) => (
              <span key={r.name} className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-zinc-900/70 border border-amber-500/20 text-sm">
                <span className="text-white">{r.name}</span>
                <span className="text-amber-400 font-semibold">{r.lossPct.toFixed(1)}%</span>
              </span>
            ))}
          </div>
        </div>
      )}

      {loading ? (
        <div className="py-20 flex items-center justify-center">
          <div className="w-8 h-8 border-4 border-amber-500/30 border-t-amber-500 rounded-full animate-spin" />
        </div>
      ) : (
        <>
          <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-5">
            <h2 className="text-white font-semibold mb-1">{t("loss.chart.title")}</h2>
            <p className="text-zinc-500 text-xs mb-4">{t("loss.chart.sub")}</p>
            {chartData.length > 0 ? (
              <div style={{ width: "100%", height: 300 }}>
                <ResponsiveContainer>
                  <LineChart data={chartData} margin={{ top: 4, right: 8, left: -12, bottom: 4 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                    <XAxis dataKey="date" tick={{ fill: "#a1a1aa", fontSize: 11 }} axisLine={{ stroke: "#3f3f46" }} tickLine={false} />
                    <YAxis tick={{ fill: "#a1a1aa", fontSize: 11 }} axisLine={false} tickLine={false} />
                    <Tooltip contentStyle={{ background: "#18181b", border: "1px solid #3f3f46", borderRadius: 12, color: "#fff" }} />
                    <Legend wrapperStyle={{ fontSize: 12 }} />
                    <Line type="monotone" dataKey="production" name={t("loss.series.production")} stroke="#f59e0b" strokeWidth={2} dot={false} />
                    <Line type="monotone" dataKey="consumption" name={t("loss.series.consumption")} stroke="#06b6d4" strokeWidth={2} dot={false} />
                    <Line type="monotone" dataKey="loss" name={t("loss.series.loss")} stroke="#ef4444" strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-64 flex items-center justify-center text-zinc-600 text-sm">{t("loss.empty")}</div>
            )}
          </div>

          <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 overflow-hidden">
            <div className="p-5 border-b border-zinc-800">
              <h2 className="text-white font-semibold">{t("loss.byLocation.title")}</h2>
              <p className="text-zinc-500 text-xs mt-1">{t("loss.byLocation.sub")}</p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-zinc-800 text-zinc-400 text-xs uppercase tracking-wider">
                    <th className="text-left px-5 py-3 font-medium">{t("loss.col.location")}</th>
                    <th className="text-right px-5 py-3 font-medium">{t("loss.col.production")}</th>
                    <th className="text-right px-5 py-3 font-medium">{t("loss.col.consumption")}</th>
                    <th className="text-right px-5 py-3 font-medium">{t("loss.col.loss")}</th>
                    <th className="text-right px-5 py-3 font-medium">{t("loss.col.lossPct")}</th>
                    <th className="text-right px-5 py-3 font-medium">{t("loss.col.efficiency")}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800/50">
                  {locRows.length === 0 ? (
                    <tr><td colSpan={6} className="px-5 py-12 text-center text-zinc-500">{t("loss.empty")}</td></tr>
                  ) : (
                    locRows.map((r) => (
                      <tr key={r.name} className="hover:bg-zinc-900/50 transition-colors">
                        <td className="px-5 py-3 text-white font-medium">{r.name}</td>
                        <td className="px-5 py-3 text-right text-amber-400">{r.prod.toLocaleString()}</td>
                        <td className="px-5 py-3 text-right text-cyan-400">{r.cons.toLocaleString()}</td>
                        <td className="px-5 py-3 text-right text-zinc-300">{r.loss.toLocaleString()}</td>
                        <td className={`px-5 py-3 text-right font-semibold ${r.lossPct > 15 ? "text-red-400" : r.lossPct > 8 ? "text-amber-400" : "text-emerald-400"}`}>
                          {r.lossPct.toFixed(1)}%
                        </td>
                        <td className="px-5 py-3 text-right text-zinc-300">{r.eff != null ? `${r.eff.toFixed(1)}%` : "—"}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function StatBox({ label, value, icon: Icon, color, bg, sub }) {
  return (
    <div className={`rounded-2xl bg-gradient-to-br border p-5 ${bg}`}>
      <div className="flex items-center justify-between mb-3">
        <p className="text-zinc-400 text-xs font-medium uppercase tracking-wider">{label}</p>
        <Icon className={`w-4 h-4 ${color}`} />
      </div>
      <p className={`text-2xl font-bold ${color}`}>{value}</p>
      {sub && <p className="text-zinc-500 text-xs mt-1">{sub}</p>}
    </div>
  );
}