import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useT } from "@/lib/i18n";
import { Calendar, Plus } from "lucide-react";
import DataErrorState from "@/components/common/DataErrorState";
import SummaryCards from "@/components/revenue-dashboard/SummaryCards";
import MonthlyRevenueChart from "@/components/revenue-dashboard/MonthlyRevenueChart";
import CustomerConsumptionTable from "@/components/revenue-dashboard/CustomerConsumptionTable";
import ProductionVsSoldChart from "@/components/revenue-dashboard/ProductionVsSoldChart";

const round2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const keyOf = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;

export default function DashboardDakhliga() {
  const { t, lang } = useT();
  const [customers, setCustomers] = useState([]);
  const [billings, setBillings] = useState([]);
  const [dailyUsages, setDailyUsages] = useState([]);
  const [solarData, setSolarData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const load = () => {
    setLoading(true);
    setError(false);
    Promise.all([
      base44.entities.Customer.list(),
      base44.entities.Billing.list(),
      base44.entities.DailyUsage.list(),
      base44.entities.SolarData.list("-usage_date", 500),
    ])
      .then(([c, b, u, sd]) => {
        setCustomers(c);
        setBillings(b);
        setDailyUsages(u);
        setSolarData(sd);
      })
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-amber-500/30 border-t-amber-500 rounded-full animate-spin" />
      </div>
    );
  }

  if (error) return <DataErrorState onRetry={load} />;

  const locale = lang === "so" ? "en" : lang;
  const labelOf = (key) => {
    const [y, m] = key.split("-").map(Number);
    return new Date(y, m - 1, 1).toLocaleDateString(locale, { month: "short", year: "2-digit" });
  };

  // ---- last six months as chart buckets ----
  const buckets = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date();
    d.setMonth(d.getMonth() - i);
    buckets.push(keyOf(d));
  }

  // Show the most recent month that has meter or solar activity, so the figures are
  // never blank just because nothing has been recorded yet this calendar month.
  // Months that only carry bills are used as a fallback.
  const monthsOf = (rows, pick) => rows.map(pick).filter(Boolean).sort();
  const operationalMonths = monthsOf([...dailyUsages, ...solarData], (r) =>
    (r.usage_date || "").slice(0, 7)
  );
  const billedMonths = monthsOf(billings, (b) => (b.billing_month || "").slice(0, 7));
  const activeKey =
    operationalMonths[operationalMonths.length - 1] ||
    billedMonths[billedMonths.length - 1] ||
    keyOf(new Date());

  // ---- monthly series ----
  const revenueSeries = buckets.map((key) => {
    const bills = billings.filter((b) => (b.billing_month || "").startsWith(key));
    const billed = bills.reduce((s, b) => s + (Number(b.total_amount) || 0), 0);
    const collected = bills
      .filter((b) => b.status === "paid")
      .reduce((s, b) => s + (Number(b.total_amount) || 0), 0);
    return { name: labelOf(key), billed: round2(billed), collected: round2(collected) };
  });

  const energySeries = buckets.map((key) => {
    const sold = billings
      .filter((b) => (b.billing_month || "").startsWith(key))
      .reduce((s, b) => s + (Number(b.kwh_used) || 0), 0);
    const produced = solarData
      .filter((s) => (s.usage_date || "").startsWith(key))
      .reduce((sum, s) => sum + (Number(s.production_kwh) || 0), 0);
    return { name: labelOf(key), produced: round2(produced), sold: round2(sold) };
  });

  // ---- figures for the active month ----
  const activeBills = billings.filter((b) => (b.billing_month || "").startsWith(activeKey));
  const activeUsages = dailyUsages.filter((u) => (u.usage_date || "").startsWith(activeKey));

  const billed = activeBills.reduce((s, b) => s + (Number(b.total_amount) || 0), 0);
  const collected = activeBills
    .filter((b) => b.status === "paid")
    .reduce((s, b) => s + (Number(b.total_amount) || 0), 0);

  const usageFromReadings = activeUsages.reduce((s, u) => s + (Number(u.kwh_used) || 0), 0);
  const usageFromBills = activeBills.reduce((s, b) => s + (Number(b.kwh_used) || 0), 0);
  const usageTotal = usageFromReadings || usageFromBills;
  const usageEstimated = activeUsages
    .filter((u) => u.reading_type === "estimated")
    .reduce((s, u) => s + (Number(u.kwh_used) || 0), 0);
  const readingDays = new Set(activeUsages.map((u) => u.usage_date).filter(Boolean)).size;

  const produced = solarData
    .filter((s) => (s.usage_date || "").startsWith(activeKey))
    .reduce((sum, s) => sum + (Number(s.production_kwh) || 0), 0);
  const sold = usageFromBills;

  const revenue = {
    billed: round2(billed),
    collected: round2(collected),
    pending: round2(Math.max(0, billed - collected)),
    rate: billed > 0 ? (collected / billed) * 100 : 0,
  };

  const consumption = {
    total: round2(usageTotal),
    estimated: round2(usageEstimated),
    dailyAvg: readingDays > 0 ? round2(usageTotal / readingDays) : 0,
    customers: customers.filter((c) => activeUsages.some((u) => u.customer === c.id)).length,
  };

  const energy = {
    produced: round2(produced),
    sold: round2(sold),
    coverage: produced > 0 ? (sold / produced) * 100 : 0,
    diff: round2(produced - sold),
  };

  // ---- per-customer consumption estimate for the active month ----
  const [ay, am] = activeKey.split("-").map(Number);
  const daysInMonth = new Date(ay, am, 0).getDate();

  const customerRows = customers
    .map((c) => {
      const usages = activeUsages.filter((u) => u.customer === c.id);
      const used = usages.reduce((s, u) => s + (Number(u.kwh_used) || 0), 0);
      const bill = activeBills.find((b) => b.customer === c.id);
      const kwh = used || (Number(bill?.kwh_used) || 0);
      const hasReading = usages.length > 0;
      const estimated = hasReading && usages.every((u) => u.reading_type === "estimated");
      // Project the month from the daily pace once at least one reading exists.
      const projected = used > 0 && readingDays > 0 ? (used / readingDays) * daysInMonth : kwh;
      return { id: c.id, name: c.full_name, kwh: round2(kwh), projected: round2(projected), hasReading, estimated };
    })
    .filter((r) => r.kwh > 0)
    .sort((a, b) => b.kwh - a.kwh);

  const hasAnyData = billings.length > 0 || dailyUsages.length > 0 || solarData.length > 0;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-foreground">{t("revdash.title")}</h1>
          <p className="text-muted-foreground text-sm mt-1">{t("revdash.subtitle")}</p>
        </div>
        <div className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-card border border-border text-sm text-muted-foreground whitespace-nowrap">
          <Calendar className="w-4 h-4 text-orange-400" />
          {t("revdash.month")}: <span className="text-foreground font-semibold">{labelOf(activeKey)}</span>
        </div>
      </div>

      {!hasAnyData ? (
        <div className="rounded-2xl bg-card border border-border py-16 text-center">
          <Plus className="w-12 h-12 mx-auto mb-3 text-muted-foreground opacity-30" />
          <p className="text-foreground font-semibold">{t("revdash.empty")}</p>
          <p className="text-muted-foreground text-sm mt-1 mb-5">{t("revdash.empty.sub")}</p>
          <Link
            to="/isticmaalka"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-black text-sm font-semibold transition-colors"
          >
            <Plus className="w-4 h-4" />
            {t("revdash.empty.cta")}
          </Link>
        </div>
      ) : (
        <>
          <SummaryCards revenue={revenue} consumption={consumption} energy={energy} />
          <MonthlyRevenueChart data={revenueSeries} />
          <CustomerConsumptionTable rows={customerRows} />
          <ProductionVsSoldChart data={energySeries} />
        </>
      )}
    </div>
  );
}