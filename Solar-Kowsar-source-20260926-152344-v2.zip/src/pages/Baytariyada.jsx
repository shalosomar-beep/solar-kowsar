import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Battery, BatteryWarning, Search, Thermometer, Activity, CheckCircle2 } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { STATUS_META } from "@/components/equipment/EquipmentCard";

function socColor(v) {
  if (v == null) return "#71717a";
  if (v <= 25) return "#ef4444";
  if (v <= 40) return "#f59e0b";
  return "#22c55e";
}

function healthColor(v) {
  if (v == null) return "text-zinc-400";
  if (v <= 50) return "text-red-400";
  if (v <= 60) return "text-amber-400";
  return "text-emerald-400";
}

export default function Baytariyada() {
  const { toast } = useToast();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");

  const fetch = async () => {
    try {
      setLoading(true);
      const data = await base44.entities.Equipment.filter({ category: "battery" }, "-created_date", 200);
      setItems(data);
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Baytariyada lama keeni karo" });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetch(); }, []);

  const withSoc = items.filter((i) => typeof i.battery_level === "number");
  const avgSoc = withSoc.length ? Math.round(withSoc.reduce((s, i) => s + i.battery_level, 0) / withSoc.length) : 0;
  const withHealth = items.filter((i) => typeof i.health === "number");
  const avgHealth = withHealth.length ? Math.round(withHealth.reduce((s, i) => s + i.health, 0) / withHealth.length) : 0;
  const lowCount = items.filter(
    (i) =>
      (typeof i.battery_level === "number" && i.battery_level <= 40) ||
      (typeof i.health === "number" && i.health <= 60)
  ).length;

  const chartData = items.slice(0, 12).map((i) => ({
    name: i.name?.length > 14 ? `${i.name.slice(0, 14)}…` : i.name,
    soc: i.battery_level ?? 0,
    color: socColor(i.battery_level),
  }));

  const filtered = items.filter((i) => {
    const q = search.toLowerCase();
    const matchQ =
      !q ||
      i.name?.toLowerCase().includes(q) ||
      i.location?.toLowerCase().includes(q) ||
      i.serial_number?.toLowerCase().includes(q);
    const matchStatus = filterStatus === "all" || i.status === filterStatus;
    return matchQ && matchStatus;
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Kaydka Tamarta (Baytariyada)</h1>
        <p className="text-zinc-400 text-sm mt-1">Kormeer heerka batteriga (SoC%) iyo caafimaadka kaydka tamarta</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatBox label="Baytariyada" value={items.length} icon={Battery} color="text-blue-400" bg="from-blue-500/10 to-blue-600/5 border-blue-500/15" />
        <StatBox label="Celceliska SoC" value={`${avgSoc}%`} icon={Activity} color="text-emerald-400" bg="from-emerald-500/10 to-emerald-600/5 border-emerald-500/15" />
        <StatBox label="Celceliska Caafimaadka" value={`${avgHealth}%`} icon={CheckCircle2} color="text-purple-400" bg="from-purple-500/10 to-purple-600/5 border-purple-500/15" />
        <StatBox label="Digniin Hoose" value={lowCount} icon={BatteryWarning} color="text-amber-400" bg="from-amber-500/10 to-amber-600/5 border-amber-500/15" />
      </div>

      {chartData.length > 0 && (
        <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-5">
          <h2 className="text-white font-semibold mb-1">Heerka Battery-da (SoC%)</h2>
          <p className="text-zinc-500 text-xs mb-4">Heerka kasta oo batteri</p>
          <div style={{ width: "100%", height: 260 }}>
            <ResponsiveContainer>
              <BarChart data={chartData} margin={{ top: 4, right: 8, left: -18, bottom: 4 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                <XAxis dataKey="name" tick={{ fill: "#a1a1aa", fontSize: 11 }} axisLine={{ stroke: "#3f3f46" }} tickLine={false} />
                <YAxis domain={[0, 100]} tick={{ fill: "#a1a1aa", fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ background: "#18181b", border: "1px solid #3f3f46", borderRadius: 12, color: "#fff" }}
                  formatter={(v) => [`${v}%`, "SoC"]}
                />
                <Bar dataKey="soc" radius={[6, 6, 0, 0]}>
                  {chartData.map((d, i) => (
                    <Cell key={i} fill={d.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
          <Input
            placeholder="Raadi batteri, goob ama siiraad..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 bg-zinc-900 border-zinc-800 text-white placeholder:text-zinc-600"
          />
        </div>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-44 bg-zinc-900 border-zinc-800 text-white"><SelectValue /></SelectTrigger>
          <SelectContent className="bg-zinc-900 border-zinc-800">
            <SelectItem value="all">Dhammaan</SelectItem>
            <SelectItem value="online">Online</SelectItem>
            <SelectItem value="warning">Digniin</SelectItem>
            <SelectItem value="offline">Offline</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="py-20 flex items-center justify-center">
          <div className="w-8 h-8 border-4 border-orange-500/30 border-t-orange-500 rounded-full animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="py-20 text-center text-zinc-500">
          <Battery className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p className="text-sm">Batteri lama helin. Kudar qalab nooca Battery-ga ah bogga Qalabka.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((i) => {
            const status = STATUS_META[i.status] || STATUS_META.online;
            const soc = i.battery_level;
            return (
              <div key={i.id} className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-5 hover:border-zinc-700 transition-colors">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 bg-amber-500/10 text-amber-400">
                      <Battery className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <h3 className="text-white font-semibold text-sm truncate">{i.name}</h3>
                      <p className="text-zinc-500 text-xs mt-0.5 truncate">{i.location}</p>
                    </div>
                  </div>
                  <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${status.bg} ${status.text} shrink-0`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${status.dot}`} />
                    {status.label}
                  </span>
                </div>

                <div className="space-y-3">
                  <div>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="text-zinc-500">Heerka (SoC)</span>
                      <span className="font-semibold text-white">{soc != null ? `${soc}%` : "—"}</span>
                    </div>
                    <div className="h-2 bg-zinc-800 rounded-full overflow-hidden">
                      <div className="h-full rounded-full transition-all" style={{ width: `${soc ?? 0}%`, background: socColor(soc) }} />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="text-zinc-500">Caafimaadka</span>
                      <span className={`font-semibold ${healthColor(i.health)}`}>{i.health != null ? `${i.health}%` : "—"}</span>
                    </div>
                    <div className="h-2 bg-zinc-800 rounded-full overflow-hidden">
                      <div className="h-full rounded-full transition-all bg-current" style={{ width: `${i.health ?? 0}%` }} />
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-sm pt-1">
                    <span className="text-zinc-500 flex items-center gap-1.5"><Thermometer className="w-3.5 h-3.5" /> Kulka</span>
                    <span className={`font-medium ${i.temperature >= 50 ? "text-red-400" : "text-zinc-200"}`}>
                      {i.temperature != null ? `${i.temperature}°C` : "—"}
                    </span>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-zinc-800/60">
                  <span className="text-zinc-500 text-xs font-mono">{i.serial_number}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function StatBox({ label, value, icon: Icon, color, bg }) {
  return (
    <div className={`rounded-2xl bg-gradient-to-br border p-5 ${bg}`}>
      <div className="flex items-center justify-between mb-3">
        <p className="text-zinc-400 text-xs font-medium uppercase tracking-wider">{label}</p>
        <Icon className={`w-4 h-4 ${color}`} />
      </div>
      <p className={`text-2xl font-bold ${color}`}>{value}</p>
    </div>
  );
}