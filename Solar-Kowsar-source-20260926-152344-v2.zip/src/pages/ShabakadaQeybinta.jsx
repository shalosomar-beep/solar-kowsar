import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Network, Plus, Pencil, Trash2, Zap, AlertTriangle, Gauge, Building2 } from "lucide-react";
import TransformerDialog from "@/components/grid/TransformerDialog";
import SubstationDialog from "@/components/grid/SubstationDialog";

const loadPct = (t) => (t.capacity_kva > 0 && t.current_load_kw != null ? (t.current_load_kw / t.capacity_kva) * 100 : 0);
const loadColor = (p) => (p >= 85 ? "#ef4444" : p >= 60 ? "#f59e0b" : "#10b981");

export default function ShabakadaQeybinta() {
  const { toast } = useToast();
  const [tab, setTab] = useState("transformers");
  const [transformers, setTransformers] = useState([]);
  const [substations, setSubstations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [trOpen, setTrOpen] = useState(false);
  const [subOpen, setSubOpen] = useState(false);
  const [editingTr, setEditingTr] = useState(null);
  const [editingSub, setEditingSub] = useState(null);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [tr, sub] = await Promise.all([
        base44.entities.Transformer.list("name", 300),
        base44.entities.Substation.list("name", 200),
      ]);
      setTransformers(tr);
      setSubstations(sub);
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Xogta shabakada lama keeni karin" });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  const subName = (id) => substations.find((s) => s.id === id)?.name || "—";

  const overloaded = transformers.filter((t) => t.status === "overloaded" || loadPct(t) >= 85);
  const warning = transformers.filter((t) => t.status === "warning");
  const totalCapacity = transformers.reduce((s, t) => s + (t.capacity_kva || 0), 0);
  const totalLoad = transformers.reduce((s, t) => s + (t.current_load_kw || 0), 0);

  const deleteTr = async (t) => {
    if (!confirm("Ma hubtaa inaad tirtirto transformer-kan?")) return;
    try { await base44.entities.Transformer.delete(t.id); toast({ title: "Waa la tirtiray" }); fetchData(); }
    catch { toast({ variant: "destructive", title: "Khalad", description: "Lama tirtiri karo" }); }
  };
  const deleteSub = async (s) => {
    if (!confirm("Ma hubtaa inaad tirtirto xaruntan?")) return;
    try { await base44.entities.Substation.delete(s.id); toast({ title: "Waa la tirtiray" }); fetchData(); }
    catch { toast({ variant: "destructive", title: "Khalad", description: "Lama tirtiri karo" }); }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Maamulka Shabakada Qeybinta</h1>
          <p className="text-zinc-400 text-sm mt-1">La soco culayska transformer-ka si looga hortago inuu gubto</p>
        </div>
        <Button
          onClick={() => (tab === "transformers" ? (setEditingTr(null), setTrOpen(true)) : (setEditingSub(null), setSubOpen(true)))}
          className="gap-2 bg-amber-500 hover:bg-amber-600 text-black font-semibold"
        >
          <Plus className="w-4 h-4" /> {tab === "transformers" ? "Transformer Cusub" : "Xarun Cusub"}
        </Button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatBox label="Transformer-yada" value={transformers.length} icon={Zap} color="text-blue-400" />
        <StatBox label="Culays Badan" value={overloaded.length} icon={AlertTriangle} color={overloaded.length ? "text-red-400" : "text-zinc-400"} />
        <StatBox label="Awoodda Guud" value={`${totalCapacity} kVA`} icon={Gauge} color="text-purple-400" />
        <StatBox label="Culayska Hadda" value={`${totalLoad} kW`} icon={Network} color="text-amber-400" />
      </div>

      {overloaded.length > 0 && (
        <div className="rounded-2xl bg-red-500/10 border border-red-500/25 p-5">
          <p className="text-red-400 font-semibold text-sm flex items-center gap-2">
            <AlertTriangle className="w-4 h-4" /> Digniin: {overloaded.length} transformer ayaa culays badan saaran yahay
          </p>
          <p className="text-zinc-400 text-xs mt-1">
            {overloaded.map((t) => `${t.name} (${loadPct(t).toFixed(0)}%)`).join(" · ")} — khatar gubasho ayaa jirta, fadlan yaree culayska.
          </p>
        </div>
      )}

      <div className="flex gap-2">
        {[{ key: "transformers", label: "Transformer-yada" }, { key: "substations", label: "Xarumaha Qeybinta" }].map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`px-4 py-2 rounded-full text-xs font-medium border transition-colors ${
              tab === t.key ? "bg-amber-500 text-black border-amber-500" : "bg-zinc-900/60 text-zinc-400 border-zinc-800 hover:border-zinc-700"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="py-20 flex items-center justify-center">
          <div className="w-8 h-8 border-4 border-amber-500/30 border-t-amber-500 rounded-full animate-spin" />
        </div>
      ) : tab === "transformers" ? (
        transformers.length === 0 ? (
          <Empty icon={Zap} text="Weli transformer lama diiwaangelin" />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {transformers.map((t) => {
              const pct = loadPct(t);
              const color = loadColor(pct);
              return (
                <div key={t.id} className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-5">
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="min-w-0">
                      <h3 className="text-white font-semibold text-sm">{t.name}</h3>
                      <p className="text-zinc-500 text-xs mt-0.5">{subName(t.substation)}{t.location ? ` · ${t.location}` : ""}</p>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <Button variant="ghost" size="icon" onClick={() => { setEditingTr(t); setTrOpen(true); }} className="h-7 w-7 text-zinc-400 hover:text-amber-400">
                        <Pencil className="w-3.5 h-3.5" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => deleteTr(t)} className="h-7 w-7 text-zinc-400 hover:text-red-400">
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </div>

                  <div className="flex items-end justify-between mb-2">
                    <span className="text-zinc-400 text-xs">Culayska</span>
                    <span className="text-lg font-bold" style={{ color }}>{pct.toFixed(0)}%</span>
                  </div>
                  <div className="h-2 rounded-full bg-zinc-800 overflow-hidden">
                    <div className="h-full rounded-full transition-all" style={{ width: `${Math.min(pct, 100)}%`, background: color }} />
                  </div>

                  <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-zinc-800 text-center">
                    <div>
                      <p className="text-zinc-500 text-[10px] uppercase">Awoodda</p>
                      <p className="text-zinc-200 text-xs font-medium">{t.capacity_kva ?? "—"} kVA</p>
                    </div>
                    <div>
                      <p className="text-zinc-500 text-[10px] uppercase">Culays</p>
                      <p className="text-zinc-200 text-xs font-medium">{t.current_load_kw ?? "—"} kW</p>
                    </div>
                    <div>
                      <p className="text-zinc-500 text-[10px] uppercase">Kulka</p>
                      <p className="text-zinc-200 text-xs font-medium">{t.temperature != null ? `${t.temperature}°C` : "—"}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )
      ) : substations.length === 0 ? (
        <Empty icon={Building2} text="Weli xarun qeybineed lama diiwaangelin" />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {substations.map((s) => {
            const count = transformers.filter((t) => t.substation === s.id).length;
            return (
              <div key={s.id} className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-5">
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="min-w-0">
                    <h3 className="text-white font-semibold text-sm">{s.name}</h3>
                    <p className="text-zinc-500 text-xs mt-0.5">{s.city}{s.address ? ` · ${s.address}` : ""}</p>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <Button variant="ghost" size="icon" onClick={() => { setEditingSub(s); setSubOpen(true); }} className="h-7 w-7 text-zinc-400 hover:text-amber-400">
                      <Pencil className="w-3.5 h-3.5" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => deleteSub(s)} className="h-7 w-7 text-zinc-400 hover:text-red-400">
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-2 pt-3 border-t border-zinc-800 text-center">
                  <div>
                    <p className="text-zinc-500 text-[10px] uppercase">Awoodda</p>
                    <p className="text-zinc-200 text-xs font-medium">{s.capacity_kva ?? "—"} kVA</p>
                  </div>
                  <div>
                    <p className="text-zinc-500 text-[10px] uppercase">Transformer</p>
                    <p className="text-zinc-200 text-xs font-medium">{count}</p>
                  </div>
                  <div>
                    <p className="text-zinc-500 text-[10px] uppercase">Xaaladda</p>
                    <p className="text-zinc-200 text-xs font-medium">{s.status}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <TransformerDialog open={trOpen} onOpenChange={setTrOpen} editing={editingTr} substations={substations} onSaved={fetchData} />
      <SubstationDialog open={subOpen} onOpenChange={setSubOpen} editing={editingSub} onSaved={fetchData} />
    </div>
  );
}

function Empty({ icon: Icon, text }) {
  return (
    <div className="py-20 text-center text-zinc-500 rounded-2xl bg-zinc-900/60 border border-zinc-800">
      <Icon className="w-12 h-12 mx-auto mb-3 opacity-30" />
      <p className="text-sm">{text}</p>
    </div>
  );
}

function StatBox({ label, value, icon: Icon, color }) {
  return (
    <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-4">
      <div className="flex items-center justify-between mb-2">
        <p className="text-zinc-500 text-[11px] font-medium uppercase tracking-wider">{label}</p>
        <Icon className={`w-4 h-4 ${color}`} />
      </div>
      <p className={`text-xl font-bold ${color}`}>{value}</p>
    </div>
  );
}