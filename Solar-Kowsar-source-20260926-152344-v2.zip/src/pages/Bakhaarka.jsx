import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { useT } from "@/lib/i18n";
import { useToast } from "@/components/ui/use-toast";
import { Package, AlertTriangle, CheckCircle2, Save, Boxes } from "lucide-react";
import StockItemsPanel from "@/components/warehouse/StockItemsPanel";
import StockAlertsPanel from "@/components/warehouse/StockAlertsPanel";

const CATEGORIES = ["solar_panel", "battery", "inverter", "smart_meter", "generator"];
const DEFAULT_MIN = 2;

export default function Bakhaarka() {
  const { t } = useT();
  const { toast } = useToast();
  const [equipment, setEquipment] = useState([]);
  const [minimums, setMinimums] = useState({});
  const [drafts, setDrafts] = useState({});
  const [loading, setLoading] = useState(true);
  const [savingCat, setSavingCat] = useState(null);

  useEffect(() => {
    load();
  }, []);

  const load = async () => {
    const [eq, mins] = await Promise.all([
      base44.entities.Equipment.list(),
      base44.entities.StockMinimum.list(),
    ]);
    setEquipment(Array.isArray(eq) ? eq : []);
    const map = {};
    (Array.isArray(mins) ? mins : []).forEach((m) => {
      map[m.category] = { id: m.id, min: Number(m.min_quantity) || 0 };
    });
    setMinimums(map);
    setLoading(false);
  };

  const saveMin = async (category) => {
    const raw = drafts[category];
    const value = Number(raw === undefined ? minFor(category) : raw) || 0;
    setSavingCat(category);
    try {
      const existing = minimums[category];
      if (existing?.id) {
        await base44.entities.StockMinimum.update(existing.id, { category, min_quantity: value });
      } else {
        await base44.entities.StockMinimum.create({ category, min_quantity: value });
      }
      await load();
      setDrafts((d) => ({ ...d, [category]: undefined }));
      toast({ title: t("warehouse.saved"), description: t(`equip.${category}`) });
    } finally {
      setSavingCat(null);
    }
  };

  const minFor = (category) => (minimums[category] ? minimums[category].min : DEFAULT_MIN);
  const stockFor = (category) =>
    equipment.filter((e) => e.asset_state === "warehouse" && e.category === category).length;

  const rows = CATEGORIES.map((category) => {
    const stock = stockFor(category);
    const min = minFor(category);
    const status = stock <= 0 ? "critical" : stock < min ? "low" : "ok";
    return { category, stock, min, status };
  });

  const lowRows = rows.filter((r) => r.status !== "ok");
  const warehouseItems = equipment.filter((e) => e.asset_state === "warehouse");

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-4 border-orange-500/30 border-t-orange-500 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start gap-3">
        <div className="w-11 h-11 rounded-xl bg-orange-500/10 border border-orange-500/20 flex items-center justify-center shrink-0">
          <Boxes className="w-5 h-5 text-orange-500" />
        </div>
        <div>
          <h1 className="text-2xl font-bold">{t("warehouse.title")}</h1>
          <p className="text-muted-foreground text-sm">{t("warehouse.subtitle")}</p>
        </div>
      </div>

      <StockAlertsPanel />

      {lowRows.length > 0 ? (
        <div className="rounded-2xl border border-amber-500/30 bg-amber-500/10 p-4 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-amber-700 dark:text-amber-300">
              {t("warehouse.banner.low", { count: lowRows.length })}
            </p>
            <p className="text-sm text-amber-700/80 dark:text-amber-300/80 mt-0.5">
              {lowRows.map((r) => `${t(`equip.${r.category}`)} (${r.stock})`).join(" · ")}
            </p>
          </div>
        </div>
      ) : (
        <div className="rounded-2xl border border-emerald-500/30 bg-emerald-500/10 p-4 flex items-center gap-3">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
          <p className="font-medium text-emerald-700 dark:text-emerald-300">
            {t("warehouse.banner.ok")}
          </p>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
        {rows.map((r) => (
          <div key={r.category} className="rounded-2xl bg-card border border-border p-5 space-y-4">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2">
                <Package className="w-4 h-4 text-muted-foreground" />
                <p className="font-semibold">{t(`equip.${r.category}`)}</p>
              </div>
              <StatusBadge status={r.status} label={t(`warehouse.status.${r.status}`)} />
            </div>

            <div>
              <p className="text-muted-foreground text-xs uppercase tracking-wider">
                {t("warehouse.inStock")}
              </p>
              <p
                className={`text-3xl font-bold ${
                  r.status === "critical"
                    ? "text-red-600 dark:text-red-400"
                    : r.status === "low"
                    ? "text-amber-600 dark:text-amber-400"
                    : "text-foreground"
                }`}
              >
                {r.stock}
              </p>
            </div>

            <div className="flex items-end gap-2">
              <div className="flex-1">
                <label className="text-muted-foreground text-xs uppercase tracking-wider">
                  {t("warehouse.minLevel")}
                </label>
                <input
                  type="number"
                  min="0"
                  value={drafts[r.category] === undefined ? r.min : drafts[r.category]}
                  onChange={(e) => setDrafts((d) => ({ ...d, [r.category]: e.target.value }))}
                  className="mt-1 w-full h-9 rounded-md border border-input bg-transparent px-3 text-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                />
              </div>
              <button
                onClick={() => saveMin(r.category)}
                disabled={savingCat === r.category}
                className="inline-flex items-center gap-1.5 h-9 px-3 rounded-md bg-orange-500 text-white text-sm font-medium hover:bg-orange-600 disabled:opacity-50"
              >
                <Save className="w-3.5 h-3.5" />
                {t("common.save")}
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="rounded-2xl bg-card border border-border overflow-hidden">
        <div className="px-5 py-4 border-b border-border">
          <p className="font-semibold">{t("warehouse.items")}</p>
          <p className="text-muted-foreground text-xs">{warehouseItems.length}</p>
        </div>
        {warehouseItems.length === 0 ? (
          <p className="px-5 py-8 text-center text-muted-foreground text-sm">
            {t("warehouse.noItems")}
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-muted-foreground text-xs uppercase tracking-wider">
                  <th className="text-start font-medium px-5 py-3">{t("warehouse.col.item")}</th>
                  <th className="text-start font-medium px-5 py-3">{t("warehouse.col.category")}</th>
                  <th className="text-start font-medium px-5 py-3">{t("warehouse.col.serial")}</th>
                  <th className="text-start font-medium px-5 py-3">{t("warehouse.col.location")}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {warehouseItems.map((item) => (
                  <tr key={item.id}>
                    <td className="px-5 py-3 font-medium">{item.name}</td>
                    <td className="px-5 py-3 text-muted-foreground">{t(`equip.${item.category}`)}</td>
                    <td className="px-5 py-3 text-muted-foreground">{item.serial_number || "—"}</td>
                    <td className="px-5 py-3 text-muted-foreground">{item.location || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <StockItemsPanel />
    </div>
  );
}

function StatusBadge({ status, label }) {
  const styles = {
    ok: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20",
    low: "bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20",
    critical: "bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/20",
  };
  return (
    <span className={`px-2.5 py-1 rounded-full border text-xs font-medium ${styles[status]}`}>
      {label}
    </span>
  );
}