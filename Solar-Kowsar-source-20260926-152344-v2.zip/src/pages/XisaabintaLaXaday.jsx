import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Zap, Activity, TrendingDown, AlertTriangle, Search, ShieldAlert, Plus, UserPlus } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import TheftAlertsPanel from "@/components/losses/TheftAlertsPanel";
import DiscrepancyCalculator from "@/components/losses/DiscrepancyCalculator";
import RiskZonesHeatmap from "@/components/losses/RiskZonesHeatmap";
import LossExportMenu from "@/components/losses/LossExportMenu";

// Commercial losses / power theft.
// Compares the load dispatched by the distribution transformers (what left the
// station) against the load the customers' meters actually registered. A gap
// that is too wide means energy disappeared between the station and the meter —
// a theft (illegal tap) or a faulty/bypassed meter.

const RISK_LEVELS = {
  critical: { label: "Halis Sare", text: "text-red-400", bg: "bg-red-500/15", border: "border-red-500/30" },
  suspicious: { label: "Shaki Leh", text: "text-amber-400", bg: "bg-amber-500/15", border: "border-amber-500/30" },
  watch: { label: "La Soco", text: "text-yellow-400", bg: "bg-yellow-500/15", border: "border-yellow-500/30" },
  normal: { label: "Caadi", text: "text-emerald-400", bg: "bg-emerald-500/15", border: "border-emerald-500/30" },
};

const riskOf = (pct) => (pct >= 25 ? "critical" : pct >= 15 ? "suspicious" : pct >= 8 ? "watch" : "normal");

const money = (n) => `$${Number(n || 0).toLocaleString(undefined, { maximumFractionDigits: 2 })}`;

export default function XisaabintaLaXaday() {
  const [transformers, setTransformers] = useState([]);
  const [meters, setMeters] = useState([]);
  const [rate, setRate] = useState(0);
  const [loading, setLoading] = useState(true);
  const [locFilter, setLocFilter] = useState("all");
  const [search, setSearch] = useState("");

  const loadData = () =>
    Promise.all([
      base44.entities.Transformer.list("-created_date", 500),
      base44.entities.Meter.list("-created_date", 500),
      base44.entities.Tariff.list("-effective_date", 200),
      base44.entities.Settings.list().catch(() => []),
    ]).then(([tr, mt, tariffs, settings]) => {
      setTransformers(tr || []);
      setMeters(mt || []);
      const active =
        (tariffs || []).find((t) => t.is_default && t.status === "active") ||
        (tariffs || []).find((t) => t.status === "active");
      setRate(Number(active?.rate_per_kwh) || Number(settings?.[0]?.rate_per_kwh) || 0);
    });

  useEffect(() => {
    loadData().finally(() => setLoading(false));
    // Live stream: re-read the devices whenever a meter or transformer reports in.
    const unsubMeters = base44.entities.Meter.subscribe(() => loadData());
    const unsubTransformers = base44.entities.Transformer.subscribe(() => loadData());
    return () => {
      unsubMeters();
      unsubTransformers();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // --- Group transformers (dispatched) and meters (registered) by location ---
  const zones = {};
  const ensureZone = (key) => {
    if (!zones[key]) zones[key] = { location: key, dispatched: 0, metered: 0, transformers: 0, meters: 0 };
    return zones[key];
  };
  transformers.forEach((t) => {
    const z = ensureZone(t.location || "—");
    z.dispatched += Number(t.current_load_kw) || 0;
    z.transformers += 1;
  });
  meters.forEach((m) => {
    const z = ensureZone(m.location || "—");
    z.metered += Number(m.current_load_kw) || 0;
    z.meters += 1;
  });

  const allZones = Object.values(zones).map((z) => {
    const loss = Math.max(0, z.dispatched - z.metered);
    const lossPct = z.dispatched > 0 ? (loss / z.dispatched) * 100 : 0;
    return {
      ...z,
      loss,
      lossPct,
      risk: riskOf(lossPct),
      dailyValue: loss * 24 * rate,
    };
  });

  const locations = allZones.map((z) => z.location).filter((l) => l !== "—");
  const scoped = locFilter === "all" ? allZones : allZones.filter((z) => z.location === locFilter);
  const rows = [...scoped].sort((a, b) => b.lossPct - a.lossPct);

  const totalDispatched = scoped.reduce((s, z) => s + z.dispatched, 0);
  const totalMetered = scoped.reduce((s, z) => s + z.metered, 0);
  const totalLoss = Math.max(0, totalDispatched - totalMetered);
  const totalLossPct = totalDispatched > 0 ? (totalLoss / totalDispatched) * 100 : 0;
  const flagged = rows.filter((z) => z.risk === "critical" || z.risk === "suspicious");

  // --- Individual meters that need a field check ---
  const suspects = meters
    .filter((m) => {
      const z = zones[m.location || "—"];
      const load = Number(m.current_load_kw) || 0;
      if (m.status === "faulty") return true;
      if (z && z.dispatched > 0 && (load === 0 || m.status === "inactive")) return true;
      return false;
    })
    .map((m) => {
      const z = zones[m.location || "—"];
      const load = Number(m.current_load_kw) || 0;
      let reason = "Baaritaan ayaa loo baahan yahay";
      if (m.status === "faulty") reason = "Mitaarka waa cilladaysan";
      else if (z && z.dispatched > 0 && load === 0) reason = "Culays la'aan halka xaruntu koronto dirtay";
      else if (m.status === "inactive") reason = "Mitaarka waa daman";
      return { ...m, reason };
    })
    .filter((m) => {
      if (!search) return true;
      const s = search.toLowerCase();
      return (
        (m.serial_number || "").toLowerCase().includes(s) ||
        (m.customer_name || "").toLowerCase().includes(s) ||
        (m.location || "").toLowerCase().includes(s)
      );
    });

  // --- Live theft alerts: a meter silent while its transformer line is loaded ---
  const theftAlerts = meters
    .map((m) => {
      const z = zones[m.location || "—"];
      const dispatched = z ? z.dispatched : 0;
      const load = Number(m.current_load_kw) || 0;
      if (dispatched <= 0) return null;
      if (m.status === "active" && load > 0) return null;
      let reason = "Mitaarku ma diiwaangelin culays halka xariiqdu shaqeyneyso";
      if (m.status === "faulty") reason = "Mitaarku waa cilladaysan — isgaarsiin la'aan";
      else if (m.status === "inactive") reason = "Mitaarku waa daman — isgaarsiin la'aan";
      return {
        id: m.id,
        meter: m.serial_number || "—",
        customer: m.customer_name || "Macmiil aan la aqoon",
        location: m.location || "—",
        load,
        dispatched,
        severity: m.status === "faulty" || m.status === "inactive" ? "critical" : "warning",
        reason,
      };
    })
    .filter(Boolean)
    .sort((a, b) => (a.severity === "critical" ? 0 : 1) - (b.severity === "critical" ? 0 : 1));

  const chartData = rows
    .filter((z) => z.dispatched > 0 || z.metered > 0)
    .slice(0, 12)
    .map((z) => ({
      name: z.location,
      dispatched: Number(z.dispatched.toFixed(2)),
      metered: Number(z.metered.toFixed(2)),
    }));

  const hasData = transformers.length > 0 || meters.length > 0;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-red-500/10 flex items-center justify-center">
            <ShieldAlert className="w-5 h-5 text-red-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">Xisaabinta Tamarta La Xaday</h1>
            <p className="text-muted-foreground text-sm">
              Farqiga u dhexeeya korontada ka baxday xarunta iyo tan mitaaradu diiwaangelisay — digniinta tuuganimada
            </p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Select value={locFilter} onValueChange={setLocFilter}>
            <SelectTrigger className="w-52 bg-background border-border text-foreground">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Dhammaan goobaha</SelectItem>
              {locations.map((l) => (
                <SelectItem key={l} value={l}>
                  {l}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <LossExportMenu
            zones={rows}
            rate={rate}
            scopeLabel={locFilter === "all" ? "dhammaan-goobaha" : locFilter}
          />
        </div>
      </div>

      {loading ? (
        <div className="py-24 flex items-center justify-center">
          <div className="w-8 h-8 border-4 border-orange-500/30 border-t-orange-500 rounded-full animate-spin" />
        </div>
      ) : (
        <>
          {!hasData && (
            <div className="rounded-2xl bg-card border border-border p-8 text-center">
              <ShieldAlert className="w-10 h-10 mx-auto mb-3 text-muted-foreground opacity-30" />
              <p className="text-sm text-muted-foreground">
                Xog kugu filan lama helin. Diiwaangeli Transformer-ka xarunta iyo Mitaarada si nidaamku u xisaabiyo farqiga.
              </p>
              <div className="flex flex-wrap items-center justify-center gap-3 mt-5">
                <Link to="/shabakada-qeybinta">
                  <Button className="gap-2 bg-orange-500 hover:bg-orange-600 text-white">
                    <Plus className="w-4 h-4" /> Kudar Transformer
                  </Button>
                </Link>
                <Link to="/macaamiisha">
                  <Button variant="outline" className="gap-2">
                    <UserPlus className="w-4 h-4" /> Diiwaangeli Mitaar
                  </Button>
                </Link>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <DiscrepancyCalculator
              dispatched={totalDispatched}
              metered={totalMetered}
              loss={totalLoss}
              lossPct={totalLossPct}
              rate={rate}
            />
            <RiskZonesHeatmap zones={rows} />
          </div>

          <TheftAlertsPanel alerts={theftAlerts} />

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatBox
              label="Korontada Xarunta"
              value={`${totalDispatched.toFixed(1)} kW`}
              icon={Zap}
              tone="text-amber-400"
              bg="from-amber-500/10 to-amber-600/5 border-amber-500/15"
              sub="Waxa ka baxay transformer-rada"
            />
            <StatBox
              label="Mitaaradu Diiwaangelisay"
              value={`${totalMetered.toFixed(1)} kW`}
              icon={Activity}
              tone="text-cyan-400"
              bg="from-cyan-500/10 to-cyan-600/5 border-cyan-500/15"
              sub="Wadarta culayska mitaarada"
            />
            <StatBox
              label="Farqiga (La Xaday)"
              value={`${totalLoss.toFixed(1)} kW`}
              icon={TrendingDown}
              tone="text-red-400"
              bg="from-red-500/10 to-red-600/5 border-red-500/15"
              sub={`${totalLossPct.toFixed(1)}% lumid`}
            />
            <StatBox
              label="Goobaha Shaki Leh"
              value={`${flagged.length}`}
              icon={AlertTriangle}
              tone="text-orange-400"
              bg="from-orange-500/10 to-orange-600/5 border-orange-500/15"
              sub={`${rows.length} goobood la eegay`}
            />
          </div>

          {rate > 0 && (
            <div className="rounded-2xl bg-gradient-to-br from-red-500/10 to-red-600/5 border border-red-500/15 p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <p className="text-muted-foreground text-xs font-medium uppercase tracking-wider">Qiimaha Lumitaanka</p>
                <p className="text-muted-foreground text-xs mt-0.5">
                  Haddii culayska hadda jiro 24 saac, maalin kasta waxaa lumaya lacag dhan
                </p>
              </div>
              <p className="text-2xl font-bold text-red-400">{money(totalLoss * 24 * rate)}</p>
            </div>
          )}

          {flagged.length > 0 && (
            <div className="rounded-2xl bg-amber-500/10 border border-amber-500/20 p-5">
              <div className="flex items-center gap-2 mb-3">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                <h2 className="text-amber-400 font-semibold text-sm">
                  Goobaha Farqiga Badan — Tuuganimada Korontada Ayaa Laga Shakiyay
                </h2>
              </div>
              <div className="flex flex-wrap gap-2">
                {flagged.map((z) => (
                  <span
                    key={z.location}
                    className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-card border border-amber-500/20 text-sm"
                  >
                    <span className="text-foreground">{z.location}</span>
                    <span className="text-amber-400 font-semibold">{z.lossPct.toFixed(1)}%</span>
                    <span className="text-muted-foreground text-xs">{z.loss.toFixed(1)} kW</span>
                  </span>
                ))}
              </div>
            </div>
          )}

          <div className="rounded-2xl bg-card border border-border p-5">
            <h2 className="text-foreground font-semibold mb-1">Xarunta vs Mitaarada</h2>
            <p className="text-muted-foreground text-xs mb-4">Culayska la diray iyo kan la diiwaangeliyay goob kasta (kW)</p>
            {chartData.length > 0 ? (
              <div style={{ width: "100%", height: 300 }}>
                <ResponsiveContainer>
                  <BarChart data={chartData} margin={{ top: 4, right: 8, left: -12, bottom: 4 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                    <XAxis
                      dataKey="name"
                      tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }}
                      axisLine={{ stroke: "hsl(var(--border))" }}
                      tickLine={false}
                    />
                    <YAxis tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }} axisLine={false} tickLine={false} />
                    <Tooltip
                      contentStyle={{
                        background: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: 12,
                        color: "hsl(var(--foreground))",
                      }}
                    />
                    <Legend wrapperStyle={{ fontSize: 12 }} />
                    <Bar dataKey="dispatched" name="Ka baxay xarunta" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="metered" name="Mitaaradu diiwaangelisay" fill="#06b6d4" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-64 flex items-center justify-center text-muted-foreground text-sm">Xog lama helin</div>
            )}
          </div>

          <div className="rounded-2xl bg-card border border-border overflow-hidden">
            <div className="p-5 border-b border-border">
              <h2 className="text-foreground font-semibold">Farqiga Goob kasta</h2>
              <p className="text-muted-foreground text-xs mt-1">Goobaha loo kala saaray farqiga ugu badan</p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border text-muted-foreground text-xs uppercase tracking-wider">
                    <th className="text-left px-5 py-3 font-medium">Goobta</th>
                    <th className="text-right px-5 py-3 font-medium">Ka baxay xarunta</th>
                    <th className="text-right px-5 py-3 font-medium">Mitaarada</th>
                    <th className="text-right px-5 py-3 font-medium">Farqi</th>
                    <th className="text-right px-5 py-3 font-medium">Farqi %</th>
                    <th className="text-right px-5 py-3 font-medium">Qiimaha/Maalin</th>
                    <th className="text-left px-5 py-3 font-medium">Heerka Halista</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {rows.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="px-5 py-12 text-center text-muted-foreground">
                        Xog lama helin
                      </td>
                    </tr>
                  ) : (
                    rows.map((z) => {
                      const risk = RISK_LEVELS[z.risk];
                      return (
                        <tr key={z.location} className="hover:bg-accent/30 transition-colors">
                          <td className="px-5 py-3">
                            <span className="text-foreground font-medium">{z.location}</span>
                            <span className="block text-xs text-muted-foreground">
                              {z.transformers} transformer · {z.meters} mitaar
                            </span>
                          </td>
                          <td className="px-5 py-3 text-right text-amber-400">{z.dispatched.toFixed(1)}</td>
                          <td className="px-5 py-3 text-right text-cyan-400">{z.metered.toFixed(1)}</td>
                          <td className="px-5 py-3 text-right text-foreground font-medium">{z.loss.toFixed(1)}</td>
                          <td className={`px-5 py-3 text-right font-semibold ${risk.text}`}>{z.lossPct.toFixed(1)}%</td>
                          <td className="px-5 py-3 text-right text-muted-foreground">
                            {rate > 0 ? money(z.dailyValue) : "—"}
                          </td>
                          <td className="px-5 py-3">
                            <span className={`inline-flex px-2.5 py-1 rounded-full text-xs font-medium border ${risk.bg} ${risk.text} ${risk.border}`}>
                              {risk.label}
                            </span>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>

          <div className="rounded-2xl bg-card border border-border overflow-hidden">
            <div className="p-5 border-b border-border flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-foreground font-semibold">Mitaarada Loo Baahan Yahay Baaritaan</h2>
                <p className="text-muted-foreground text-xs mt-1">
                  Mitaarada aan culays diiwaangelin ama cilladaysan — tuuganimada oo suurtagal ah
                </p>
              </div>
              <div className="relative sm:w-72">
                <Search className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Raadi mitaar, macmiil ama goob..."
                  className="ps-9 bg-background border-border text-foreground"
                />
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border text-muted-foreground text-xs uppercase tracking-wider">
                    <th className="text-left px-5 py-3 font-medium">Mitaarka</th>
                    <th className="text-left px-5 py-3 font-medium">Macmiilka</th>
                    <th className="text-left px-5 py-3 font-medium">Goobta</th>
                    <th className="text-right px-5 py-3 font-medium">Culays (kW)</th>
                    <th className="text-left px-5 py-3 font-medium">Sababta</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {suspects.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="px-5 py-12 text-center text-muted-foreground">
                        Mitaar shaki leh lama helin
                      </td>
                    </tr>
                  ) : (
                    suspects.map((m) => (
                      <tr key={m.id} className="hover:bg-accent/30 transition-colors">
                        <td className="px-5 py-3 text-foreground font-medium">{m.serial_number || "—"}</td>
                        <td className="px-5 py-3 text-muted-foreground">{m.customer_name || "—"}</td>
                        <td className="px-5 py-3 text-muted-foreground">{m.location || "—"}</td>
                        <td className="px-5 py-3 text-right text-foreground">{Number(m.current_load_kw) || 0}</td>
                        <td className="px-5 py-3">
                          <span className="text-xs px-2.5 py-1 rounded-full bg-red-500/15 text-red-400 border border-red-500/30">
                            {m.reason}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function StatBox({ label, value, icon: Icon, tone, bg, sub }) {
  return (
    <div className={`rounded-2xl bg-gradient-to-br border p-5 ${bg}`}>
      <div className="flex items-center justify-between mb-3">
        <p className="text-muted-foreground text-xs font-medium uppercase tracking-wider">{label}</p>
        <Icon className={`w-4 h-4 ${tone}`} />
      </div>
      <p className={`text-2xl font-bold ${tone}`}>{value}</p>
      {sub && <p className="text-muted-foreground text-xs mt-1">{sub}</p>}
    </div>
  );
}