import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { LifeBuoy, Plus, Search, Clock, CheckCircle2, AlertTriangle, Send, Trash2, Loader2 } from "lucide-react";

const CATEGORY_META = {
  technical: "Cilad Farsamo",
  billing: "Arrimaha Lacagta",
  maintenance: "Dayactir",
  complaint: "Cabasho",
  other: "Kale",
};

const PRIORITY_META = {
  low: { label: "Hoose", color: "text-zinc-400 bg-zinc-500/10 border-zinc-500/20" },
  medium: { label: "Dhexdhexaad", color: "text-amber-400 bg-amber-500/10 border-amber-500/20" },
  high: { label: "Sare", color: "text-orange-400 bg-orange-500/10 border-orange-500/20" },
  urgent: { label: "Dagdag", color: "text-red-400 bg-red-500/10 border-red-500/20" },
};

const STATUS_META = {
  open: { label: "Furan", color: "text-blue-400 bg-blue-500/10 border-blue-500/20" },
  in_progress: { label: "Socota", color: "text-amber-400 bg-amber-500/10 border-amber-500/20" },
  resolved: { label: "La Xalliyay", color: "text-emerald-400 bg-emerald-500/10 border-emerald-500/20" },
  closed: { label: "La Xiray", color: "text-zinc-400 bg-zinc-500/10 border-zinc-500/20" },
};

const emptyForm = {
  subject: "",
  description: "",
  category: "technical",
  priority: "medium",
  status: "open",
  customer: "",
  contact_name: "",
  contact_phone: "",
};

export default function Caawinaad() {
  const { toast } = useToast();
  const [tickets, setTickets] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [respondOpen, setRespondOpen] = useState(false);
  const [active, setActive] = useState(null);
  const [response, setResponse] = useState("");
  const [assignedTo, setAssignedTo] = useState("");
  const [respondStatus, setRespondStatus] = useState("in_progress");
  const [saving, setSaving] = useState(false);

  const load = async () => {
    try {
      setLoading(true);
      const [t, c] = await Promise.all([
        base44.entities.SupportTicket.list("-created_date", 200),
        base44.entities.Customer.list(),
      ]);
      setTickets(t);
      setCustomers(c);
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Tikidhada lama keeni karo" });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const getCustomerName = (id) => customers.find((c) => c.id === id)?.full_name || "";

  const openCreate = () => { setEditing(null); setForm(emptyForm); setFormOpen(true); };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    const payload = {
      ...form,
      customer: form.customer || null,
      ticket_number: editing?.ticket_number || `TKT-${Date.now().toString().slice(-6)}`,
    };
    try {
      if (editing) {
        await base44.entities.SupportTicket.update(editing.id, payload);
        toast({ title: "Waa la cusboonaysiiyay", description: "Tikidhka waa la bedelay" });
      } else {
        await base44.entities.SupportTicket.create(payload);
        toast({ title: "Waa la gudbiyay", description: "Cabashadaada waa la helay" });
      }
      setFormOpen(false);
      load();
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Hawl lama soosaarin karo" });
    } finally {
      setSaving(false);
    }
  };

  const openRespond = (ticket) => {
    setActive(ticket);
    setResponse(ticket.response || "");
    setAssignedTo(ticket.assigned_to || "");
    setRespondStatus(ticket.status === "open" ? "in_progress" : ticket.status);
    setRespondOpen(true);
  };

  const handleRespond = async () => {
    if (!active) return;
    setSaving(true);
    try {
      await base44.entities.SupportTicket.update(active.id, {
        response,
        assigned_to: assignedTo,
        status: respondStatus,
        resolved_date: respondStatus === "resolved"
          ? new Date().toISOString().split("T")[0]
          : active.resolved_date,
      });
      toast({ title: "Jawaabta waa la keydiyay", description: "Macmiilka waa la jawaabay" });
      setRespondOpen(false);
      load();
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Jawaabta lama keydin karo" });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (ticket) => {
    try {
      await base44.entities.SupportTicket.delete(ticket.id);
      toast({ title: "Waa la tirtiray", description: "Tikidhka waa la saaray" });
      load();
    } catch {
      toast({ variant: "destructive", title: "Khalad", description: "Lama tirtiri karo" });
    }
  };

  const counts = {
    open: tickets.filter((t) => t.status === "open").length,
    in_progress: tickets.filter((t) => t.status === "in_progress").length,
    resolved: tickets.filter((t) => t.status === "resolved" || t.status === "closed").length,
  };

  const filtered = tickets.filter((t) => {
    const name = (t.contact_name || getCustomerName(t.customer) || "").toLowerCase();
    const matchSearch =
      name.includes(search.toLowerCase()) ||
      t.subject?.toLowerCase().includes(search.toLowerCase()) ||
      t.ticket_number?.includes(search);
    const matchStatus = filterStatus === "all" || t.status === filterStatus;
    return matchSearch && matchStatus;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Caawinaad &amp; Taageero</h1>
          <p className="text-zinc-400 text-sm mt-1">Cabashooyinka macaamiisha iyo ciladaha farsamo</p>
        </div>
        <Button onClick={openCreate} className="gap-2 bg-orange-500 hover:bg-orange-600 text-white">
          <Plus className="w-4 h-4" /> Gudbi Cabasho
        </Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatBox label="Furan" value={counts.open} icon={AlertTriangle} color="text-blue-400" bg="from-blue-500/10 to-blue-600/5 border-blue-500/15" />
        <StatBox label="Socota" value={counts.in_progress} icon={Clock} color="text-amber-400" bg="from-amber-500/10 to-amber-600/5 border-amber-500/15" />
        <StatBox label="La Xalliyay" value={counts.resolved} icon={CheckCircle2} color="text-emerald-400" bg="from-emerald-500/10 to-emerald-600/5 border-emerald-500/15" />
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
          <Input
            placeholder="Raadi cinwaan, macmiil ama lambar..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 bg-zinc-900 border-zinc-800 text-white placeholder:text-zinc-600"
          />
        </div>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-44 bg-zinc-900 border-zinc-800 text-white"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Dhammaan</SelectItem>
            <SelectItem value="open">Furan</SelectItem>
            <SelectItem value="in_progress">Socota</SelectItem>
            <SelectItem value="resolved">La Xalliyay</SelectItem>
            <SelectItem value="closed">La Xiray</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="flex justify-center py-20">
          <div className="w-8 h-8 border-4 border-orange-500/30 border-t-orange-500 rounded-full animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-20 text-zinc-500">
          <LifeBuoy className="w-12 h-12 mx-auto mb-3 text-zinc-700" />
          <p className="text-lg font-medium">Tikidh lama helin</p>
          <p className="text-sm mt-1">Gudbi cabasho cusub si aad u bilowdo</p>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-zinc-800/50">
          <table className="w-full">
            <thead>
              <tr className="bg-zinc-900/80 border-b border-zinc-800/50">
                <th className="text-left p-4 text-xs font-medium text-zinc-400 uppercase tracking-wider">Cinwaanka</th>
                <th className="text-left p-4 text-xs font-medium text-zinc-400 uppercase tracking-wider hidden md:table-cell">Qaybta</th>
                <th className="text-left p-4 text-xs font-medium text-zinc-400 uppercase tracking-wider hidden sm:table-cell">Muhimada</th>
                <th className="text-left p-4 text-xs font-medium text-zinc-400 uppercase tracking-wider">Xaaladda</th>
                <th className="text-right p-4 text-xs font-medium text-zinc-400 uppercase tracking-wider">Hawlo</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/30">
              {filtered.map((t) => {
                const p = PRIORITY_META[t.priority] || PRIORITY_META.medium;
                const s = STATUS_META[t.status] || STATUS_META.open;
                return (
                  <tr key={t.id} className="hover:bg-zinc-900/50 transition-colors">
                    <td className="p-4">
                      <p className="text-white text-sm font-medium">{t.subject}</p>
                      <p className="text-zinc-500 text-xs mt-0.5">
                        {t.contact_name || getCustomerName(t.customer) || "—"} · {t.ticket_number || "—"}
                      </p>
                    </td>
                    <td className="p-4 text-zinc-300 text-sm hidden md:table-cell">{CATEGORY_META[t.category] || t.category}</td>
                    <td className="p-4 hidden sm:table-cell">
                      <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium border ${p.color}`}>{p.label}</span>
                    </td>
                    <td className="p-4">
                      <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium border ${s.color}`}>{s.label}</span>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center justify-end gap-2">
                        <Button size="sm" onClick={() => openRespond(t)} className="bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 text-xs">
                          <Send className="w-3 h-3 mr-1" /> Jawaab
                        </Button>
                        <button onClick={() => handleDelete(t)} className="text-zinc-500 hover:text-red-400 transition-colors p-1">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* New / Edit ticket */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="bg-zinc-900 border-zinc-800 text-white sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Gudbi Cabasho Cusub</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label className="text-zinc-300">Cinwaanka *</Label>
              <Input required value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" placeholder="T.c. Inverter-ka wuu joogsaday" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-zinc-300">Qaybta</Label>
                <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
                  <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-zinc-900 border-zinc-800">
                    {Object.entries(CATEGORY_META).map(([v, label]) => (
                      <SelectItem key={v} value={v}>{label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-zinc-300">Muhimada</Label>
                <Select value={form.priority} onValueChange={(v) => setForm({ ...form, priority: v })}>
                  <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-zinc-900 border-zinc-800">
                    {Object.entries(PRIORITY_META).map(([v, m]) => (
                      <SelectItem key={v} value={v}>{m.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-zinc-300">Macmiilka (ikhtiyaari)</Label>
              <Select value={form.customer} onValueChange={(v) => setForm({ ...form, customer: v })}>
                <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white"><SelectValue placeholder="Dooro macmiil" /></SelectTrigger>
                <SelectContent className="bg-zinc-900 border-zinc-800">
                  {customers.map((c) => (
                    <SelectItem key={c.id} value={c.id}>{c.full_name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-zinc-300">Magaca Soo Gudbiyaha</Label>
                <Input value={form.contact_name} onChange={(e) => setForm({ ...form, contact_name: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" placeholder="T.c. Cabdi Cali" />
              </div>
              <div className="space-y-2">
                <Label className="text-zinc-300">Telefoonka</Label>
                <Input value={form.contact_phone} onChange={(e) => setForm({ ...form, contact_phone: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" placeholder="0615XXXXXX" />
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-zinc-300">Faahfaahinta *</Label>
              <Textarea required rows={4} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="bg-zinc-800 border-zinc-700 text-white" placeholder="Sharax ciladda ama cabashada..." />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setFormOpen(false)} className="border-zinc-700 text-zinc-300">Jooji</Button>
              <Button type="submit" disabled={saving} className="bg-orange-500 hover:bg-orange-600 text-white">
                {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
                Gudbi
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Respond */}
      <Dialog open={respondOpen} onOpenChange={setRespondOpen}>
        <DialogContent className="bg-zinc-900 border-zinc-800 text-white sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Jawaab &amp; Xaaladda Tikidhka</DialogTitle>
          </DialogHeader>
          {active && (
            <div className="space-y-4">
              <div className="rounded-xl bg-zinc-800/50 border border-zinc-800 p-4">
                <p className="text-white text-sm font-medium">{active.subject}</p>
                <p className="text-zinc-400 text-xs mt-1">{active.description}</p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-zinc-300">Xaaladda</Label>
                  <Select value={respondStatus} onValueChange={setRespondStatus}>
                    <SelectTrigger className="bg-zinc-800 border-zinc-700 text-white"><SelectValue /></SelectTrigger>
                    <SelectContent className="bg-zinc-900 border-zinc-800">
                      <SelectItem value="open">Furan</SelectItem>
                      <SelectItem value="in_progress">Socota</SelectItem>
                      <SelectItem value="resolved">La Xalliyay</SelectItem>
                      <SelectItem value="closed">La Xiray</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="text-zinc-300">Loo Xilsaaray</Label>
                  <Input value={assignedTo} onChange={(e) => setAssignedTo(e.target.value)} className="bg-zinc-800 border-zinc-700 text-white" placeholder="T.c. Farsamaha" />
                </div>
              </div>
              <div className="space-y-2">
                <Label className="text-zinc-300">Jawaabta</Label>
                <Textarea rows={4} value={response} onChange={(e) => setResponse(e.target.value)} className="bg-zinc-800 border-zinc-700 text-white" placeholder="Qor jawaabta macmiilka..." />
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setRespondOpen(false)} className="border-zinc-700 text-zinc-300">Jooji</Button>
                <Button type="button" onClick={handleRespond} disabled={saving} className="bg-emerald-500 hover:bg-emerald-600 text-white">
                  {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Send className="w-4 h-4 mr-2" />}
                  Keydi Jawaabta
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function StatBox({ label, value, icon: Icon, color, bg }) {
  return (
    <div className={`rounded-2xl bg-gradient-to-br border p-5 ${bg}`}>
      <div className="flex items-center justify-between mb-3">
        <p className="text-zinc-400 text-xs font-medium uppercase tracking-wider">{label}</p>
        <Icon className={`w-4 h-4 ${color}`} />
      </div>
      <p className={`text-2xl font-bold ${color}`}>{value}</p>
    </div>
  );
}