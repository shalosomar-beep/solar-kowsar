import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { useT } from "@/lib/i18n";
import { useAuth } from "@/lib/AuthContext";
import { useToast } from "@/components/ui/use-toast";
import { isAdminRole } from "@/lib/permissions";
import ChangelogForm from "@/components/changelog/ChangelogForm";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  History as HistoryIcon,
  Plus,
  Pencil,
  Trash2,
  Search,
  Rocket,
  Bug,
  Wrench,
  ShieldCheck,
  Calendar,
  Layers,
} from "lucide-react";

const CATEGORY_META = {
  feature: { icon: Rocket, cls: "bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20" },
  fix: { icon: Bug, cls: "bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/20" },
  improvement: { icon: Wrench, cls: "bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20" },
  security: { icon: ShieldCheck, cls: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20" },
};

const CATEGORIES = ["feature", "fix", "improvement", "security"];

export default function LogIsbeddelada() {
  const { t } = useT();
  const { jobRole } = useAuth();
  const { toast } = useToast();
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [saving, setSaving] = useState(false);

  const isAdmin = isAdminRole(jobRole);

  useEffect(() => {
    load();
  }, []);

  const load = async () => {
    const data = await base44.entities.ChangelogEntry.list("-release_date", 200);
    setEntries(Array.isArray(data) ? data : []);
    setLoading(false);
  };

  const openNew = () => {
    setEditing(null);
    setDialogOpen(true);
  };

  const openEdit = (entry) => {
    setEditing(entry);
    setDialogOpen(true);
  };

  const save = async (form) => {
    setSaving(true);
    try {
      if (editing?.id) {
        await base44.entities.ChangelogEntry.update(editing.id, form);
      } else {
        await base44.entities.ChangelogEntry.create(form);
      }
      await load();
      setDialogOpen(false);
      setEditing(null);
      toast({ title: t("changelog.toast.saved") });
    } catch (e) {
      toast({
        title: t("common.error"),
        description: String(e?.message || e),
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const remove = async (entry) => {
    if (!window.confirm(t("common.confirmDelete"))) return;
    await base44.entities.ChangelogEntry.delete(entry.id);
    await load();
    toast({ title: t("changelog.toast.deleted") });
  };

  const query = search.trim().toLowerCase();
  const filtered = entries.filter((entry) => {
    if (filter !== "all" && entry.category !== filter) return false;
    if (!query) return true;
    return [entry.version, entry.title, entry.description].some((value) =>
      String(value || "").toLowerCase().includes(query)
    );
  });

  const latest = entries.find((e) => e.status !== "planned") || entries[0];

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-4 border-orange-500/30 border-t-orange-500 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div className="flex items-start gap-3">
          <div className="w-11 h-11 rounded-xl bg-orange-500/10 border border-orange-500/20 flex items-center justify-center shrink-0">
            <HistoryIcon className="w-5 h-5 text-orange-500" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">{t("changelog.title")}</h1>
            <p className="text-muted-foreground text-sm">{t("changelog.subtitle")}</p>
          </div>
        </div>
        {isAdmin && (
          <Button onClick={openNew} className="bg-orange-500 hover:bg-orange-600 text-white">
            <Plus className="w-4 h-4" />
            {t("changelog.new")}
          </Button>
        )}
      </div>

      {latest && (
        <div className="rounded-2xl border border-orange-500/30 bg-orange-500/10 p-5">
          <p className="text-xs uppercase tracking-wider font-medium text-orange-600 dark:text-orange-400">
            {t("changelog.latest")}
          </p>
          <p className="text-3xl font-bold mt-1">v{latest.version}</p>
          <p className="text-sm mt-0.5 text-foreground/80">{latest.title}</p>
        </div>
      )}

      <div className="flex flex-col lg:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t("changelog.searchPlaceholder")}
            className="ps-9"
          />
        </div>
        <div className="flex flex-wrap gap-2">
          {["all", ...CATEGORIES].map((c) => (
            <button
              key={c}
              onClick={() => setFilter(c)}
              className={`px-3 py-2 rounded-lg text-xs font-medium border transition-colors ${
                filter === c
                  ? "bg-orange-500 text-white border-orange-500"
                  : "bg-card border-border text-muted-foreground hover:text-foreground"
              }`}
            >
              {c === "all" ? t("changelog.filter.all") : t(`changelog.cat.${c}`)}
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-2xl bg-card border border-border p-12 text-center">
          <Layers className="w-10 h-10 mx-auto text-muted-foreground/50" />
          <p className="mt-3 font-medium">{t("changelog.empty")}</p>
          <p className="text-muted-foreground text-sm mt-0.5">{t("changelog.empty.sub")}</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((entry) => {
            const meta = CATEGORY_META[entry.category] || CATEGORY_META.feature;
            const Icon = meta.icon;
            return (
              <div key={entry.id} className="rounded-2xl bg-card border border-border p-5">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3 min-w-0">
                    <span
                      className={`w-9 h-9 rounded-lg border flex items-center justify-center shrink-0 ${meta.cls}`}
                    >
                      <Icon className="w-4 h-4" />
                    </span>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="px-2 py-0.5 rounded-md bg-orange-500/10 text-orange-600 dark:text-orange-400 border border-orange-500/20 text-xs font-bold">
                          v{entry.version}
                        </span>
                        <span
                          className={`px-2.5 py-0.5 rounded-full border text-xs font-medium ${meta.cls}`}
                        >
                          {t(`changelog.cat.${entry.category}`)}
                        </span>
                        {entry.status === "planned" && (
                          <span className="px-2.5 py-0.5 rounded-full border border-border bg-muted text-muted-foreground text-xs font-medium">
                            {t("changelog.status.planned")}
                          </span>
                        )}
                      </div>
                      <p className="font-semibold mt-2">{entry.title}</p>
                      {entry.description && (
                        <p className="text-muted-foreground text-sm mt-1 whitespace-pre-line">
                          {entry.description}
                        </p>
                      )}
                      {entry.release_date && (
                        <p className="flex items-center gap-1.5 text-muted-foreground text-xs mt-2">
                          <Calendar className="w-3.5 h-3.5" />
                          {entry.release_date}
                        </p>
                      )}
                    </div>
                  </div>
                  {isAdmin && (
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={() => openEdit(entry)}
                        title={t("common.edit")}
                        className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => remove(entry)}
                        title={t("common.delete")}
                        className="p-2 rounded-lg text-muted-foreground hover:text-red-400 hover:bg-accent transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      <ChangelogForm
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        initial={editing}
        onSave={save}
        saving={saving}
      />
    </div>
  );
}