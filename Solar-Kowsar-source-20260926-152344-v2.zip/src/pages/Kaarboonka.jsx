import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Leaf, Zap, TreePine, Car, Award, TrendingUp, DollarSign, Info } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

export default function Kaarboonka() {
  const { toast } = useToast();
  const [solar, setSolar] = useState([]);
  const [loading, setLoading] = useState(true);
  const [factor, setFactor] = useState(0.7);
  const [price, setPrice] = useState(10);

  useEffect(() => {
    base44.entities.SolarData.list("-usage_date", 500)
      .then(setSolar)
      .catch(() => toast({ variant: "destructive", title: "Khalad", description: "Xogta qoraxda lama keeni karin" }))
      .finally(() => setLoading(false));
  }, []);

  const totalKwh = solar.reduce((s, r) => s + (r.production_kwh || 0), 0);
  const co2Kg = totalKwh * factor;
  const tonnes = co2Kg / 1000;
  const credits = tonnes;
  const value = credits * price;
  const trees = co2Kg / 21;
  const cars = co2Kg / 4600;

  const byMonth = {};
  solar.forEach((r) => {
    const m = (r.usage_date || "").slice(0, 7);
    if (!m) return;
    byMonth[m] = (byMonth[m] || 0) + (r.production_kwh || 0);
  });
  const chartData = Object.entries(byMonth)
    .sort((a, b) => a[0].localeCompare(b[0]))
    .slice(-12)
    .map(([m, kwh]) => ({ month: m.slice(2), co2: Number(((kwh * factor) / 1000).toFixed(2)), kwh: Math.round(kwh) }));

  if (loading) {
    return (
      <div className="py-24 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-emerald-500/30 border-t-emerald-500 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Maamulka Deegaanka &amp; Kaarboonka</h1>
        <p className="text-zinc-400 text-sm mt-1">Xisaabi CO₂-ga la badbaadiyay iyo qiimaha kaarboon credits-ka</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="rounded-2xl bg-gradient-to-br from-emerald-500/10 to-emerald-600/5 border border-emerald-500/20 p-5">
          <div className="flex items-center justify-between mb-3">
            <p className="text-zinc-400 text-xs font-medium uppercase tracking-wider">CO₂ La Badbaadiyay</p>
            <Leaf className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-3xl font-bold text-emerald-400">{tonnes.toFixed(1)}</p>
          <p className="text-zinc-500 text-xs mt-1">tan oo CO₂ ({co2Kg.toLocaleString(undefined, { maximumFractionDigits: 0 })} kg)</p>
        </div>
        <div className="rounded-2xl bg-gradient-to-br from-amber-500/10 to-amber-600/5 border border-amber-500/20 p-5">
          <div className="flex items-center justify-between mb-3">
            <p className="text-zinc-400 text-xs font-medium uppercase tracking-wider">Kaarboon Credits</p>
            <Award className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-3xl font-bold text-amber-400">{credits.toFixed(1)}</p>
          <p className="text-zinc-500 text-xs mt-1">1 credit = 1 tan CO₂</p>
        </div>
        <div className="rounded-2xl bg-gradient-to-br from-blue-500/10 to-blue-600/5 border border-blue-500/20 p-5">
          <div className="flex items-center justify-between mb-3">
            <p className="text-zinc-400 text-xs font-medium uppercase tracking-wider">Qiimaha La Filan</p>
            <DollarSign className="w-4 h-4 text-blue-400" />
          </div>
          <p className="text-3xl font-bold text-blue-400">${value.toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
          <p className="text-zinc-500 text-xs mt-1">marka la iibiyo credits-ka</p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <ImpactCard icon={Zap} label="Tamarta Qorraxda" value={`${totalKwh.toLocaleString(undefined, { maximumFractionDigits: 0 })} kWh`} color="text-amber-400" />
        <ImpactCard icon={TreePine} label="Geedo U Dhigma" value={trees.toLocaleString(undefined, { maximumFractionDigits: 0 })} color="text-emerald-400" />
        <ImpactCard icon={Car} label="Baabuur La Dhigay" value={cars.toFixed(1)} color="text-blue-400" />
      </div>

      {chartData.length > 0 && (
        <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-5">
          <h2 className="text-white font-semibold mb-1">CO₂ La Badbaadiyay Bishii</h2>
          <p className="text-zinc-500 text-xs mb-4">Tanno CO₂ bishii (12 bilood ee ugu dambeeyay)</p>
          <div style={{ width: "100%", height: 280 }}>
            <ResponsiveContainer>
              <BarChart data={chartData} margin={{ top: 4, right: 8, left: -18, bottom: 4 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                <XAxis dataKey="month" tick={{ fill: "#a1a1aa", fontSize: 11 }} axisLine={{ stroke: "#3f3f46" }} tickLine={false} />
                <YAxis tick={{ fill: "#a1a1aa", fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ background: "#18181b", border: "1px solid #3f3f46", borderRadius: 12, color: "#fff" }} formatter={(v) => [`${v} tCO₂`, "La badbaadiyay"]} />
                <Bar dataKey="co2" fill="#10b981" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-5">
        <h2 className="text-white font-semibold mb-4 flex items-center gap-2"><TrendingUp className="w-4 h-4 text-emerald-400" /> Habka Xisaabta</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label className="text-zinc-400 text-xs">Heerka CO₂ ee Shabakada (kg CO₂ / kWh)</Label>
            <Input type="number" step="0.01" value={factor} onChange={(e) => setFactor(Number(e.target.value) || 0)} className="bg-zinc-800 border-zinc-700 text-white" />
          </div>
          <div className="space-y-2">
            <Label className="text-zinc-400 text-xs">Qiimaha Credit-ka ($ / tan CO₂)</Label>
            <Input type="number" step="0.5" value={price} onChange={(e) => setPrice(Number(e.target.value) || 0)} className="bg-zinc-800 border-zinc-700 text-white" />
          </div>
        </div>
        <p className="text-zinc-500 text-xs mt-4 flex items-start gap-2">
          <Info className="w-3.5 h-3.5 mt-0.5 shrink-0" />
          CO₂ la badbaadiyay = tamarta qorraxda la soo saaray × heerka CO₂ ee shabakada. Haddii shirkaddu isticmaasho generator shidaal, heerka caadiga ah waa 0.7–0.9 kg/kWh. Geed kastaa wuxuu nuugaa ~21 kg CO₂ sannadkii.
        </p>
      </div>
    </div>
  );
}

function ImpactCard({ icon: Icon, label, value, color }) {
  return (
    <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-4 flex items-center gap-4">
      <div className="w-10 h-10 rounded-xl bg-zinc-800/60 flex items-center justify-center shrink-0">
        <Icon className={`w-5 h-5 ${color}`} />
      </div>
      <div>
        <p className="text-zinc-500 text-[11px] font-medium uppercase tracking-wider">{label}</p>
        <p className={`text-lg font-bold ${color}`}>{value}</p>
      </div>
    </div>
  );
}