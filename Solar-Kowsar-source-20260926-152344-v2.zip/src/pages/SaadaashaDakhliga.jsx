import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { TrendingUp, Wallet, Sun, Users, CloudSun, Calculator } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { useT } from "@/lib/i18n";

// Revenue forecasting.
// Projects the current month's revenue from the customers' metered consumption,
// then adjusts it by the weather trend (recent sun hours vs the 30-day baseline)
// because generation — and therefore deliverable, billable energy — follows the sun.

const keyOf = (date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
const monthKeyOf = (value) => (typeof value === "string" ? value.slice(0, 7) : "");

const labelOf = (key) => {
  const [y, m] = key.split("-");
  return new Date(Number(y), Number(m) - 1, 1).toLocaleDateString("en", { month: "short", year: "2-digit" });
};

const money = (n) => `$${Number(n || 0).toLocaleString(undefined, { maximumFractionDigits: 0 })}`;
const kwh = (n) => `${Math.round(Number(n) || 0).toLocaleString()} kWh`;

const TYPE_KEYS = { residential: "seg.residential.short", commercial: "seg.commercial.short", industrial: "seg.industrial.short" };

export default function SaadaashaDakhliga() {
  const { t } = useT();
  const [usage, setUsage] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [solar, setSolar] = useState([]);
  const [rate, setRate] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      base44.entities.DailyUsage.list("-usage_date", 2000),
      base44.entities.Customer.list("-created_date", 1000),
      base44.entities.SolarData.list("-usage_date", 200),
      base44.entities.Tariff.list("-effective_date", 200),
      base44.entities.Settings.list().catch(() => []),
    ])
      .then(([u, c, s, tariffs, settings]) => {
        setUsage(u || []);
        setCustomers(c || []);
        setSolar(s || []);
        const active =
          (tariffs || []).find((t) => t.is_default && t.status === "active") ||
          (tariffs || []).find((t) => t.status === "active");
        setRate(Number(active?.rate_per_kwh) || Number(settings?.[0]?.rate_per_kwh) || 0);
      })
      .finally(() => setLoading(false));
  }, []);

  const now = new Date();
  const currentKey = keyOf(now);
  const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
  const daysElapsed = now.getDate();

  // --- Consumption this month → run rate → projection ---
  const usageThisMonth = usage.filter((r) => monthKeyOf(r.usage_date) === currentKey);
  const kwhMtd = usageThisMonth.reduce((s, r) => s + (Number(r.kwh_used) || 0), 0);
  const dailyAvgKwh = daysElapsed > 0 ? kwhMtd / daysElapsed : 0;
  const projectedKwh = dailyAvgKwh * daysInMonth;
  const hasUsageThisMonth = kwhMtd > 0;

  // --- Weather factor: recent sun hours vs 30-day baseline ---
  const withSun = solar.filter((r) => typeof r.sun_hours === "number" && r.usage_date);
  const avgSun = (arr) => (arr.length ? arr.reduce((s, r) => s + r.sun_hours, 0) / arr.length : 0);
  const recentSunAvg = avgSun(withSun.slice(0, 7));
  const baselineSunAvg = avgSun(withSun.slice(0, 30));
  const rawFactor = baselineSunAvg > 0 ? recentSunAvg / baselineSunAvg : 1;
  const weatherFactor = Math.min(1.25, Math.max(0.75, rawFactor));

  // --- Contracted subscription revenue ---
  const activeCustomers = customers.filter((c) => c.status === "active");
  const contractedRevenue = activeCustomers.reduce((s, c) => s + (Number(c.monthly_rate) || 0), 0);

  // With no metered consumption yet this month, fall back to the customers'
  // contracted monthly rates so the forecast is still meaningful. The weather
  // trend only adjusts consumption-based projections, never fixed contracts.
  const baselineRevenue = hasUsageThisMonth ? projectedKwh * rate : contractedRevenue;
  const forecastRevenue = baselineRevenue * (hasUsageThisMonth ? weatherFactor : 1);

  // --- Monthly history: last 6 months, current month shown as the forecast ---
  const monthKeys = [];
  for (let i = 5; i >= 0; i--) {
    monthKeys.push(keyOf(new Date(now.getFullYear(), now.getMonth() - i, 1)));
  }
  const kwhByMonth = {};
  usage.forEach((r) => {
    const k = monthKeyOf(r.usage_date);
    if (!k) return;
    kwhByMonth[k] = (kwhByMonth[k] || 0) + (Number(r.kwh_used) || 0);
  });
  const history = monthKeys.map((k) => {
    const isCurrent = k === currentKey;
    const monthKwh = isCurrent ? projectedKwh : kwhByMonth[k] || 0;
    return {
      label: labelOf(k),
      isCurrent,
      kwh: Math.round(monthKwh),
      revenue: Math.round(isCurrent ? forecastRevenue : monthKwh * rate),
    };
  });

  // --- Breakdown by customer type ---
  const typeById = {};
  customers.forEach((c) => {
    typeById[c.id] = c.customer_type || "residential";
  });
  const byType = {};
  usageThisMonth.forEach((r) => {
    const t = typeById[r.customer] || "residential";
    if (!byType[t]) byType[t] = { kwh: 0, ids: new Set() };
    byType[t].kwh += Number(r.kwh_used) || 0;
    if (r.customer) byType[t].ids.add(r.customer);
  });
  const typeRows = hasUsageThisMonth
    ? Object.entries(byType)
        .map(([type, v]) => {
          const projKwh = daysElapsed > 0 ? (v.kwh / daysElapsed) * daysInMonth : 0;
          return {
            type,
            labelKey: TYPE_KEYS[type] || null,
            customers: v.ids.size,
            mtdKwh: v.kwh,
            projKwh,
            revenue: projKwh * rate * weatherFactor,
            usageBased: true,
          };
        })
        .sort((a, b) => b.revenue - a.revenue)
    : Object.entries(
        activeCustomers.reduce((acc, c) => {
          const t = c.customer_type || "residential";
          if (!acc[t]) acc[t] = { count: 0, rate: 0 };
          acc[t].count += 1;
          acc[t].rate += Number(c.monthly_rate) || 0;
          return acc;
        }, {})
      )
        .map(([type, v]) => ({
          type,
          labelKey: TYPE_KEYS[type] || null,
          customers: v.count,
          mtdKwh: 0,
          projKwh: 0,
          revenue: v.rate,
          usageBased: false,
        }))
        .sort((a, b) => b.revenue - a.revenue);

  const hasData = usage.length > 0 || customers.length > 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-lg bg-emerald-500/10 flex items-center justify-center">
          <TrendingUp className="w-5 h-5 text-emerald-400" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-foreground">{t("rev.title")}</h1>
          <p className="text-muted-foreground text-sm">{t("rev.sub")}</p>
        </div>
      </div>

      {loading ? (
        <div className="py-24 flex items-center justify-center">
          <div className="w-8 h-8 border-4 border-orange-500/30 border-t-orange-500 rounded-full animate-spin" />
        </div>
      ) : !hasData ? (
        <div className="rounded-2xl bg-card border border-border p-12 text-center">
          <Calculator className="w-12 h-12 mx-auto mb-3 text-muted-foreground opacity-30" />
          <p className="text-sm text-muted-foreground">{t("rev.empty")}</p>
        </div>
      ) : (
        <>
          <div className="rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 p-6 text-white">
            <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider opacity-90">
              <Sun className="w-4 h-4" />
              {t("rev.hero.month", { month: now.toLocaleDateString("en", { month: "long", year: "numeric" }) })}
            </div>
            <p className="text-4xl sm:text-5xl font-bold mt-3">{money(forecastRevenue)}</p>
            <p className="text-sm opacity-90 mt-3 max-w-2xl">
              {t("rev.hero.desc", { amount: money(forecastRevenue) })}
            </p>
            {!hasUsageThisMonth && (
              <p className="text-xs opacity-80 mt-2">
                {t("rev.hero.noUsage")}
              </p>
            )}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-5 pt-5 border-t border-white/20 text-sm">
              <div>
                <p className="opacity-80 text-xs uppercase tracking-wider">{t("rev.hero.projectedUsage")}</p>
                <p className="font-semibold text-lg mt-0.5">{kwh(projectedKwh)}</p>
              </div>
              <div>
                <p className="opacity-80 text-xs uppercase tracking-wider">{t("rev.hero.weather")}</p>
                <p className="font-semibold text-lg mt-0.5">
                  {hasUsageThisMonth
                    ? `${weatherFactor >= 1 ? "+" : ""}${((weatherFactor - 1) * 100).toFixed(1)}%`
                    : "—"}
                </p>
              </div>
              <div>
                <p className="opacity-80 text-xs uppercase tracking-wider">{t("rev.hero.contract")}</p>
                <p className="font-semibold text-lg mt-0.5">{money(contractedRevenue)}</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatBox
              label={t("rev.stat.made")}
              value={money(kwhMtd * rate)}
              icon={Wallet}
              tone="text-emerald-400"
              bg="from-emerald-500/10 to-emerald-600/5 border-emerald-500/15"
              sub={t("rev.stat.madeSub", { kwh: kwhMtd.toLocaleString(undefined, { maximumFractionDigits: 0 }) })}
            />
            <StatBox
              label={t("rev.stat.noWeather")}
              value={money(baselineRevenue)}
              icon={Calculator}
              tone="text-cyan-400"
              bg="from-cyan-500/10 to-cyan-600/5 border-cyan-500/15"
              sub={t("rev.stat.noWeatherSub", { elapsed: daysElapsed, total: daysInMonth })}
            />
            <StatBox
              label={t("rev.stat.daily")}
              value={money(dailyAvgKwh * rate)}
              icon={TrendingUp}
              tone="text-amber-400"
              bg="from-amber-500/10 to-amber-600/5 border-amber-500/15"
              sub={t("rev.stat.dailySub", { kwh: dailyAvgKwh.toFixed(1) })}
            />
            <StatBox
              label={t("rev.stat.active")}
              value={`${activeCustomers.length}`}
              icon={Users}
              tone="text-purple-400"
              bg="from-purple-500/10 to-purple-600/5 border-purple-500/15"
              sub={t("rev.stat.activeSub", { count: customers.length })}
            />
          </div>

          <div className="rounded-2xl bg-card border border-border p-5">
            <div className="flex items-center gap-2 mb-1">
              <CloudSun className="w-4 h-4 text-amber-400" />
              <h2 className="text-foreground font-semibold">{t("rev.hero.weather")}</h2>
            </div>
            <p className="text-muted-foreground text-xs mb-4">{t("rev.weather.sub")}</p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="rounded-xl bg-accent/40 p-4">
                <p className="text-muted-foreground text-xs uppercase tracking-wider">{t("rev.weather.7")}</p>
                <p className="text-foreground font-semibold text-xl mt-1">{recentSunAvg.toFixed(2)} h</p>
              </div>
              <div className="rounded-xl bg-accent/40 p-4">
                <p className="text-muted-foreground text-xs uppercase tracking-wider">{t("rev.weather.30")}</p>
                <p className="text-foreground font-semibold text-xl mt-1">{baselineSunAvg.toFixed(2)} h</p>
              </div>
              <div className="rounded-xl bg-accent/40 p-4">
                <p className="text-muted-foreground text-xs uppercase tracking-wider">{t("rev.weather.impact")}</p>
                <p className={`font-semibold text-xl mt-1 ${weatherFactor >= 1 ? "text-emerald-400" : "text-amber-400"}`}>
                  {weatherFactor >= 1 ? "+" : ""}
                  {((weatherFactor - 1) * 100).toFixed(1)}%
                </p>
              </div>
            </div>
            {baselineSunAvg === 0 && (
              <p className="text-muted-foreground text-xs mt-3">
                {t("rev.weather.none")}
              </p>
            )}
          </div>

          <div className="rounded-2xl bg-card border border-border p-5">
            <h2 className="text-foreground font-semibold mb-1">{t("rev.month.title")}</h2>
            <p className="text-muted-foreground text-xs mb-4">{t("rev.month.sub")}</p>
            <div style={{ width: "100%", height: 300 }}>
              <ResponsiveContainer>
                <BarChart data={history} margin={{ top: 4, right: 8, left: -12, bottom: 4 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                  <XAxis
                    dataKey="label"
                    tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }}
                    axisLine={{ stroke: "hsl(var(--border))" }}
                    tickLine={false}
                  />
                  <YAxis tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }} axisLine={false} tickLine={false} />
                  <Tooltip
                    formatter={(value, name) => (name === "revenue" ? [money(value), t("rev.month.revenue")] : [kwh(value), t("rev.month.usage")])}
                    contentStyle={{
                      background: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: 12,
                      color: "hsl(var(--foreground))",
                    }}
                  />
                  <Bar dataKey="revenue" name="revenue" radius={[6, 6, 0, 0]}>
                    {history.map((h) => (
                      <Cell key={h.label} fill={h.isCurrent ? "#34d399" : "#0f766e"} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {typeRows.length > 0 && (
            <div className="rounded-2xl bg-card border border-border overflow-hidden">
              <div className="p-5 border-b border-border">
                <h2 className="text-foreground font-semibold">{t("rev.type.title")}</h2>
                <p className="text-muted-foreground text-xs mt-1">{t("rev.type.sub")}</p>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border text-muted-foreground text-xs uppercase tracking-wider">
                      <th className="text-left px-5 py-3 font-medium">{t("rev.col.type")}</th>
                      <th className="text-right px-5 py-3 font-medium">{t("rev.col.customers")}</th>
                      <th className="text-right px-5 py-3 font-medium">{t("rev.col.mtd")}</th>
                      <th className="text-right px-5 py-3 font-medium">{t("rev.col.projected")}</th>
                      <th className="text-right px-5 py-3 font-medium">{t("rev.col.revenue")}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {typeRows.map((r) => (
                      <tr key={r.type} className="hover:bg-accent/30 transition-colors">
                        <td className="px-5 py-3 text-foreground font-medium">{r.labelKey ? t(r.labelKey) : r.type}</td>
                        <td className="px-5 py-3 text-right text-muted-foreground">{r.customers}</td>
                        <td className="px-5 py-3 text-right text-cyan-400">{r.usageBased ? kwh(r.mtdKwh) : "—"}</td>
                        <td className="px-5 py-3 text-right text-foreground">{r.usageBased ? kwh(r.projKwh) : "—"}</td>
                        <td className="px-5 py-3 text-right text-emerald-400 font-semibold">{money(r.revenue)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function StatBox({ label, value, icon: Icon, tone, bg, sub }) {
  return (
    <div className={`rounded-2xl bg-gradient-to-br border p-5 ${bg}`}>
      <div className="flex items-center justify-between mb-3">
        <p className="text-muted-foreground text-xs font-medium uppercase tracking-wider">{label}</p>
        <Icon className={`w-4 h-4 ${tone}`} />
      </div>
      <p className={`text-2xl font-bold ${tone}`}>{value}</p>
      {sub && <p className="text-muted-foreground text-xs mt-1">{sub}</p>}
    </div>
  );
}