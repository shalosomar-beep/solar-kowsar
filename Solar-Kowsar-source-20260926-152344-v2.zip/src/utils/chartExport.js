const VAR_ATTRS = ["fill", "stroke", "stop-color"];

// Serializes a recharts SVG to a downloadable PNG. CSS variables inside the
// SVG attributes are resolved from the live DOM first, otherwise the exported
// image loses every themed colour.
export async function exportChartPng(container, filename, bg = "#ffffff") {
  const svg = container?.querySelector("svg");
  if (!svg) return false;

  const clone = svg.cloneNode(true);
  const orig = [svg, ...svg.querySelectorAll("*")];
  const cloned = [clone, ...clone.querySelectorAll("*")];

  cloned.forEach((el, i) => {
    const source = orig[i];
    if (!source) return;
    VAR_ATTRS.forEach((attr) => {
      const raw = el.getAttribute(attr);
      if (!raw || !raw.includes("var(")) return;
      const cs = getComputedStyle(source);
      const resolved = attr === "stop-color" ? cs.stopColor : cs.getPropertyValue(attr);
      if (resolved) el.setAttribute(attr, resolved);
    });
  });

  const rect = svg.getBoundingClientRect();
  const w = Math.round(rect.width) || 800;
  const h = Math.round(rect.height) || 400;
  clone.setAttribute("width", w);
  clone.setAttribute("height", h);
  clone.setAttribute("xmlns", "http://www.w3.org/2000/svg");

  const data = new XMLSerializer().serializeToString(clone);
  const src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(data);

  const img = new Image();
  await new Promise((resolve, reject) => {
    img.onload = resolve;
    img.onerror = reject;
    img.src = src;
  });

  const scale = 2;
  const canvas = document.createElement("canvas");
  canvas.width = w * scale;
  canvas.height = h * scale;
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

  const a = document.createElement("a");
  a.href = canvas.toDataURL("image/png");
  a.download = filename.endsWith(".png") ? filename : `${filename}.png`;
  a.click();
  return true;
}