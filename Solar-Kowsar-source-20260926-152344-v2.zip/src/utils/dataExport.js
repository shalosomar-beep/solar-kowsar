import { jsPDF } from "jspdf";

/** @param {unknown} v */
function escapeCell(v) {
  const s = v == null ? "" : String(v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

/** @param {string} filename @param {string[]} columns @param {unknown[][]} rows */
export function exportCsv(filename, columns, rows) {
  const csv = [columns, ...rows].map((r) => r.map(escapeCell).join(",")).join("\n");
  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename.endsWith(".csv") ? filename : `${filename}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

/** @param {string} filename @param {string} title @param {string[]} columns @param {unknown[][]} rows */
export function exportPdf(filename, title, columns, rows) {
  const doc = new jsPDF({ orientation: columns.length > 6 ? "landscape" : "portrait" });
  const pageW = doc.internal.pageSize.getWidth();
  const pageH = doc.internal.pageSize.getHeight();
  const colW = (pageW - 28) / columns.length;
  let y = 18;

  doc.setFontSize(14);
  doc.setTextColor(20);
  doc.text(title, 14, y);
  y += 6;
  doc.setFontSize(8);
  doc.setTextColor(130);
  doc.text(`La soo saaray: ${new Date().toLocaleString()} · ${rows.length} diiwaan`, 14, y);
  y += 9;

  const drawHeader = () => {
    doc.setFontSize(8);
    doc.setTextColor(60);
    columns.forEach((c, i) => doc.text(String(c).slice(0, 22), 14 + i * colW, y));
    y += 2.5;
    doc.setDrawColor(200);
    doc.line(14, y, pageW - 14, y);
    y += 4.5;
  };
  drawHeader();

  doc.setFontSize(8);
  doc.setTextColor(30);
  rows.forEach((r) => {
    if (y > pageH - 14) {
      doc.addPage();
      y = 18;
      drawHeader();
      doc.setFontSize(8);
      doc.setTextColor(30);
    }
    r.forEach((cell, i) => {
      doc.text(String(cell == null ? "" : cell).slice(0, 24), 14 + i * colW, y);
    });
    y += 5.5;
  });

  doc.save(`${filename}.pdf`);
}