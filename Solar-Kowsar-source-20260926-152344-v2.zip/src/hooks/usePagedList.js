import { useMemo, useState } from "react";

const compare = (a, b) => {
  if (a == null && b == null) return 0;
  if (a == null) return 1;
  if (b == null) return -1;
  const an = Number(a);
  const bn = Number(b);
  if (!Number.isNaN(an) && !Number.isNaN(bn) && a !== "" && b !== "") return an - bn;
  return String(a).localeCompare(String(b));
};

/**
 * Client-side sorting + pagination for a list already filtered by the page.
 * Returns the current page slice plus the controls the header/pagination need.
 */
export function usePagedList(items, { pageSize = 10, initialSort = null } = {}) {
  const [page, setPage] = useState(1);
  const [sort, setSort] = useState({ key: initialSort, dir: "asc" });

  const sorted = useMemo(() => {
    if (!sort.key) return items;
    const copy = [...items].sort((a, b) => compare(a[sort.key], b[sort.key]));
    return sort.dir === "asc" ? copy : copy.reverse();
  }, [items, sort]);

  const pageCount = Math.max(1, Math.ceil(sorted.length / pageSize));
  const safePage = Math.min(page, pageCount);
  const from = (safePage - 1) * pageSize;
  const to = Math.min(from + pageSize, sorted.length);

  const toggleSort = (key) =>
    setSort((s) => ({ key, dir: s.key === key && s.dir === "asc" ? "desc" : "asc" }));

  return {
    slice: sorted.slice(from, to),
    page: safePage,
    pageCount,
    total: sorted.length,
    from: sorted.length === 0 ? 0 : from + 1,
    to,
    setPage,
    sort,
    toggleSort,
  };
}